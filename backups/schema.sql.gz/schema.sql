--
-- PostgreSQL database dump
--

\restrict iNWr7apgr2iSZtpAkVs84lMeetbzjbpfmkSDjczggckHYxgb1fdtIVjOOYAu2wD

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.10 (Debian 17.10-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP EVENT TRIGGER pgrst_drop_watch;
DROP EVENT TRIGGER pgrst_ddl_watch;
DROP EVENT TRIGGER issue_pg_net_access;
DROP EVENT TRIGGER issue_pg_graphql_access;
DROP EVENT TRIGGER issue_pg_cron_access;
DROP EVENT TRIGGER issue_graphql_placeholder;
DROP PUBLICATION supabase_realtime;
DROP POLICY user_saved_playlists_select_own ON public.user_saved_playlists;
DROP POLICY user_saved_playlists_insert_own ON public.user_saved_playlists;
DROP POLICY user_saved_playlists_delete_own ON public.user_saved_playlists;
DROP POLICY user_recent_searches_update_own ON public.user_recent_searches;
DROP POLICY user_recent_searches_select_own ON public.user_recent_searches;
DROP POLICY user_recent_searches_insert_own ON public.user_recent_searches;
DROP POLICY user_recent_searches_delete_own ON public.user_recent_searches;
DROP POLICY user_recent_items_update_own ON public.user_recent_items;
DROP POLICY user_recent_items_select_own ON public.user_recent_items;
DROP POLICY user_recent_items_insert_own ON public.user_recent_items;
DROP POLICY user_recent_items_delete_own ON public.user_recent_items;
DROP POLICY user_preferred_genres_select_own ON public.user_preferred_genres;
DROP POLICY user_preferred_artists_select_own ON public.user_preferred_artists;
DROP POLICY user_player_state_update_own ON public.user_player_state;
DROP POLICY user_player_state_select_own ON public.user_player_state;
DROP POLICY user_player_state_insert_own ON public.user_player_state;
DROP POLICY user_player_state_delete_own ON public.user_player_state;
DROP POLICY user_followed_artists_select_own ON public.user_followed_artists;
DROP POLICY user_followed_artists_insert_own ON public.user_followed_artists;
DROP POLICY user_followed_artists_delete_own ON public.user_followed_artists;
DROP POLICY user_disliked_songs_update_own ON public.user_disliked_songs;
DROP POLICY user_disliked_songs_select_own ON public.user_disliked_songs;
DROP POLICY user_disliked_songs_insert_own ON public.user_disliked_songs;
DROP POLICY user_disliked_songs_delete_own ON public.user_disliked_songs;
DROP POLICY user_disliked_artists_update_own ON public.user_disliked_artists;
DROP POLICY user_disliked_artists_select_own ON public.user_disliked_artists;
DROP POLICY user_disliked_artists_insert_own ON public.user_disliked_artists;
DROP POLICY user_disliked_artists_delete_own ON public.user_disliked_artists;
DROP POLICY trending_search_keywords_public_read ON public.trending_search_keywords;
DROP POLICY songs_public_read_active ON public.songs;
DROP POLICY song_moods_public_read ON public.song_moods;
DROP POLICY song_listens_select_own ON public.song_listens;
DROP POLICY song_listens_insert_own ON public.song_listens;
DROP POLICY song_hashtags_public_read ON public.song_hashtags;
DROP POLICY song_genres_public_read ON public.song_genres;
DROP POLICY song_artists_public_read ON public.song_artists;
DROP POLICY profiles_update_own ON public.profiles;
DROP POLICY profiles_select_own ON public.profiles;
DROP POLICY podcasts_public_read_active ON public.podcasts;
DROP POLICY podcast_listens_select_own ON public.podcast_listens;
DROP POLICY podcast_listens_insert_own ON public.podcast_listens;
DROP POLICY podcast_favorites_select_own ON public.podcast_favorites;
DROP POLICY podcast_favorites_insert_own ON public.podcast_favorites;
DROP POLICY podcast_favorites_delete_own ON public.podcast_favorites;
DROP POLICY podcast_channels_public_read ON public.podcast_channels;
DROP POLICY playlists_update_own ON public.playlists;
DROP POLICY playlists_select_own_or_saved ON public.playlists;
DROP POLICY playlists_public_read ON public.playlists;
DROP POLICY playlists_insert_own ON public.playlists;
DROP POLICY playlists_delete_own ON public.playlists;
DROP POLICY playlist_songs_update_own ON public.playlist_songs;
DROP POLICY playlist_songs_read_accessible_playlist ON public.playlist_songs;
DROP POLICY playlist_songs_insert_own ON public.playlist_songs;
DROP POLICY playlist_songs_delete_own ON public.playlist_songs;
DROP POLICY moods_public_read_active ON public.moods;
DROP POLICY home_sections_public_read_active ON public.home_sections;
DROP POLICY home_section_items_public_read_active ON public.home_section_items;
DROP POLICY home_banners_public_read_active ON public.home_banners;
DROP POLICY hashtags_public_read_active ON public.hashtags;
DROP POLICY genres_public_read_active ON public.genres;
DROP POLICY favorites_select_own ON public.favorites;
DROP POLICY favorites_insert_own ON public.favorites;
DROP POLICY favorites_delete_own ON public.favorites;
DROP POLICY channel_subscriptions_select_own ON public.channel_subscriptions;
DROP POLICY channel_subscriptions_insert_own ON public.channel_subscriptions;
DROP POLICY channel_subscriptions_delete_own ON public.channel_subscriptions;
DROP POLICY artists_public_read ON public.artists;
DROP POLICY albums_public_read_active ON public.albums;
DROP POLICY album_songs_public_read ON public.album_songs;
DROP POLICY album_artists_public_read ON public.album_artists;
DROP POLICY "Users can view their own recent items" ON public.user_recent_items;
DROP POLICY "Users can update their own recent items" ON public.user_recent_items;
DROP POLICY "Users can select their own listens" ON public.listens;
DROP POLICY "Users can insert their own recent items" ON public.user_recent_items;
DROP POLICY "Users can insert their own listens" ON public.listens;
ALTER TABLE ONLY public.user_saved_playlists DROP CONSTRAINT user_saved_playlists_user_id_fkey;
ALTER TABLE ONLY public.user_saved_playlists DROP CONSTRAINT user_saved_playlists_playlist_id_fkey;
ALTER TABLE ONLY public.user_recent_searches DROP CONSTRAINT user_recent_searches_user_id_fkey;
ALTER TABLE ONLY public.user_recent_items DROP CONSTRAINT user_recent_items_user_id_fkey;
ALTER TABLE ONLY public.user_preferred_genres DROP CONSTRAINT user_preferred_genres_user_id_fkey;
ALTER TABLE ONLY public.user_preferred_genres DROP CONSTRAINT user_preferred_genres_genre_id_fkey;
ALTER TABLE ONLY public.user_preferred_artists DROP CONSTRAINT user_preferred_artists_user_id_fkey;
ALTER TABLE ONLY public.user_preferred_artists DROP CONSTRAINT user_preferred_artists_artist_id_fkey;
ALTER TABLE ONLY public.user_followed_artists DROP CONSTRAINT user_followed_artists_user_id_fkey;
ALTER TABLE ONLY public.user_followed_artists DROP CONSTRAINT user_followed_artists_artist_id_fkey;
ALTER TABLE ONLY public.user_disliked_songs DROP CONSTRAINT user_disliked_songs_user_id_fkey;
ALTER TABLE ONLY public.user_disliked_songs DROP CONSTRAINT user_disliked_songs_song_id_fkey;
ALTER TABLE ONLY public.user_disliked_artists DROP CONSTRAINT user_disliked_artists_user_id_fkey;
ALTER TABLE ONLY public.user_disliked_artists DROP CONSTRAINT user_disliked_artists_artist_id_fkey;
ALTER TABLE ONLY public.song_moods DROP CONSTRAINT song_moods_song_id_fkey;
ALTER TABLE ONLY public.song_moods DROP CONSTRAINT song_moods_mood_id_fkey;
ALTER TABLE ONLY public.song_hashtags DROP CONSTRAINT song_hashtags_song_id_fkey;
ALTER TABLE ONLY public.song_hashtags DROP CONSTRAINT song_hashtags_hashtag_id_fkey;
ALTER TABLE ONLY public.song_genres DROP CONSTRAINT song_genres_song_id_fkey;
ALTER TABLE ONLY public.song_genres DROP CONSTRAINT song_genres_genre_id_fkey;
ALTER TABLE ONLY public.song_artists DROP CONSTRAINT song_artists_song_id_fkey;
ALTER TABLE ONLY public.song_artists DROP CONSTRAINT song_artists_artist_id_fkey;
ALTER TABLE ONLY public.podcasts DROP CONSTRAINT podcasts_channel_id_fkey;
ALTER TABLE ONLY public.podcast_listens DROP CONSTRAINT podcast_listens_user_id_fkey;
ALTER TABLE ONLY public.podcast_listens DROP CONSTRAINT podcast_listens_podcast_id_fkey;
ALTER TABLE ONLY public.podcast_favorites DROP CONSTRAINT podcast_favorites_user_id_fkey;
ALTER TABLE ONLY public.podcast_favorites DROP CONSTRAINT podcast_favorites_podcast_id_fkey;
ALTER TABLE ONLY public.playlists DROP CONSTRAINT playlists_user_id_fkey;
ALTER TABLE ONLY public.playlist_songs DROP CONSTRAINT playlist_songs_song_id_fkey;
ALTER TABLE ONLY public.playlist_songs DROP CONSTRAINT playlist_songs_playlist_id_fkey;
ALTER TABLE ONLY public.listens DROP CONSTRAINT listens_user_id_fkey;
ALTER TABLE ONLY public.listens DROP CONSTRAINT listens_song_id_fkey;
ALTER TABLE ONLY public.listens DROP CONSTRAINT listens_podcast_id_fkey;
ALTER TABLE ONLY public.home_section_items DROP CONSTRAINT home_section_items_section_id_fkey;
ALTER TABLE ONLY public.channel_subscriptions DROP CONSTRAINT channel_subscriptions_user_id_fkey;
ALTER TABLE ONLY public.channel_subscriptions DROP CONSTRAINT channel_subscriptions_channel_id_fkey;
ALTER TABLE ONLY public.album_songs DROP CONSTRAINT album_songs_song_id_fkey;
ALTER TABLE ONLY public.album_songs DROP CONSTRAINT album_songs_album_id_fkey;
ALTER TABLE ONLY public.album_artists DROP CONSTRAINT album_artists_artist_id_fkey;
ALTER TABLE ONLY public.album_artists DROP CONSTRAINT album_artists_album_id_fkey;
DROP TRIGGER trg_user_saved_playlists_cache ON public.user_saved_playlists;
DROP TRIGGER trg_user_recent_searches_trending ON public.user_recent_searches;
DROP TRIGGER trg_user_followed_artists_cache ON public.user_followed_artists;
DROP TRIGGER trg_song_listens_after_insert ON public.song_listens;
DROP TRIGGER trg_song_artists_cache ON public.song_artists;
DROP TRIGGER trg_podcast_listens_count ON public.podcast_listens;
DROP TRIGGER trg_playlist_songs_cache ON public.playlist_songs;
DROP TRIGGER trg_favorites_like_count ON public.favorites;
DROP TRIGGER trg_channel_subscriptions_count ON public.channel_subscriptions;
DROP TRIGGER trg_album_songs_cache ON public.album_songs;
DROP TRIGGER trg_album_artists_cache ON public.album_artists;
DROP INDEX public.idx_user_saved_playlists_user_id;
DROP INDEX public.idx_user_saved_playlists_playlist_id;
DROP INDEX public.idx_user_recent_searches_user_time;
DROP INDEX public.idx_user_recent_items_user_time;
DROP INDEX public.idx_user_preferred_genres_user_score;
DROP INDEX public.idx_user_preferred_artists_user_score;
DROP INDEX public.idx_user_player_state_song_id;
DROP INDEX public.idx_user_player_state_playlist_id;
DROP INDEX public.idx_user_followed_artists_user_id;
DROP INDEX public.idx_user_followed_artists_artist_id;
DROP INDEX public.idx_trending_search_keywords_score;
DROP INDEX public.idx_songs_release_date;
DROP INDEX public.idx_songs_is_active;
DROP INDEX public.idx_songs_external_id;
DROP INDEX public.idx_songs_album_id;
DROP INDEX public.idx_song_moods_song_id;
DROP INDEX public.idx_song_moods_mood_id;
DROP INDEX public.idx_song_listens_user_id;
DROP INDEX public.idx_song_listens_source_playlist_id;
DROP INDEX public.idx_song_listens_song_id;
DROP INDEX public.idx_song_listens_listened_at;
DROP INDEX public.idx_song_hashtags_song_id;
DROP INDEX public.idx_song_hashtags_hashtag_id;
DROP INDEX public.idx_song_genres_song_id;
DROP INDEX public.idx_song_genres_genre_id;
DROP INDEX public.idx_song_artists_song_id;
DROP INDEX public.idx_song_artists_artist_id;
DROP INDEX public.idx_podcasts_is_active;
DROP INDEX public.idx_podcasts_external_id;
DROP INDEX public.idx_podcasts_channel_id;
DROP INDEX public.idx_podcast_listens_user_id;
DROP INDEX public.idx_podcast_listens_podcast_id;
DROP INDEX public.idx_podcast_channels_name;
DROP INDEX public.idx_playlists_user_id;
DROP INDEX public.idx_playlists_type_public;
DROP INDEX public.idx_playlist_songs_song_id;
DROP INDEX public.idx_playlist_songs_playlist_id;
DROP INDEX public.idx_moods_slug;
DROP INDEX public.idx_home_sections_order;
DROP INDEX public.idx_home_section_items_section_order;
DROP INDEX public.idx_home_banners_order;
DROP INDEX public.idx_hashtags_slug;
DROP INDEX public.idx_hashtags_active;
DROP INDEX public.idx_genres_slug;
DROP INDEX public.idx_favorites_user_id;
DROP INDEX public.idx_favorites_song_id;
DROP INDEX public.idx_channel_subscriptions_user_id;
DROP INDEX public.idx_channel_subscriptions_channel_id;
DROP INDEX public.idx_artists_name;
DROP INDEX public.idx_artists_monthly_current_month;
DROP INDEX public.idx_albums_release_date;
DROP INDEX public.idx_albums_is_active;
DROP INDEX public.idx_albums_external_id;
DROP INDEX public.idx_album_songs_song_id;
DROP INDEX public.idx_album_songs_album_id;
DROP INDEX public.idx_album_artists_artist_id;
DROP INDEX public.idx_album_artists_album_id;
ALTER TABLE ONLY public.user_saved_playlists DROP CONSTRAINT user_saved_playlists_user_playlist_unique;
ALTER TABLE ONLY public.user_saved_playlists DROP CONSTRAINT user_saved_playlists_pkey;
ALTER TABLE ONLY public.user_recent_searches DROP CONSTRAINT user_recent_searches_user_keyword_unique;
ALTER TABLE ONLY public.user_recent_searches DROP CONSTRAINT user_recent_searches_pkey;
ALTER TABLE ONLY public.user_recent_items DROP CONSTRAINT user_recent_items_user_item_unique;
ALTER TABLE ONLY public.user_recent_items DROP CONSTRAINT user_recent_items_pkey;
ALTER TABLE ONLY public.user_preferred_genres DROP CONSTRAINT user_preferred_genres_pkey;
ALTER TABLE ONLY public.user_preferred_artists DROP CONSTRAINT user_preferred_artists_pkey;
ALTER TABLE ONLY public.user_player_state DROP CONSTRAINT user_player_state_pkey;
ALTER TABLE ONLY public.user_followed_artists DROP CONSTRAINT user_followed_artists_user_artist_unique;
ALTER TABLE ONLY public.user_followed_artists DROP CONSTRAINT user_followed_artists_pkey;
ALTER TABLE ONLY public.user_disliked_songs DROP CONSTRAINT user_disliked_songs_pkey;
ALTER TABLE ONLY public.user_disliked_artists DROP CONSTRAINT user_disliked_artists_pkey;
ALTER TABLE ONLY public.trending_search_keywords DROP CONSTRAINT trending_search_keywords_pkey;
ALTER TABLE ONLY public.trending_search_keywords DROP CONSTRAINT trending_search_keywords_keyword_key;
ALTER TABLE ONLY public.songs DROP CONSTRAINT songs_pkey;
ALTER TABLE ONLY public.song_moods DROP CONSTRAINT song_moods_pkey;
ALTER TABLE ONLY public.song_listens DROP CONSTRAINT song_listens_pkey;
ALTER TABLE ONLY public.song_hashtags DROP CONSTRAINT song_hashtags_song_hashtag_unique;
ALTER TABLE ONLY public.song_hashtags DROP CONSTRAINT song_hashtags_pkey;
ALTER TABLE ONLY public.song_genres DROP CONSTRAINT song_genres_pkey;
ALTER TABLE ONLY public.song_artists DROP CONSTRAINT song_artists_pkey;
ALTER TABLE ONLY public.profiles DROP CONSTRAINT profiles_pkey;
ALTER TABLE ONLY public.podcasts DROP CONSTRAINT podcasts_pkey;
ALTER TABLE ONLY public.podcasts DROP CONSTRAINT podcasts_external_id_key;
ALTER TABLE ONLY public.podcast_listens DROP CONSTRAINT podcast_listens_pkey;
ALTER TABLE ONLY public.podcast_favorites DROP CONSTRAINT podcast_favorites_user_id_podcast_id_key;
ALTER TABLE ONLY public.podcast_favorites DROP CONSTRAINT podcast_favorites_pkey;
ALTER TABLE ONLY public.podcast_channels DROP CONSTRAINT podcast_channels_pkey;
ALTER TABLE ONLY public.podcast_channels DROP CONSTRAINT podcast_channels_name_key;
ALTER TABLE ONLY public.playlists DROP CONSTRAINT playlists_pkey;
ALTER TABLE ONLY public.playlist_songs DROP CONSTRAINT playlist_songs_playlist_song_unique;
ALTER TABLE ONLY public.playlist_songs DROP CONSTRAINT playlist_songs_playlist_position_unique;
ALTER TABLE ONLY public.playlist_songs DROP CONSTRAINT playlist_songs_pkey;
ALTER TABLE ONLY public.moods DROP CONSTRAINT moods_slug_key;
ALTER TABLE ONLY public.moods DROP CONSTRAINT moods_pkey;
ALTER TABLE ONLY public.moods DROP CONSTRAINT moods_name_key;
ALTER TABLE ONLY public.listens DROP CONSTRAINT listens_pkey;
ALTER TABLE ONLY public.home_sections DROP CONSTRAINT home_sections_pkey;
ALTER TABLE ONLY public.home_sections DROP CONSTRAINT home_sections_code_key;
ALTER TABLE ONLY public.home_section_items DROP CONSTRAINT home_section_items_section_item_unique;
ALTER TABLE ONLY public.home_section_items DROP CONSTRAINT home_section_items_pkey;
ALTER TABLE ONLY public.home_banners DROP CONSTRAINT home_banners_pkey;
ALTER TABLE ONLY public.hashtags DROP CONSTRAINT hashtags_slug_key;
ALTER TABLE ONLY public.hashtags DROP CONSTRAINT hashtags_pkey;
ALTER TABLE ONLY public.genres DROP CONSTRAINT genres_slug_key;
ALTER TABLE ONLY public.genres DROP CONSTRAINT genres_pkey;
ALTER TABLE ONLY public.genres DROP CONSTRAINT genres_name_key;
ALTER TABLE ONLY public.favorites DROP CONSTRAINT favorites_pkey;
ALTER TABLE ONLY public.channel_subscriptions DROP CONSTRAINT channel_subscriptions_user_id_channel_id_key;
ALTER TABLE ONLY public.channel_subscriptions DROP CONSTRAINT channel_subscriptions_pkey;
ALTER TABLE ONLY public.artists DROP CONSTRAINT artists_pkey;
ALTER TABLE ONLY public.albums DROP CONSTRAINT albums_pkey;
ALTER TABLE ONLY public.albums DROP CONSTRAINT albums_external_id_key;
ALTER TABLE ONLY public.album_songs DROP CONSTRAINT album_songs_song_id_key;
ALTER TABLE ONLY public.album_songs DROP CONSTRAINT album_songs_pkey;
ALTER TABLE ONLY public.album_songs DROP CONSTRAINT album_songs_album_id_disc_number_track_number_key;
ALTER TABLE ONLY public.album_artists DROP CONSTRAINT album_artists_pkey;
ALTER TABLE ONLY public.album_artists DROP CONSTRAINT album_artists_album_id_artist_order_key;
DROP VIEW public.v_trending_search_keywords_for_app;
DROP VIEW public.v_songs_for_app;
DROP VIEW public.v_songs_by_hashtag_for_app;
DROP VIEW public.v_song_details;
DROP VIEW public.v_recent_song_history_for_app;
DROP VIEW public.v_recent_searches_for_app;
DROP VIEW public.v_recent_items_for_app;
DROP VIEW public.v_podcasts;
DROP VIEW public.v_player_state_for_app;
DROP VIEW public.v_moods_for_app;
DROP VIEW public.v_library_playlists_for_app;
DROP VIEW public.v_home_sections_for_app;
DROP VIEW public.v_home_section_items_for_app;
DROP VIEW public.v_home_banners_for_app;
DROP VIEW public.v_hashtags_for_app;
DROP VIEW public.v_genres_for_app;
DROP VIEW public.v_favorite_podcasts_for_app;
DROP VIEW public.v_artists_for_app;
DROP VIEW public.v_artist_details_for_app;
DROP VIEW public.v_albums_for_app;
DROP VIEW public.v_album_details_for_app;
DROP TABLE public.user_saved_playlists;
DROP TABLE public.user_recent_searches;
DROP TABLE public.user_recent_items;
DROP TABLE public.user_preferred_genres;
DROP TABLE public.user_preferred_artists;
DROP TABLE public.user_player_state;
DROP TABLE public.user_followed_artists;
DROP TABLE public.user_disliked_songs;
DROP TABLE public.user_disliked_artists;
DROP TABLE public.trending_search_keywords;
DROP TABLE public.songs;
DROP TABLE public.song_moods;
DROP TABLE public.song_listens;
DROP TABLE public.song_hashtags;
DROP TABLE public.song_genres;
DROP TABLE public.song_artists;
DROP TABLE public.profiles;
DROP TABLE public.podcasts;
DROP TABLE public.podcast_listens;
DROP TABLE public.podcast_favorites;
DROP TABLE public.podcast_channels;
DROP TABLE public.playlists;
DROP TABLE public.playlist_songs;
DROP TABLE public.moods;
DROP TABLE public.listens;
DROP TABLE public.home_sections;
DROP TABLE public.home_section_items;
DROP TABLE public.home_banners;
DROP TABLE public.hashtags;
DROP TABLE public.genres;
DROP TABLE public.favorites;
DROP TABLE public.channel_subscriptions;
DROP TABLE public.artists;
DROP TABLE public.albums;
DROP TABLE public.album_songs;
DROP TABLE public.album_artists;
DROP FUNCTION public.upsert_user_recent_item(p_user_id uuid, p_item_type text, p_item_key text, p_time timestamp with time zone, p_interaction_type text, p_source_screen text);
DROP FUNCTION public.unsubscribe_from_channel(p_channel_id uuid);
DROP FUNCTION public.unsubscribe_channel(p_channel_id uuid);
DROP FUNCTION public.unsave_playlist(p_playlist_id bigint);
DROP FUNCTION public.unlike_song(p_song_id bigint);
DROP FUNCTION public.unlike_podcast(p_podcast_id uuid);
DROP FUNCTION public.unfollow_artist(p_artist_id uuid);
DROP FUNCTION public.undislike_song(p_song_id bigint);
DROP FUNCTION public.undislike_artist(p_artist_id uuid);
DROP FUNCTION public.subscribe_to_channel(p_channel_id uuid);
DROP FUNCTION public.subscribe_channel(p_channel_id uuid);
DROP FUNCTION public.set_user_player_state(p_song_id bigint, p_playlist_id bigint, p_position_seconds integer, p_is_playing boolean, p_shuffle_enabled boolean, p_repeat_mode text);
DROP FUNCTION public.save_playlist(p_playlist_id bigint, p_source_screen text);
DROP FUNCTION public.rollover_all_artists_monthly_stats(p_reference_time timestamp with time zone);
DROP FUNCTION public.record_song_listen(p_song_id bigint, p_source_playlist_id bigint, p_source_screen text);
DROP FUNCTION public.record_search_keyword(p_keyword text, p_source_screen text);
DROP FUNCTION public.record_podcast_listen(p_podcast_id uuid);
DROP FUNCTION public.recalculate_playlist_song_count(p_playlist_id bigint);
DROP FUNCTION public.recalculate_artist_song_count(p_artist_id uuid);
DROP FUNCTION public.recalculate_artist_album_count(p_artist_id uuid);
DROP FUNCTION public.recalculate_album_track_cache(p_album_id bigint);
DROP FUNCTION public.mark_playlist_opened(p_playlist_id bigint, p_source_screen text);
DROP FUNCTION public.mark_liked_songs_opened(p_source_screen text);
DROP FUNCTION public.mark_hashtag_opened(p_hashtag_id bigint, p_source_screen text);
DROP FUNCTION public.mark_artist_opened(p_artist_id uuid, p_source_screen text);
DROP FUNCTION public.mark_album_opened(p_album_id bigint, p_source_screen text);
DROP FUNCTION public.like_song(p_song_id bigint, p_source_screen text);
DROP FUNCTION public.like_podcast(p_podcast_id uuid);
DROP FUNCTION public.handle_song_listen_after_insert();
DROP FUNCTION public.handle_song_artists_cache();
DROP FUNCTION public.handle_saved_playlists_cache();
DROP FUNCTION public.handle_recent_searches_trending();
DROP FUNCTION public.handle_podcast_listen_count();
DROP FUNCTION public.handle_playlist_songs_cache();
DROP FUNCTION public.handle_new_user();
DROP FUNCTION public.handle_followed_artists_cache();
DROP FUNCTION public.handle_favorites_like_count();
DROP FUNCTION public.handle_channel_subscription_count();
DROP FUNCTION public.handle_album_songs_cache();
DROP FUNCTION public.handle_album_artists_cache();
DROP FUNCTION public.follow_artist(p_artist_id uuid, p_source_screen text);
DROP FUNCTION public.ensure_artist_month_rollover(p_artist_id uuid, p_reference_time timestamp with time zone);
DROP FUNCTION public.dislike_song(p_song_id bigint, p_reason text);
DROP FUNCTION public.dislike_artist(p_artist_id uuid, p_reason text);
DROP FUNCTION public.clear_user_player_state();
DROP FUNCTION graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb);
DROP EXTENSION "uuid-ossp";
DROP EXTENSION supabase_vault;
DROP EXTENSION pgcrypto;
DROP EXTENSION pg_stat_statements;
DROP SCHEMA graphql_public;
--
-- Name: graphql_public; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA graphql_public;


ALTER SCHEMA graphql_public OWNER TO supabase_admin;

--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA extensions;


--
-- Name: EXTENSION pg_stat_statements; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_stat_statements IS 'track planning and execution statistics of all SQL statements executed';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA extensions;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: supabase_vault; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS supabase_vault WITH SCHEMA vault;


--
-- Name: EXTENSION supabase_vault; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION supabase_vault IS 'Supabase Vault Extension';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA extensions;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: graphql(text, text, jsonb, jsonb); Type: FUNCTION; Schema: graphql_public; Owner: supabase_admin
--

CREATE FUNCTION graphql_public.graphql("operationName" text DEFAULT NULL::text, query text DEFAULT NULL::text, variables jsonb DEFAULT NULL::jsonb, extensions jsonb DEFAULT NULL::jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
            DECLARE
                server_version float;
            BEGIN
                server_version = (SELECT (SPLIT_PART((select version()), ' ', 2))::float);

                IF server_version >= 14 THEN
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql extension is not enabled.'
                            )
                        )
                    );
                ELSE
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql is only available on projects running Postgres 14 onwards.'
                            )
                        )
                    );
                END IF;
            END;
        $$;


ALTER FUNCTION graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb) OWNER TO supabase_admin;

--
-- Name: clear_user_player_state(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.clear_user_player_state() RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  if auth.uid() is null then
    raise exception 'Bạn cần đăng nhập';
  end if;

  delete from public.user_player_state
  where user_id = auth.uid();
end;
$$;


ALTER FUNCTION public.clear_user_player_state() OWNER TO postgres;

--
-- Name: dislike_artist(uuid, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.dislike_artist(p_artist_id uuid, p_reason text DEFAULT NULL::text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  if auth.uid() is null then
    raise exception 'Bạn cần đăng nhập';
  end if;

  insert into public.user_disliked_artists(user_id, artist_id, reason)
  values (auth.uid(), p_artist_id, p_reason)
  on conflict (user_id, artist_id)
  do update set reason = excluded.reason;

  perform public.upsert_user_recent_item(auth.uid(), 'artist', p_artist_id::text, now(), 'dislike', 'artist');
end;
$$;


ALTER FUNCTION public.dislike_artist(p_artist_id uuid, p_reason text) OWNER TO postgres;

--
-- Name: dislike_song(bigint, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.dislike_song(p_song_id bigint, p_reason text DEFAULT NULL::text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  if auth.uid() is null then
    raise exception 'Bạn cần đăng nhập';
  end if;

  insert into public.user_disliked_songs(user_id, song_id, reason)
  values (auth.uid(), p_song_id, p_reason)
  on conflict (user_id, song_id)
  do update set reason = excluded.reason;

  perform public.upsert_user_recent_item(auth.uid(), 'song', p_song_id::text, now(), 'dislike', 'player');
end;
$$;


ALTER FUNCTION public.dislike_song(p_song_id bigint, p_reason text) OWNER TO postgres;

--
-- Name: ensure_artist_month_rollover(uuid, timestamp with time zone); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.ensure_artist_month_rollover(p_artist_id uuid, p_reference_time timestamp with time zone DEFAULT now()) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
declare
  v_month_start date := date_trunc('month', p_reference_time)::date;
  v_previous_month date := (date_trunc('month', p_reference_time) - interval '1 month')::date;
begin
  update public.artists
  set
    monthly_listeners_previous =
      case
        when monthly_current_month <> v_month_start then
          case
            when monthly_current_month = v_previous_month then monthly_listeners_current
            else 0
          end
        else monthly_listeners_previous
      end,
    monthly_previous_month =
      case
        when monthly_current_month <> v_month_start then v_previous_month
        else monthly_previous_month
      end,
    monthly_listeners_current =
      case
        when monthly_current_month <> v_month_start then 0
        else monthly_listeners_current
      end,
    monthly_current_month =
      case
        when monthly_current_month <> v_month_start then v_month_start
        else monthly_current_month
      end,
    updated_at = now()
  where id = p_artist_id;
end;
$$;


ALTER FUNCTION public.ensure_artist_month_rollover(p_artist_id uuid, p_reference_time timestamp with time zone) OWNER TO postgres;

--
-- Name: follow_artist(uuid, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.follow_artist(p_artist_id uuid, p_source_screen text DEFAULT 'artist'::text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  if auth.uid() is null then
    raise exception 'Bạn cần đăng nhập để theo dõi nghệ sĩ';
  end if;

  if not exists (select 1 from public.artists where id = p_artist_id) then
    raise exception 'Nghệ sĩ không tồn tại';
  end if;

  insert into public.user_followed_artists(user_id, artist_id)
  values (auth.uid(), p_artist_id)
  on conflict (user_id, artist_id) do nothing;

  perform public.upsert_user_recent_item(auth.uid(), 'artist', p_artist_id::text, now(), 'follow', p_source_screen);
end;
$$;


ALTER FUNCTION public.follow_artist(p_artist_id uuid, p_source_screen text) OWNER TO postgres;

--
-- Name: handle_album_artists_cache(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.handle_album_artists_cache() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  if tg_op = 'INSERT' then
    perform public.recalculate_artist_album_count(new.artist_id);
    return new;
  elsif tg_op = 'DELETE' then
    perform public.recalculate_artist_album_count(old.artist_id);
    return old;
  elsif tg_op = 'UPDATE' then
    perform public.recalculate_artist_album_count(old.artist_id);
    perform public.recalculate_artist_album_count(new.artist_id);
    return new;
  end if;
  return null;
end;
$$;


ALTER FUNCTION public.handle_album_artists_cache() OWNER TO postgres;

--
-- Name: handle_album_songs_cache(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.handle_album_songs_cache() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
declare
  v_release_date date;
begin
  if tg_op = 'INSERT' then
    select release_date into v_release_date
    from public.albums
    where id = new.album_id;

    update public.songs
    set
      album_id = new.album_id,
      release_date = coalesce(release_date, v_release_date)
    where id = new.song_id;

    perform public.recalculate_album_track_cache(new.album_id);
    return new;
  elsif tg_op = 'DELETE' then
    update public.songs
    set album_id = null
    where id = old.song_id
      and album_id = old.album_id;

    perform public.recalculate_album_track_cache(old.album_id);
    return old;
  elsif tg_op = 'UPDATE' then
    if old.album_id <> new.album_id then
      update public.songs
      set album_id = new.album_id
      where id = new.song_id;

      perform public.recalculate_album_track_cache(old.album_id);
      perform public.recalculate_album_track_cache(new.album_id);
    else
      perform public.recalculate_album_track_cache(new.album_id);
    end if;

    return new;
  end if;
  return null;
end;
$$;


ALTER FUNCTION public.handle_album_songs_cache() OWNER TO postgres;

--
-- Name: handle_channel_subscription_count(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.handle_channel_subscription_count() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
begin
  if tg_op = 'INSERT' then
    update public.podcast_channels
    set subscriber_count = subscriber_count + 1
    where id = new.channel_id;
    return new;
  elsif tg_op = 'DELETE' then
    update public.podcast_channels
    set subscriber_count = greatest(subscriber_count - 1, 0)
    where id = old.channel_id;
    return old;
  end if;
  return null;
end;
$$;


ALTER FUNCTION public.handle_channel_subscription_count() OWNER TO postgres;

--
-- Name: handle_favorites_like_count(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.handle_favorites_like_count() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  if tg_op = 'INSERT' then
    update public.songs
    set like_count_cache = like_count_cache + 1
    where id = new.song_id;

    perform public.upsert_user_recent_item(new.user_id, 'song', new.song_id::text, new.created_at, 'like', 'player');
    return new;
  elsif tg_op = 'DELETE' then
    update public.songs
    set like_count_cache = greatest(like_count_cache - 1, 0)
    where id = old.song_id;
    return old;
  end if;
  return null;
end;
$$;


ALTER FUNCTION public.handle_favorites_like_count() OWNER TO postgres;

--
-- Name: handle_followed_artists_cache(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.handle_followed_artists_cache() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  if tg_op = 'INSERT' then
    update public.artists
    set
      followers_count_cache = followers_count_cache + 1,
      updated_at = now()
    where id = new.artist_id;

    insert into public.user_preferred_artists(user_id, artist_id, score, updated_at)
    values (new.user_id, new.artist_id, 10, now())
    on conflict (user_id, artist_id)
    do update set
      score = public.user_preferred_artists.score + 10,
      updated_at = now();

    return new;
  elsif tg_op = 'DELETE' then
    update public.artists
    set
      followers_count_cache = greatest(followers_count_cache - 1, 0),
      updated_at = now()
    where id = old.artist_id;

    update public.user_preferred_artists
    set
      score = greatest(score - 10, 0),
      updated_at = now()
    where user_id = old.user_id
      and artist_id = old.artist_id;

    return old;
  end if;
  return null;
end;
$$;


ALTER FUNCTION public.handle_followed_artists_cache() OWNER TO postgres;

--
-- Name: handle_new_user(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.handle_new_user() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  insert into public.profiles (id, email, display_name)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data->>'display_name', split_part(new.email, '@', 1))
  )
  on conflict (id) do nothing;

  return new;
end;
$$;


ALTER FUNCTION public.handle_new_user() OWNER TO postgres;

--
-- Name: handle_playlist_songs_cache(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.handle_playlist_songs_cache() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  if tg_op = 'INSERT' then
    perform public.recalculate_playlist_song_count(new.playlist_id);
    return new;
  elsif tg_op = 'DELETE' then
    perform public.recalculate_playlist_song_count(old.playlist_id);
    return old;
  elsif tg_op = 'UPDATE' then
    perform public.recalculate_playlist_song_count(old.playlist_id);
    perform public.recalculate_playlist_song_count(new.playlist_id);
    return new;
  end if;
  return null;
end;
$$;


ALTER FUNCTION public.handle_playlist_songs_cache() OWNER TO postgres;

--
-- Name: handle_podcast_listen_count(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.handle_podcast_listen_count() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
begin
  update public.podcasts
  set listen_count = listen_count + 1
  where id = new.podcast_id;
  return new;
end;
$$;


ALTER FUNCTION public.handle_podcast_listen_count() OWNER TO postgres;

--
-- Name: handle_recent_searches_trending(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.handle_recent_searches_trending() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  insert into public.trending_search_keywords(keyword, score, updated_at)
  values (new.keyword, 1, now())
  on conflict (keyword)
  do update set
    score = public.trending_search_keywords.score + 1,
    updated_at = now();

  return new;
end;
$$;


ALTER FUNCTION public.handle_recent_searches_trending() OWNER TO postgres;

--
-- Name: handle_saved_playlists_cache(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.handle_saved_playlists_cache() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  if tg_op = 'INSERT' then
    update public.playlists
    set saves_count_cache = saves_count_cache + 1
    where id = new.playlist_id;
    return new;
  elsif tg_op = 'DELETE' then
    update public.playlists
    set saves_count_cache = greatest(saves_count_cache - 1, 0)
    where id = old.playlist_id;
    return old;
  end if;
  return null;
end;
$$;


ALTER FUNCTION public.handle_saved_playlists_cache() OWNER TO postgres;

--
-- Name: handle_song_artists_cache(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.handle_song_artists_cache() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  if tg_op = 'INSERT' then
    perform public.recalculate_artist_song_count(new.artist_id);
    return new;
  elsif tg_op = 'DELETE' then
    perform public.recalculate_artist_song_count(old.artist_id);
    return old;
  elsif tg_op = 'UPDATE' then
    perform public.recalculate_artist_song_count(old.artist_id);
    perform public.recalculate_artist_song_count(new.artist_id);
    return new;
  end if;
  return null;
end;
$$;


ALTER FUNCTION public.handle_song_artists_cache() OWNER TO postgres;

--
-- Name: handle_song_listen_after_insert(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.handle_song_listen_after_insert() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
declare
  v_artist_id uuid;
  v_genre_id bigint;
begin
  update public.songs
  set total_listens = total_listens + 1
  where id = new.song_id;

  if new.source_playlist_id is not null then
    update public.playlists
    set total_listens_cache = total_listens_cache + 1
    where id = new.source_playlist_id;
  end if;

  for v_artist_id in
    select sa.artist_id
    from public.song_artists sa
    where sa.song_id = new.song_id
  loop
    perform public.ensure_artist_month_rollover(v_artist_id, new.listened_at);

    update public.artists
    set
      monthly_listeners_current = monthly_listeners_current + 1,
      updated_at = now()
    where id = v_artist_id;

    insert into public.user_preferred_artists(user_id, artist_id, score, updated_at)
    values (new.user_id, v_artist_id, 1, now())
    on conflict (user_id, artist_id)
    do update set
      score = public.user_preferred_artists.score + 1,
      updated_at = now();
  end loop;

  for v_genre_id in
    select sg.genre_id
    from public.song_genres sg
    where sg.song_id = new.song_id
  loop
    insert into public.user_preferred_genres(user_id, genre_id, score, updated_at)
    values (new.user_id, v_genre_id, 1, now())
    on conflict (user_id, genre_id)
    do update set
      score = public.user_preferred_genres.score + 1,
      updated_at = now();
  end loop;

  perform public.upsert_user_recent_item(new.user_id, 'song', new.song_id::text, new.listened_at, 'play', new.source_screen);

  if new.source_playlist_id is not null then
    perform public.upsert_user_recent_item(new.user_id, 'playlist', new.source_playlist_id::text, new.listened_at, 'play', new.source_screen);
  end if;

  return new;
end;
$$;


ALTER FUNCTION public.handle_song_listen_after_insert() OWNER TO postgres;

--
-- Name: like_podcast(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.like_podcast(p_podcast_id uuid) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  if auth.uid() is null then
    raise exception 'Bạn cần đăng nhập để thích podcast';
  end if;

  insert into public.podcast_favorites(user_id, podcast_id)
  values (auth.uid(), p_podcast_id)
  on conflict (user_id, podcast_id) do nothing;
end;
$$;


ALTER FUNCTION public.like_podcast(p_podcast_id uuid) OWNER TO postgres;

--
-- Name: like_song(bigint, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.like_song(p_song_id bigint, p_source_screen text DEFAULT 'player'::text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  if auth.uid() is null then
    raise exception 'Bạn cần đăng nhập để thích bài hát';
  end if;

  if not exists (select 1 from public.songs where id = p_song_id and is_active = true) then
    raise exception 'Bài hát không tồn tại';
  end if;

  insert into public.favorites(user_id, song_id)
  values (auth.uid(), p_song_id)
  on conflict (user_id, song_id) do nothing;

  perform public.upsert_user_recent_item(auth.uid(), 'song', p_song_id::text, now(), 'like', p_source_screen);
end;
$$;


ALTER FUNCTION public.like_song(p_song_id bigint, p_source_screen text) OWNER TO postgres;

--
-- Name: mark_album_opened(bigint, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.mark_album_opened(p_album_id bigint, p_source_screen text DEFAULT 'home'::text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  if auth.uid() is null then
    raise exception 'Bạn cần đăng nhập';
  end if;

  if not exists (select 1 from public.albums where id = p_album_id and is_active = true) then
    raise exception 'Album không tồn tại';
  end if;

  perform public.upsert_user_recent_item(auth.uid(), 'album', p_album_id::text, now(), 'open', p_source_screen);
end;
$$;


ALTER FUNCTION public.mark_album_opened(p_album_id bigint, p_source_screen text) OWNER TO postgres;

--
-- Name: mark_artist_opened(uuid, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.mark_artist_opened(p_artist_id uuid, p_source_screen text DEFAULT 'search'::text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  if auth.uid() is null then
    raise exception 'Bạn cần đăng nhập';
  end if;

  if not exists (select 1 from public.artists where id = p_artist_id) then
    raise exception 'Nghệ sĩ không tồn tại';
  end if;

  perform public.upsert_user_recent_item(auth.uid(), 'artist', p_artist_id::text, now(), 'open', p_source_screen);
end;
$$;


ALTER FUNCTION public.mark_artist_opened(p_artist_id uuid, p_source_screen text) OWNER TO postgres;

--
-- Name: mark_hashtag_opened(bigint, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.mark_hashtag_opened(p_hashtag_id bigint, p_source_screen text DEFAULT 'search'::text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  if auth.uid() is null then
    raise exception 'Bạn cần đăng nhập';
  end if;

  if not exists (select 1 from public.hashtags where id = p_hashtag_id and is_active = true) then
    raise exception 'Hashtag không tồn tại';
  end if;

  perform public.upsert_user_recent_item(auth.uid(), 'hashtag', p_hashtag_id::text, now(), 'open', p_source_screen);
end;
$$;


ALTER FUNCTION public.mark_hashtag_opened(p_hashtag_id bigint, p_source_screen text) OWNER TO postgres;

--
-- Name: mark_liked_songs_opened(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.mark_liked_songs_opened(p_source_screen text DEFAULT 'library'::text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  if auth.uid() is null then
    raise exception 'Bạn cần đăng nhập';
  end if;

  perform public.upsert_user_recent_item(auth.uid(), 'liked_songs', 'liked', now(), 'open', p_source_screen);
end;
$$;


ALTER FUNCTION public.mark_liked_songs_opened(p_source_screen text) OWNER TO postgres;

--
-- Name: mark_playlist_opened(bigint, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.mark_playlist_opened(p_playlist_id bigint, p_source_screen text DEFAULT 'library'::text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  if auth.uid() is null then
    raise exception 'Bạn cần đăng nhập';
  end if;

  if not exists (
    select 1
    from public.playlists p
    where p.id = p_playlist_id
      and (
        p.playlist_type = 'system'
        or p.is_public = true
        or p.user_id = auth.uid()
      )
  ) then
    raise exception 'Playlist không tồn tại hoặc bạn không có quyền truy cập';
  end if;

  perform public.upsert_user_recent_item(auth.uid(), 'playlist', p_playlist_id::text, now(), 'open', p_source_screen);
end;
$$;


ALTER FUNCTION public.mark_playlist_opened(p_playlist_id bigint, p_source_screen text) OWNER TO postgres;

--
-- Name: recalculate_album_track_cache(bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.recalculate_album_track_cache(p_album_id bigint) RETURNS void
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  update public.albums al
  set
    total_tracks_cache = (
      select count(*)::integer
      from public.album_songs als
      where als.album_id = p_album_id
    ),
    total_duration_seconds_cache = coalesce((
      select sum(s.duration_seconds)::integer
      from public.album_songs als
      join public.songs s on s.id = als.song_id
      where als.album_id = p_album_id
    ), 0)
  where al.id = p_album_id;
$$;


ALTER FUNCTION public.recalculate_album_track_cache(p_album_id bigint) OWNER TO postgres;

--
-- Name: recalculate_artist_album_count(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.recalculate_artist_album_count(p_artist_id uuid) RETURNS void
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  update public.artists a
  set
    albums_count_cache = (
      select count(*)::integer
      from public.album_artists aa
      where aa.artist_id = p_artist_id
    ),
    updated_at = now()
  where a.id = p_artist_id;
$$;


ALTER FUNCTION public.recalculate_artist_album_count(p_artist_id uuid) OWNER TO postgres;

--
-- Name: recalculate_artist_song_count(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.recalculate_artist_song_count(p_artist_id uuid) RETURNS void
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  update public.artists a
  set
    songs_count_cache = (
      select count(*)::integer
      from public.song_artists sa
      where sa.artist_id = p_artist_id
    ),
    updated_at = now()
  where a.id = p_artist_id;
$$;


ALTER FUNCTION public.recalculate_artist_song_count(p_artist_id uuid) OWNER TO postgres;

--
-- Name: recalculate_playlist_song_count(bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.recalculate_playlist_song_count(p_playlist_id bigint) RETURNS void
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  update public.playlists p
  set songs_count_cache = (
    select count(*)::integer
    from public.playlist_songs ps
    where ps.playlist_id = p_playlist_id
  )
  where p.id = p_playlist_id;
$$;


ALTER FUNCTION public.recalculate_playlist_song_count(p_playlist_id bigint) OWNER TO postgres;

--
-- Name: record_podcast_listen(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.record_podcast_listen(p_podcast_id uuid) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  insert into public.podcast_listens(podcast_id, user_id)
  values (p_podcast_id, auth.uid());
end;
$$;


ALTER FUNCTION public.record_podcast_listen(p_podcast_id uuid) OWNER TO postgres;

--
-- Name: record_search_keyword(text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.record_search_keyword(p_keyword text, p_source_screen text DEFAULT 'search'::text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
declare
  v_keyword text := btrim(coalesce(p_keyword, ''));
begin
  if auth.uid() is null then
    raise exception 'Bạn cần đăng nhập để lưu lịch sử tìm kiếm';
  end if;

  if v_keyword = '' then
    return;
  end if;

  insert into public.user_recent_searches(user_id, keyword, searched_at)
  values (auth.uid(), v_keyword, now())
  on conflict (user_id, keyword)
  do update set searched_at = excluded.searched_at;

  perform public.upsert_user_recent_item(auth.uid(), 'search', lower(v_keyword), now(), 'search', p_source_screen);
end;
$$;


ALTER FUNCTION public.record_search_keyword(p_keyword text, p_source_screen text) OWNER TO postgres;

--
-- Name: record_song_listen(bigint, bigint, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.record_song_listen(p_song_id bigint, p_source_playlist_id bigint DEFAULT NULL::bigint, p_source_screen text DEFAULT 'player'::text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  if auth.uid() is null then
    raise exception 'Bạn cần đăng nhập để ghi nhận lượt nghe bài hát';
  end if;

  if not exists (
    select 1
    from public.songs s
    where s.id = p_song_id
      and s.is_active = true
  ) then
    raise exception 'Bài hát không tồn tại hoặc đang bị khóa';
  end if;

  if p_source_playlist_id is not null and not exists (
    select 1
    from public.playlists p
    where p.id = p_source_playlist_id
  ) then
    raise exception 'Playlist nguồn không tồn tại';
  end if;

  insert into public.song_listens(song_id, user_id, source_playlist_id, source_screen)
  values (p_song_id, auth.uid(), p_source_playlist_id, coalesce(p_source_screen, 'player'));
end;
$$;


ALTER FUNCTION public.record_song_listen(p_song_id bigint, p_source_playlist_id bigint, p_source_screen text) OWNER TO postgres;

--
-- Name: rollover_all_artists_monthly_stats(timestamp with time zone); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.rollover_all_artists_monthly_stats(p_reference_time timestamp with time zone DEFAULT now()) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
declare
  v_month_start date := date_trunc('month', p_reference_time)::date;
  v_previous_month date := (date_trunc('month', p_reference_time) - interval '1 month')::date;
begin
  update public.artists
  set
    monthly_listeners_previous =
      case
        when monthly_current_month = v_previous_month then monthly_listeners_current
        else 0
      end,
    monthly_previous_month = v_previous_month,
    monthly_listeners_current = 0,
    monthly_current_month = v_month_start,
    updated_at = now()
  where monthly_current_month <> v_month_start;
end;
$$;


ALTER FUNCTION public.rollover_all_artists_monthly_stats(p_reference_time timestamp with time zone) OWNER TO postgres;

--
-- Name: save_playlist(bigint, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.save_playlist(p_playlist_id bigint, p_source_screen text DEFAULT 'playlist'::text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  if auth.uid() is null then
    raise exception 'Bạn cần đăng nhập để lưu playlist';
  end if;

  if not exists (
    select 1
    from public.playlists p
    where p.id = p_playlist_id
      and (
        p.playlist_type = 'system'
        or p.is_public = true
        or p.user_id = auth.uid()
      )
  ) then
    raise exception 'Playlist không tồn tại hoặc bạn không có quyền truy cập';
  end if;

  insert into public.user_saved_playlists(user_id, playlist_id)
  values (auth.uid(), p_playlist_id)
  on conflict (user_id, playlist_id) do nothing;

  perform public.upsert_user_recent_item(auth.uid(), 'playlist', p_playlist_id::text, now(), 'save', p_source_screen);
end;
$$;


ALTER FUNCTION public.save_playlist(p_playlist_id bigint, p_source_screen text) OWNER TO postgres;

--
-- Name: set_user_player_state(bigint, bigint, integer, boolean, boolean, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.set_user_player_state(p_song_id bigint, p_playlist_id bigint DEFAULT NULL::bigint, p_position_seconds integer DEFAULT 0, p_is_playing boolean DEFAULT true, p_shuffle_enabled boolean DEFAULT false, p_repeat_mode text DEFAULT 'off'::text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  if auth.uid() is null then
    raise exception 'Bạn cần đăng nhập';
  end if;

  if p_song_id is not null and not exists (
    select 1 from public.songs where id = p_song_id and is_active = true
  ) then
    raise exception 'Bài hát không tồn tại';
  end if;

  if p_playlist_id is not null and not exists (
    select 1 from public.playlists where id = p_playlist_id
  ) then
    raise exception 'Playlist không tồn tại';
  end if;

  if p_repeat_mode not in ('off', 'one', 'all') then
    raise exception 'repeat_mode không hợp lệ';
  end if;

  insert into public.user_player_state(
    user_id,
    current_song_id,
    current_playlist_id,
    position_seconds,
    is_playing,
    shuffle_enabled,
    repeat_mode,
    updated_at
  )
  values (
    auth.uid(),
    p_song_id,
    p_playlist_id,
    greatest(coalesce(p_position_seconds, 0), 0),
    coalesce(p_is_playing, true),
    coalesce(p_shuffle_enabled, false),
    coalesce(p_repeat_mode, 'off'),
    now()
  )
  on conflict (user_id)
  do update set
    current_song_id = excluded.current_song_id,
    current_playlist_id = excluded.current_playlist_id,
    position_seconds = excluded.position_seconds,
    is_playing = excluded.is_playing,
    shuffle_enabled = excluded.shuffle_enabled,
    repeat_mode = excluded.repeat_mode,
    updated_at = excluded.updated_at;
end;
$$;


ALTER FUNCTION public.set_user_player_state(p_song_id bigint, p_playlist_id bigint, p_position_seconds integer, p_is_playing boolean, p_shuffle_enabled boolean, p_repeat_mode text) OWNER TO postgres;

--
-- Name: subscribe_channel(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.subscribe_channel(p_channel_id uuid) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  if auth.uid() is null then
    raise exception 'Bạn cần đăng nhập để theo dõi kênh';
  end if;

  insert into public.channel_subscriptions(user_id, channel_id)
  values (auth.uid(), p_channel_id)
  on conflict (user_id, channel_id) do nothing;
end;
$$;


ALTER FUNCTION public.subscribe_channel(p_channel_id uuid) OWNER TO postgres;

--
-- Name: subscribe_to_channel(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.subscribe_to_channel(p_channel_id uuid) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  if auth.uid() is null then
    raise exception 'Bạn cần đăng nhập để đăng ký channel';
  end if;

  insert into public.channel_subscriptions(user_id, channel_id)
  values (auth.uid(), p_channel_id)
  on conflict (user_id, channel_id) do nothing;
end;
$$;


ALTER FUNCTION public.subscribe_to_channel(p_channel_id uuid) OWNER TO postgres;

--
-- Name: undislike_artist(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.undislike_artist(p_artist_id uuid) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  if auth.uid() is null then
    raise exception 'Bạn cần đăng nhập';
  end if;

  delete from public.user_disliked_artists
  where user_id = auth.uid()
    and artist_id = p_artist_id;
end;
$$;


ALTER FUNCTION public.undislike_artist(p_artist_id uuid) OWNER TO postgres;

--
-- Name: undislike_song(bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.undislike_song(p_song_id bigint) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  if auth.uid() is null then
    raise exception 'Bạn cần đăng nhập';
  end if;

  delete from public.user_disliked_songs
  where user_id = auth.uid()
    and song_id = p_song_id;
end;
$$;


ALTER FUNCTION public.undislike_song(p_song_id bigint) OWNER TO postgres;

--
-- Name: unfollow_artist(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.unfollow_artist(p_artist_id uuid) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  if auth.uid() is null then
    raise exception 'Bạn cần đăng nhập để bỏ theo dõi nghệ sĩ';
  end if;

  delete from public.user_followed_artists
  where user_id = auth.uid()
    and artist_id = p_artist_id;
end;
$$;


ALTER FUNCTION public.unfollow_artist(p_artist_id uuid) OWNER TO postgres;

--
-- Name: unlike_podcast(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.unlike_podcast(p_podcast_id uuid) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  if auth.uid() is null then
    raise exception 'Bạn cần đăng nhập';
  end if;

  delete from public.podcast_favorites
  where user_id = auth.uid()
    and podcast_id = p_podcast_id;
end;
$$;


ALTER FUNCTION public.unlike_podcast(p_podcast_id uuid) OWNER TO postgres;

--
-- Name: unlike_song(bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.unlike_song(p_song_id bigint) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  if auth.uid() is null then
    raise exception 'Bạn cần đăng nhập';
  end if;

  delete from public.favorites
  where user_id = auth.uid()
    and song_id = p_song_id;
end;
$$;


ALTER FUNCTION public.unlike_song(p_song_id bigint) OWNER TO postgres;

--
-- Name: unsave_playlist(bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.unsave_playlist(p_playlist_id bigint) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  if auth.uid() is null then
    raise exception 'Bạn cần đăng nhập để bỏ lưu playlist';
  end if;

  delete from public.user_saved_playlists
  where user_id = auth.uid()
    and playlist_id = p_playlist_id;
end;
$$;


ALTER FUNCTION public.unsave_playlist(p_playlist_id bigint) OWNER TO postgres;

--
-- Name: unsubscribe_channel(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.unsubscribe_channel(p_channel_id uuid) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  if auth.uid() is null then
    raise exception 'Bạn cần đăng nhập';
  end if;

  delete from public.channel_subscriptions
  where user_id = auth.uid()
    and channel_id = p_channel_id;
end;
$$;


ALTER FUNCTION public.unsubscribe_channel(p_channel_id uuid) OWNER TO postgres;

--
-- Name: unsubscribe_from_channel(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.unsubscribe_from_channel(p_channel_id uuid) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  if auth.uid() is null then
    raise exception 'Bạn cần đăng nhập để hủy đăng ký channel';
  end if;

  delete from public.channel_subscriptions
  where user_id = auth.uid()
    and channel_id = p_channel_id;
end;
$$;


ALTER FUNCTION public.unsubscribe_from_channel(p_channel_id uuid) OWNER TO postgres;

--
-- Name: upsert_user_recent_item(uuid, text, text, timestamp with time zone, text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.upsert_user_recent_item(p_user_id uuid, p_item_type text, p_item_key text, p_time timestamp with time zone DEFAULT now(), p_interaction_type text DEFAULT 'open'::text, p_source_screen text DEFAULT 'unknown'::text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  if p_user_id is null then
    return;
  end if;

  insert into public.user_recent_items (
    user_id,
    item_type,
    item_key,
    interaction_type,
    source_screen,
    last_interacted_at
  )
  values (
    p_user_id,
    p_item_type,
    p_item_key,
    p_interaction_type,
    p_source_screen,
    p_time
  )
  on conflict (user_id, item_type, item_key)
  do update set
    interaction_type = excluded.interaction_type,
    source_screen = excluded.source_screen,
    last_interacted_at = excluded.last_interacted_at;
end;
$$;


ALTER FUNCTION public.upsert_user_recent_item(p_user_id uuid, p_item_type text, p_item_key text, p_time timestamp with time zone, p_interaction_type text, p_source_screen text) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: album_artists; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.album_artists (
    album_id bigint NOT NULL,
    artist_id uuid NOT NULL,
    artist_order integer DEFAULT 1 NOT NULL,
    role text DEFAULT 'primary'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.album_artists OWNER TO postgres;

--
-- Name: album_songs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.album_songs (
    album_id bigint NOT NULL,
    song_id bigint NOT NULL,
    track_number integer DEFAULT 1 NOT NULL,
    disc_number integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.album_songs OWNER TO postgres;

--
-- Name: albums; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.albums (
    id bigint NOT NULL,
    external_id text,
    title text NOT NULL,
    cover_file text,
    cover_url text,
    description text,
    release_date date,
    album_type text DEFAULT 'album'::text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    total_tracks_cache integer DEFAULT 0 NOT NULL,
    total_duration_seconds_cache integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT albums_album_type_check CHECK ((album_type = ANY (ARRAY['album'::text, 'ep'::text, 'single'::text, 'compilation'::text]))),
    CONSTRAINT albums_total_duration_seconds_cache_check CHECK ((total_duration_seconds_cache >= 0)),
    CONSTRAINT albums_total_tracks_cache_check CHECK ((total_tracks_cache >= 0))
);


ALTER TABLE public.albums OWNER TO postgres;

--
-- Name: albums_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.albums ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.albums_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: artists; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.artists (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    avatar_file text,
    avatar_url text,
    cover_url text,
    bio text,
    verified boolean DEFAULT false NOT NULL,
    country text,
    debut_year integer,
    followers_count_cache integer DEFAULT 0 NOT NULL,
    songs_count_cache integer DEFAULT 0 NOT NULL,
    albums_count_cache integer DEFAULT 0 NOT NULL,
    monthly_listeners_previous integer DEFAULT 0 NOT NULL,
    monthly_listeners_current integer DEFAULT 0 NOT NULL,
    monthly_previous_month date,
    monthly_current_month date DEFAULT (date_trunc('month'::text, now()))::date NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    user_id uuid
);


ALTER TABLE public.artists OWNER TO postgres;

--
-- Name: channel_subscriptions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.channel_subscriptions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    channel_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.channel_subscriptions OWNER TO postgres;

--
-- Name: favorites; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.favorites (
    id bigint NOT NULL,
    user_id uuid NOT NULL,
    song_id bigint NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.favorites OWNER TO postgres;

--
-- Name: favorites_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.favorites ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.favorites_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: genres; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.genres (
    id bigint NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    description text,
    cover_url text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.genres OWNER TO postgres;

--
-- Name: genres_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.genres ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.genres_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: hashtags; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.hashtags (
    id bigint NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    description text,
    cover_url text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT hashtags_name_starts_with_hash CHECK (("left"(name, 1) = '#'::text)),
    CONSTRAINT hashtags_slug_no_hash CHECK (("left"(slug, 1) <> '#'::text))
);


ALTER TABLE public.hashtags OWNER TO postgres;

--
-- Name: hashtags_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.hashtags ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.hashtags_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: home_banners; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.home_banners (
    id bigint NOT NULL,
    title text NOT NULL,
    subtitle text,
    image_url text,
    action_type text NOT NULL,
    action_value text NOT NULL,
    display_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    starts_at timestamp with time zone,
    ends_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT home_banners_action_type_check CHECK ((action_type = ANY (ARRAY['playlist'::text, 'artist'::text, 'song'::text, 'album'::text, 'hashtag'::text, 'url'::text, 'search'::text])))
);


ALTER TABLE public.home_banners OWNER TO postgres;

--
-- Name: home_banners_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.home_banners ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.home_banners_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: home_section_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.home_section_items (
    id bigint NOT NULL,
    section_id bigint NOT NULL,
    item_type text NOT NULL,
    item_key text NOT NULL,
    display_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT home_section_items_item_type_check CHECK ((item_type = ANY (ARRAY['song'::text, 'playlist'::text, 'artist'::text, 'album'::text, 'hashtag'::text, 'genre'::text, 'mood'::text])))
);


ALTER TABLE public.home_section_items OWNER TO postgres;

--
-- Name: home_section_items_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.home_section_items ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.home_section_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: home_sections; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.home_sections (
    id bigint NOT NULL,
    code text NOT NULL,
    title text NOT NULL,
    subtitle text,
    section_type text DEFAULT 'manual'::text NOT NULL,
    display_order integer DEFAULT 0 NOT NULL,
    item_limit integer DEFAULT 10 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT home_sections_item_limit_check CHECK ((item_limit > 0)),
    CONSTRAINT home_sections_section_type_check CHECK ((section_type = ANY (ARRAY['manual'::text, 'recent'::text, 'personalized'::text, 'trending'::text, 'hashtag'::text, 'playlist'::text, 'artist'::text, 'album'::text, 'genre'::text, 'mood'::text, 'search'::text])))
);


ALTER TABLE public.home_sections OWNER TO postgres;

--
-- Name: home_sections_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.home_sections ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.home_sections_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: listens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.listens (
    id bigint NOT NULL,
    user_id uuid,
    song_id bigint,
    podcast_id uuid,
    listened_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.listens OWNER TO postgres;

--
-- Name: listens_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.listens ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.listens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: moods; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.moods (
    id bigint NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    description text,
    cover_url text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.moods OWNER TO postgres;

--
-- Name: moods_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.moods ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.moods_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: playlist_songs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.playlist_songs (
    id bigint NOT NULL,
    playlist_id bigint NOT NULL,
    song_id bigint NOT NULL,
    "position" integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.playlist_songs OWNER TO postgres;

--
-- Name: playlist_songs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.playlist_songs ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.playlist_songs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: playlists; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.playlists (
    id bigint NOT NULL,
    user_id uuid,
    name text NOT NULL,
    description text,
    cover_url text,
    playlist_type text DEFAULT 'user'::text NOT NULL,
    is_system boolean DEFAULT false NOT NULL,
    is_public boolean DEFAULT false NOT NULL,
    songs_count_cache integer DEFAULT 0 NOT NULL,
    saves_count_cache integer DEFAULT 0 NOT NULL,
    total_listens_cache integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT playlists_owner_or_system_chk CHECK ((((playlist_type = 'system'::text) AND (is_system = true) AND (user_id IS NULL)) OR ((playlist_type = 'user'::text) AND (is_system = false) AND (user_id IS NOT NULL)))),
    CONSTRAINT playlists_playlist_type_check CHECK ((playlist_type = ANY (ARRAY['system'::text, 'user'::text]))),
    CONSTRAINT playlists_saves_count_cache_check CHECK ((saves_count_cache >= 0)),
    CONSTRAINT playlists_songs_count_cache_check CHECK ((songs_count_cache >= 0)),
    CONSTRAINT playlists_total_listens_cache_check CHECK ((total_listens_cache >= 0))
);


ALTER TABLE public.playlists OWNER TO postgres;

--
-- Name: playlists_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.playlists ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.playlists_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: podcast_channels; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.podcast_channels (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    avatar_url text,
    subscriber_count integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT podcast_channels_subscriber_count_check CHECK ((subscriber_count >= 0))
);


ALTER TABLE public.podcast_channels OWNER TO postgres;

--
-- Name: podcast_favorites; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.podcast_favorites (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    podcast_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.podcast_favorites OWNER TO postgres;

--
-- Name: podcast_listens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.podcast_listens (
    id bigint NOT NULL,
    podcast_id uuid NOT NULL,
    user_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.podcast_listens OWNER TO postgres;

--
-- Name: podcast_listens_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.podcast_listens ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.podcast_listens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: podcasts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.podcasts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    external_id text,
    title text NOT NULL,
    channel_id uuid NOT NULL,
    audio_url text NOT NULL,
    cover_url text,
    lyrics_url text,
    duration_seconds integer DEFAULT 0 NOT NULL,
    listen_count integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT podcasts_duration_seconds_check CHECK ((duration_seconds >= 0)),
    CONSTRAINT podcasts_listen_count_check CHECK ((listen_count >= 0))
);


ALTER TABLE public.podcasts OWNER TO postgres;

--
-- Name: profiles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.profiles (
    id uuid NOT NULL,
    email text,
    display_name text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    avatar_url text,
    updated_at timestamp with time zone DEFAULT now(),
    is_artist boolean DEFAULT false,
    password text
);


ALTER TABLE public.profiles OWNER TO postgres;

--
-- Name: song_artists; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.song_artists (
    song_id bigint NOT NULL,
    artist_id uuid NOT NULL,
    artist_order integer DEFAULT 1 NOT NULL,
    role text DEFAULT 'primary'::text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.song_artists OWNER TO postgres;

--
-- Name: song_genres; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.song_genres (
    song_id bigint NOT NULL,
    genre_id bigint NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.song_genres OWNER TO postgres;

--
-- Name: song_hashtags; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.song_hashtags (
    id bigint NOT NULL,
    song_id bigint NOT NULL,
    hashtag_id bigint NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.song_hashtags OWNER TO postgres;

--
-- Name: song_hashtags_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.song_hashtags ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.song_hashtags_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: song_listens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.song_listens (
    id bigint NOT NULL,
    song_id bigint,
    user_id uuid NOT NULL,
    source_playlist_id bigint,
    source_screen text DEFAULT 'player'::text NOT NULL,
    listened_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.song_listens OWNER TO postgres;

--
-- Name: song_listens_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.song_listens ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.song_listens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: song_moods; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.song_moods (
    song_id bigint NOT NULL,
    mood_id bigint NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.song_moods OWNER TO postgres;

--
-- Name: songs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.songs (
    id bigint NOT NULL,
    external_id text,
    title text NOT NULL,
    artist text NOT NULL,
    album_id bigint,
    release_date date,
    cover_file text,
    cover_url text,
    audio_file text,
    audio_url text NOT NULL,
    lyrics_file text,
    lyrics_url text,
    duration_seconds integer DEFAULT 0,
    total_listens integer DEFAULT 0,
    like_count_cache integer DEFAULT 0,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.songs OWNER TO postgres;

--
-- Name: songs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.songs ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.songs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: trending_search_keywords; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.trending_search_keywords (
    id bigint NOT NULL,
    keyword text NOT NULL,
    score integer DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT trending_search_keywords_score_check CHECK ((score >= 0))
);


ALTER TABLE public.trending_search_keywords OWNER TO postgres;

--
-- Name: trending_search_keywords_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.trending_search_keywords ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.trending_search_keywords_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: user_disliked_artists; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_disliked_artists (
    user_id uuid NOT NULL,
    artist_id uuid NOT NULL,
    reason text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.user_disliked_artists OWNER TO postgres;

--
-- Name: user_disliked_songs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_disliked_songs (
    user_id uuid NOT NULL,
    song_id bigint NOT NULL,
    reason text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.user_disliked_songs OWNER TO postgres;

--
-- Name: user_followed_artists; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_followed_artists (
    id bigint NOT NULL,
    user_id uuid NOT NULL,
    artist_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.user_followed_artists OWNER TO postgres;

--
-- Name: user_followed_artists_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.user_followed_artists ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.user_followed_artists_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: user_player_state; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_player_state (
    user_id uuid NOT NULL,
    current_song_id bigint,
    current_playlist_id bigint,
    position_seconds integer DEFAULT 0 NOT NULL,
    is_playing boolean DEFAULT false NOT NULL,
    shuffle_enabled boolean DEFAULT false NOT NULL,
    repeat_mode text DEFAULT 'off'::text NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.user_player_state OWNER TO postgres;

--
-- Name: user_preferred_artists; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_preferred_artists (
    user_id uuid NOT NULL,
    artist_id uuid NOT NULL,
    score integer DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT user_preferred_artists_score_check CHECK ((score >= 0))
);


ALTER TABLE public.user_preferred_artists OWNER TO postgres;

--
-- Name: user_preferred_genres; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_preferred_genres (
    user_id uuid NOT NULL,
    genre_id bigint NOT NULL,
    score integer DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT user_preferred_genres_score_check CHECK ((score >= 0))
);


ALTER TABLE public.user_preferred_genres OWNER TO postgres;

--
-- Name: user_recent_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_recent_items (
    id bigint NOT NULL,
    user_id uuid NOT NULL,
    item_type text NOT NULL,
    item_key text NOT NULL,
    interaction_type text DEFAULT 'open'::text NOT NULL,
    source_screen text DEFAULT 'unknown'::text NOT NULL,
    last_interacted_at timestamp with time zone DEFAULT now() NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb,
    CONSTRAINT user_recent_items_interaction_type_check CHECK ((interaction_type = ANY (ARRAY['open'::text, 'play'::text, 'like'::text, 'save'::text, 'follow'::text, 'search'::text, 'dislike'::text]))),
    CONSTRAINT user_recent_items_item_type_check CHECK ((item_type = ANY (ARRAY['song'::text, 'playlist'::text, 'artist'::text, 'album'::text, 'liked_songs'::text, 'hashtag'::text, 'search'::text, 'podcast'::text])))
);


ALTER TABLE public.user_recent_items OWNER TO postgres;

--
-- Name: user_recent_items_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.user_recent_items ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.user_recent_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: user_recent_searches; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_recent_searches (
    id bigint NOT NULL,
    user_id uuid NOT NULL,
    keyword text NOT NULL,
    searched_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.user_recent_searches OWNER TO postgres;

--
-- Name: user_recent_searches_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.user_recent_searches ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.user_recent_searches_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: user_saved_playlists; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_saved_playlists (
    id bigint NOT NULL,
    user_id uuid NOT NULL,
    playlist_id bigint NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.user_saved_playlists OWNER TO postgres;

--
-- Name: user_saved_playlists_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.user_saved_playlists ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.user_saved_playlists_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: v_album_details_for_app; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.v_album_details_for_app WITH (security_invoker='true') AS
 SELECT al.id,
    al.external_id,
    al.title,
    al.cover_file,
    al.cover_url,
    al.description,
    al.release_date,
    al.album_type,
    al.is_active,
    al.total_tracks_cache,
    al.total_duration_seconds_cache,
    al.created_at,
    COALESCE(json_agg(DISTINCT jsonb_build_object('artist_id', a.id, 'name', a.name, 'avatar_url', a.avatar_url, 'artist_order', aa.artist_order, 'role', aa.role)) FILTER (WHERE (a.id IS NOT NULL)), '[]'::json) AS artists,
    COALESCE(json_agg(DISTINCT jsonb_build_object('song_id', s.id, 'external_id', s.external_id, 'title', s.title, 'artist', s.artist, 'cover_url', s.cover_url, 'audio_url', s.audio_url, 'lyrics_url', s.lyrics_url, 'duration_seconds', s.duration_seconds, 'track_number', als.track_number, 'disc_number', als.disc_number, 'release_date', s.release_date)) FILTER (WHERE (s.id IS NOT NULL)), '[]'::json) AS songs
   FROM ((((public.albums al
     LEFT JOIN public.album_artists aa ON ((aa.album_id = al.id)))
     LEFT JOIN public.artists a ON ((a.id = aa.artist_id)))
     LEFT JOIN public.album_songs als ON ((als.album_id = al.id)))
     LEFT JOIN public.songs s ON (((s.id = als.song_id) AND (s.is_active = true))))
  WHERE (al.is_active = true)
  GROUP BY al.id, al.external_id, al.title, al.cover_file, al.cover_url, al.description, al.release_date, al.album_type, al.is_active, al.total_tracks_cache, al.total_duration_seconds_cache, al.created_at;


ALTER VIEW public.v_album_details_for_app OWNER TO postgres;

--
-- Name: v_albums_for_app; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.v_albums_for_app WITH (security_invoker='true') AS
 SELECT al.id,
    al.external_id,
    al.title,
    al.cover_file,
    al.cover_url,
    al.description,
    al.release_date,
    al.album_type,
    al.is_active,
    al.total_tracks_cache,
    al.total_duration_seconds_cache,
    al.created_at,
    COALESCE(json_agg(json_build_object('artist_id', a.id, 'name', a.name, 'avatar_url', a.avatar_url, 'artist_order', aa.artist_order, 'role', aa.role) ORDER BY aa.artist_order) FILTER (WHERE (a.id IS NOT NULL)), '[]'::json) AS artists
   FROM ((public.albums al
     LEFT JOIN public.album_artists aa ON ((aa.album_id = al.id)))
     LEFT JOIN public.artists a ON ((a.id = aa.artist_id)))
  WHERE (al.is_active = true)
  GROUP BY al.id, al.external_id, al.title, al.cover_file, al.cover_url, al.description, al.release_date, al.album_type, al.is_active, al.total_tracks_cache, al.total_duration_seconds_cache, al.created_at;


ALTER VIEW public.v_albums_for_app OWNER TO postgres;

--
-- Name: v_artist_details_for_app; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.v_artist_details_for_app WITH (security_invoker='true') AS
 SELECT a.id,
    a.name,
    a.avatar_file,
    a.avatar_url,
    a.cover_url,
    a.bio,
    a.verified,
    a.country,
    a.debut_year,
    a.followers_count_cache,
    a.songs_count_cache,
    a.albums_count_cache,
    a.monthly_listeners_previous AS monthly_listeners,
    a.monthly_previous_month AS monthly_listeners_month,
    a.monthly_listeners_current,
    a.monthly_current_month,
    COALESCE(json_agg(DISTINCT jsonb_build_object('album_id', al.id, 'title', al.title, 'cover_url', al.cover_url, 'release_date', al.release_date, 'album_type', al.album_type)) FILTER (WHERE (al.id IS NOT NULL)), '[]'::json) AS albums,
    COALESCE(json_agg(DISTINCT jsonb_build_object('song_id', s.id, 'title', s.title, 'cover_url', s.cover_url, 'audio_url', s.audio_url, 'release_date', s.release_date, 'total_listens', s.total_listens)) FILTER (WHERE (s.id IS NOT NULL)), '[]'::json) AS songs
   FROM ((((public.artists a
     LEFT JOIN public.album_artists aa ON ((aa.artist_id = a.id)))
     LEFT JOIN public.albums al ON (((al.id = aa.album_id) AND (al.is_active = true))))
     LEFT JOIN public.song_artists sa ON ((sa.artist_id = a.id)))
     LEFT JOIN public.songs s ON (((s.id = sa.song_id) AND (s.is_active = true))))
  GROUP BY a.id, a.name, a.avatar_file, a.avatar_url, a.cover_url, a.bio, a.verified, a.country, a.debut_year, a.followers_count_cache, a.songs_count_cache, a.albums_count_cache, a.monthly_listeners_previous, a.monthly_previous_month, a.monthly_listeners_current, a.monthly_current_month;


ALTER VIEW public.v_artist_details_for_app OWNER TO postgres;

--
-- Name: v_artists_for_app; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.v_artists_for_app WITH (security_invoker='true') AS
 SELECT id,
    name,
    avatar_file,
    avatar_url,
    cover_url,
    bio,
    verified,
    country,
    debut_year,
    followers_count_cache,
    songs_count_cache,
    albums_count_cache,
    monthly_listeners_previous AS monthly_listeners,
    monthly_previous_month AS monthly_listeners_month,
    monthly_listeners_current,
    monthly_current_month,
    created_at,
    updated_at
   FROM public.artists a;


ALTER VIEW public.v_artists_for_app OWNER TO postgres;

--
-- Name: v_favorite_podcasts_for_app; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.v_favorite_podcasts_for_app WITH (security_invoker='true') AS
 SELECT pf.user_id,
    pf.created_at AS liked_at,
    p.id,
    p.external_id,
    p.title,
    p.audio_url,
    p.cover_url,
    p.lyrics_url,
    p.duration_seconds,
    p.listen_count,
    p.is_active,
    p.created_at,
    p.channel_id,
    pc.name AS channel_name,
    pc.avatar_url AS channel_avatar_url
   FROM ((public.podcast_favorites pf
     JOIN public.podcasts p ON ((p.id = pf.podcast_id)))
     JOIN public.podcast_channels pc ON ((pc.id = p.channel_id)));


ALTER VIEW public.v_favorite_podcasts_for_app OWNER TO postgres;

--
-- Name: v_genres_for_app; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.v_genres_for_app WITH (security_invoker='true') AS
 SELECT g.id,
    g.name,
    g.slug,
    g.description,
    g.cover_url,
    g.is_active,
    (count(sg.song_id))::integer AS total_songs,
    g.created_at
   FROM (public.genres g
     LEFT JOIN public.song_genres sg ON ((sg.genre_id = g.id)))
  WHERE (g.is_active = true)
  GROUP BY g.id, g.name, g.slug, g.description, g.cover_url, g.is_active, g.created_at;


ALTER VIEW public.v_genres_for_app OWNER TO postgres;

--
-- Name: v_hashtags_for_app; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.v_hashtags_for_app WITH (security_invoker='true') AS
 SELECT h.id,
    h.name,
    h.slug,
    h.description,
    h.cover_url,
    h.is_active,
    (count(sh.song_id))::integer AS total_songs,
    h.created_at,
    h.updated_at
   FROM (public.hashtags h
     LEFT JOIN public.song_hashtags sh ON ((sh.hashtag_id = h.id)))
  WHERE (h.is_active = true)
  GROUP BY h.id, h.name, h.slug, h.description, h.cover_url, h.is_active, h.created_at, h.updated_at;


ALTER VIEW public.v_hashtags_for_app OWNER TO postgres;

--
-- Name: v_home_banners_for_app; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.v_home_banners_for_app WITH (security_invoker='true') AS
 SELECT id,
    title,
    subtitle,
    image_url,
    action_type,
    action_value,
    display_order,
    starts_at,
    ends_at,
    is_active,
    created_at
   FROM public.home_banners hb
  WHERE ((is_active = true) AND ((starts_at IS NULL) OR (starts_at <= now())) AND ((ends_at IS NULL) OR (ends_at >= now())));


ALTER VIEW public.v_home_banners_for_app OWNER TO postgres;

--
-- Name: v_home_section_items_for_app; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.v_home_section_items_for_app WITH (security_invoker='true') AS
 SELECT hsi.id,
    hs.id AS section_id,
    hs.code AS section_code,
    hs.title AS section_title,
    hsi.item_type,
    hsi.item_key,
    hsi.display_order,
    hsi.is_active,
        CASE
            WHEN (hsi.item_type = 'playlist'::text) THEN p.name
            WHEN (hsi.item_type = 'artist'::text) THEN a.name
            WHEN (hsi.item_type = 'album'::text) THEN al.title
            WHEN (hsi.item_type = 'hashtag'::text) THEN h.name
            WHEN (hsi.item_type = 'genre'::text) THEN g.name
            WHEN (hsi.item_type = 'mood'::text) THEN m.name
            WHEN (hsi.item_type = 'song'::text) THEN s.title
            ELSE NULL::text
        END AS display_title,
        CASE
            WHEN (hsi.item_type = 'playlist'::text) THEN p.description
            WHEN (hsi.item_type = 'artist'::text) THEN a.bio
            WHEN (hsi.item_type = 'album'::text) THEN al.description
            WHEN (hsi.item_type = 'hashtag'::text) THEN h.description
            WHEN (hsi.item_type = 'genre'::text) THEN g.description
            WHEN (hsi.item_type = 'mood'::text) THEN m.description
            WHEN (hsi.item_type = 'song'::text) THEN s.artist
            ELSE NULL::text
        END AS display_subtitle,
        CASE
            WHEN (hsi.item_type = 'playlist'::text) THEN p.cover_url
            WHEN (hsi.item_type = 'artist'::text) THEN a.avatar_url
            WHEN (hsi.item_type = 'album'::text) THEN al.cover_url
            WHEN (hsi.item_type = 'hashtag'::text) THEN h.cover_url
            WHEN (hsi.item_type = 'genre'::text) THEN g.cover_url
            WHEN (hsi.item_type = 'mood'::text) THEN m.cover_url
            WHEN (hsi.item_type = 'song'::text) THEN s.cover_url
            ELSE NULL::text
        END AS image_url
   FROM ((((((((public.home_section_items hsi
     JOIN public.home_sections hs ON (((hs.id = hsi.section_id) AND (hs.is_active = true))))
     LEFT JOIN public.playlists p ON (((hsi.item_type = 'playlist'::text) AND ((p.id)::text = hsi.item_key))))
     LEFT JOIN public.artists a ON (((hsi.item_type = 'artist'::text) AND ((a.id)::text = hsi.item_key))))
     LEFT JOIN public.albums al ON (((hsi.item_type = 'album'::text) AND ((al.id)::text = hsi.item_key))))
     LEFT JOIN public.hashtags h ON (((hsi.item_type = 'hashtag'::text) AND ((h.id)::text = hsi.item_key))))
     LEFT JOIN public.genres g ON (((hsi.item_type = 'genre'::text) AND ((g.id)::text = hsi.item_key))))
     LEFT JOIN public.moods m ON (((hsi.item_type = 'mood'::text) AND ((m.id)::text = hsi.item_key))))
     LEFT JOIN public.songs s ON (((hsi.item_type = 'song'::text) AND ((s.id)::text = hsi.item_key))))
  WHERE (hsi.is_active = true);


ALTER VIEW public.v_home_section_items_for_app OWNER TO postgres;

--
-- Name: v_home_sections_for_app; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.v_home_sections_for_app WITH (security_invoker='true') AS
 SELECT id,
    code,
    title,
    subtitle,
    section_type,
    display_order,
    item_limit,
    is_active,
    created_at
   FROM public.home_sections hs
  WHERE (is_active = true);


ALTER VIEW public.v_home_sections_for_app OWNER TO postgres;

--
-- Name: v_library_playlists_for_app; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.v_library_playlists_for_app WITH (security_invoker='true') AS
 SELECT id,
    user_id,
    name,
    description,
    cover_url,
    playlist_type,
    is_system,
    is_public,
    songs_count_cache,
    saves_count_cache,
    total_listens_cache,
    created_at,
    (user_id = auth.uid()) AS is_owned,
    (EXISTS ( SELECT 1
           FROM public.user_saved_playlists usp
          WHERE ((usp.playlist_id = p.id) AND (usp.user_id = auth.uid())))) AS is_saved
   FROM public.playlists p
  WHERE ((playlist_type = 'system'::text) OR (is_public = true) OR (user_id = auth.uid()) OR (EXISTS ( SELECT 1
           FROM public.user_saved_playlists usp
          WHERE ((usp.playlist_id = p.id) AND (usp.user_id = auth.uid())))));


ALTER VIEW public.v_library_playlists_for_app OWNER TO postgres;

--
-- Name: v_moods_for_app; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.v_moods_for_app WITH (security_invoker='true') AS
 SELECT m.id,
    m.name,
    m.slug,
    m.description,
    m.cover_url,
    m.is_active,
    (count(sm.song_id))::integer AS total_songs,
    m.created_at
   FROM (public.moods m
     LEFT JOIN public.song_moods sm ON ((sm.mood_id = m.id)))
  WHERE (m.is_active = true)
  GROUP BY m.id, m.name, m.slug, m.description, m.cover_url, m.is_active, m.created_at;


ALTER VIEW public.v_moods_for_app OWNER TO postgres;

--
-- Name: v_player_state_for_app; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.v_player_state_for_app WITH (security_invoker='true') AS
 SELECT ups.user_id,
    ups.current_song_id,
    ups.current_playlist_id,
    ups.position_seconds,
    ups.is_playing,
    ups.shuffle_enabled,
    ups.repeat_mode,
    ups.updated_at,
    s.title AS current_song_title,
    s.artist AS current_song_artist,
    s.cover_url AS current_song_cover_url,
    p.name AS current_playlist_name,
    p.cover_url AS current_playlist_cover_url
   FROM ((public.user_player_state ups
     LEFT JOIN public.songs s ON ((s.id = ups.current_song_id)))
     LEFT JOIN public.playlists p ON ((p.id = ups.current_playlist_id)));


ALTER VIEW public.v_player_state_for_app OWNER TO postgres;

--
-- Name: v_podcasts; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.v_podcasts WITH (security_invoker='true') AS
 SELECT p.id,
    p.external_id,
    p.title,
    p.audio_url,
    p.cover_url,
    p.lyrics_url,
    p.duration_seconds,
    p.listen_count,
    p.is_active,
    p.created_at,
    ch.id AS channel_id,
    ch.name AS channel_name,
    ch.avatar_url AS channel_avatar_url,
    ch.subscriber_count
   FROM (public.podcasts p
     JOIN public.podcast_channels ch ON ((ch.id = p.channel_id)));


ALTER VIEW public.v_podcasts OWNER TO postgres;

--
-- Name: v_recent_items_for_app; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.v_recent_items_for_app WITH (security_invoker='true') AS
 SELECT id,
    user_id,
    item_type,
    item_key,
    interaction_type,
    source_screen,
    last_interacted_at
   FROM public.user_recent_items uri;


ALTER VIEW public.v_recent_items_for_app OWNER TO postgres;

--
-- Name: v_recent_searches_for_app; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.v_recent_searches_for_app WITH (security_invoker='true') AS
 SELECT id,
    user_id,
    keyword,
    searched_at
   FROM public.user_recent_searches urs;


ALTER VIEW public.v_recent_searches_for_app OWNER TO postgres;

--
-- Name: v_recent_song_history_for_app; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.v_recent_song_history_for_app WITH (security_invoker='true') AS
 SELECT sl.id,
    sl.user_id,
    sl.song_id,
    sl.source_playlist_id,
    sl.source_screen,
    sl.listened_at,
    s.title,
    s.artist,
    s.cover_url,
    s.audio_url,
    s.lyrics_url,
    s.album_id,
    s.release_date
   FROM (public.song_listens sl
     JOIN public.songs s ON ((s.id = sl.song_id)));


ALTER VIEW public.v_recent_song_history_for_app OWNER TO postgres;

--
-- Name: v_song_details; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.v_song_details WITH (security_invoker='true') AS
 SELECT id,
    '[]'::jsonb AS genres,
    '[]'::jsonb AS moods,
    '[]'::jsonb AS hashtags
   FROM public.songs s;


ALTER VIEW public.v_song_details OWNER TO postgres;

--
-- Name: v_songs_by_hashtag_for_app; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.v_songs_by_hashtag_for_app WITH (security_invoker='true') AS
 SELECT h.id AS hashtag_id,
    h.name AS hashtag_name,
    h.slug AS hashtag_slug,
    s.id AS song_id,
    s.external_id,
    s.title,
    s.artist,
    s.album_id,
    s.cover_url,
    s.audio_url,
    s.lyrics_url,
    s.release_date,
    s.duration_seconds,
    s.total_listens,
    s.like_count_cache,
    s.is_active,
    s.created_at
   FROM ((public.song_hashtags sh
     JOIN public.hashtags h ON (((h.id = sh.hashtag_id) AND (h.is_active = true))))
     JOIN public.songs s ON (((s.id = sh.song_id) AND (s.is_active = true))));


ALTER VIEW public.v_songs_by_hashtag_for_app OWNER TO postgres;

--
-- Name: v_songs_for_app; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.v_songs_for_app WITH (security_invoker='true') AS
 SELECT s.id,
    s.external_id,
    s.title,
    s.artist,
    s.album_id,
    al.title AS album_title,
    s.release_date,
    s.cover_file,
    s.cover_url,
    s.audio_file,
    s.audio_url,
    s.lyrics_file,
    s.lyrics_url,
    s.duration_seconds,
    s.total_listens,
    s.like_count_cache,
    s.is_active,
    s.created_at,
    COALESCE(json_agg(DISTINCT jsonb_build_object('genre_id', g.id, 'name', g.name, 'slug', g.slug)) FILTER (WHERE (g.id IS NOT NULL)), '[]'::json) AS genres,
    COALESCE(json_agg(DISTINCT jsonb_build_object('mood_id', m.id, 'name', m.name, 'slug', m.slug)) FILTER (WHERE (m.id IS NOT NULL)), '[]'::json) AS moods
   FROM (((((public.songs s
     LEFT JOIN public.albums al ON ((al.id = s.album_id)))
     LEFT JOIN public.song_genres sg ON ((sg.song_id = s.id)))
     LEFT JOIN public.genres g ON (((g.id = sg.genre_id) AND (g.is_active = true))))
     LEFT JOIN public.song_moods sm ON ((sm.song_id = s.id)))
     LEFT JOIN public.moods m ON (((m.id = sm.mood_id) AND (m.is_active = true))))
  GROUP BY s.id, s.external_id, s.title, s.artist, s.album_id, al.title, s.release_date, s.cover_file, s.cover_url, s.audio_file, s.audio_url, s.lyrics_file, s.lyrics_url, s.duration_seconds, s.total_listens, s.like_count_cache, s.is_active, s.created_at;


ALTER VIEW public.v_songs_for_app OWNER TO postgres;

--
-- Name: v_trending_search_keywords_for_app; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.v_trending_search_keywords_for_app WITH (security_invoker='true') AS
 SELECT id,
    keyword,
    score,
    updated_at
   FROM public.trending_search_keywords tsk;


ALTER VIEW public.v_trending_search_keywords_for_app OWNER TO postgres;

--
-- Name: album_artists album_artists_album_id_artist_order_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.album_artists
    ADD CONSTRAINT album_artists_album_id_artist_order_key UNIQUE (album_id, artist_order);


--
-- Name: album_artists album_artists_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.album_artists
    ADD CONSTRAINT album_artists_pkey PRIMARY KEY (album_id, artist_id);


--
-- Name: album_songs album_songs_album_id_disc_number_track_number_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.album_songs
    ADD CONSTRAINT album_songs_album_id_disc_number_track_number_key UNIQUE (album_id, disc_number, track_number);


--
-- Name: album_songs album_songs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.album_songs
    ADD CONSTRAINT album_songs_pkey PRIMARY KEY (album_id, song_id);


--
-- Name: album_songs album_songs_song_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.album_songs
    ADD CONSTRAINT album_songs_song_id_key UNIQUE (song_id);


--
-- Name: albums albums_external_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.albums
    ADD CONSTRAINT albums_external_id_key UNIQUE (external_id);


--
-- Name: albums albums_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.albums
    ADD CONSTRAINT albums_pkey PRIMARY KEY (id);


--
-- Name: artists artists_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.artists
    ADD CONSTRAINT artists_pkey PRIMARY KEY (id);


--
-- Name: channel_subscriptions channel_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.channel_subscriptions
    ADD CONSTRAINT channel_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: channel_subscriptions channel_subscriptions_user_id_channel_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.channel_subscriptions
    ADD CONSTRAINT channel_subscriptions_user_id_channel_id_key UNIQUE (user_id, channel_id);


--
-- Name: favorites favorites_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.favorites
    ADD CONSTRAINT favorites_pkey PRIMARY KEY (id);


--
-- Name: genres genres_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.genres
    ADD CONSTRAINT genres_name_key UNIQUE (name);


--
-- Name: genres genres_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.genres
    ADD CONSTRAINT genres_pkey PRIMARY KEY (id);


--
-- Name: genres genres_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.genres
    ADD CONSTRAINT genres_slug_key UNIQUE (slug);


--
-- Name: hashtags hashtags_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hashtags
    ADD CONSTRAINT hashtags_pkey PRIMARY KEY (id);


--
-- Name: hashtags hashtags_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hashtags
    ADD CONSTRAINT hashtags_slug_key UNIQUE (slug);


--
-- Name: home_banners home_banners_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.home_banners
    ADD CONSTRAINT home_banners_pkey PRIMARY KEY (id);


--
-- Name: home_section_items home_section_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.home_section_items
    ADD CONSTRAINT home_section_items_pkey PRIMARY KEY (id);


--
-- Name: home_section_items home_section_items_section_item_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.home_section_items
    ADD CONSTRAINT home_section_items_section_item_unique UNIQUE (section_id, item_type, item_key);


--
-- Name: home_sections home_sections_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.home_sections
    ADD CONSTRAINT home_sections_code_key UNIQUE (code);


--
-- Name: home_sections home_sections_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.home_sections
    ADD CONSTRAINT home_sections_pkey PRIMARY KEY (id);


--
-- Name: listens listens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.listens
    ADD CONSTRAINT listens_pkey PRIMARY KEY (id);


--
-- Name: moods moods_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.moods
    ADD CONSTRAINT moods_name_key UNIQUE (name);


--
-- Name: moods moods_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.moods
    ADD CONSTRAINT moods_pkey PRIMARY KEY (id);


--
-- Name: moods moods_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.moods
    ADD CONSTRAINT moods_slug_key UNIQUE (slug);


--
-- Name: playlist_songs playlist_songs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.playlist_songs
    ADD CONSTRAINT playlist_songs_pkey PRIMARY KEY (id);


--
-- Name: playlist_songs playlist_songs_playlist_position_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.playlist_songs
    ADD CONSTRAINT playlist_songs_playlist_position_unique UNIQUE (playlist_id, "position");


--
-- Name: playlist_songs playlist_songs_playlist_song_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.playlist_songs
    ADD CONSTRAINT playlist_songs_playlist_song_unique UNIQUE (playlist_id, song_id);


--
-- Name: playlists playlists_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.playlists
    ADD CONSTRAINT playlists_pkey PRIMARY KEY (id);


--
-- Name: podcast_channels podcast_channels_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.podcast_channels
    ADD CONSTRAINT podcast_channels_name_key UNIQUE (name);


--
-- Name: podcast_channels podcast_channels_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.podcast_channels
    ADD CONSTRAINT podcast_channels_pkey PRIMARY KEY (id);


--
-- Name: podcast_favorites podcast_favorites_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.podcast_favorites
    ADD CONSTRAINT podcast_favorites_pkey PRIMARY KEY (id);


--
-- Name: podcast_favorites podcast_favorites_user_id_podcast_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.podcast_favorites
    ADD CONSTRAINT podcast_favorites_user_id_podcast_id_key UNIQUE (user_id, podcast_id);


--
-- Name: podcast_listens podcast_listens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.podcast_listens
    ADD CONSTRAINT podcast_listens_pkey PRIMARY KEY (id);


--
-- Name: podcasts podcasts_external_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.podcasts
    ADD CONSTRAINT podcasts_external_id_key UNIQUE (external_id);


--
-- Name: podcasts podcasts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.podcasts
    ADD CONSTRAINT podcasts_pkey PRIMARY KEY (id);


--
-- Name: profiles profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_pkey PRIMARY KEY (id);


--
-- Name: song_artists song_artists_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.song_artists
    ADD CONSTRAINT song_artists_pkey PRIMARY KEY (song_id, artist_id);


--
-- Name: song_genres song_genres_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.song_genres
    ADD CONSTRAINT song_genres_pkey PRIMARY KEY (song_id, genre_id);


--
-- Name: song_hashtags song_hashtags_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.song_hashtags
    ADD CONSTRAINT song_hashtags_pkey PRIMARY KEY (id);


--
-- Name: song_hashtags song_hashtags_song_hashtag_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.song_hashtags
    ADD CONSTRAINT song_hashtags_song_hashtag_unique UNIQUE (song_id, hashtag_id);


--
-- Name: song_listens song_listens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.song_listens
    ADD CONSTRAINT song_listens_pkey PRIMARY KEY (id);


--
-- Name: song_moods song_moods_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.song_moods
    ADD CONSTRAINT song_moods_pkey PRIMARY KEY (song_id, mood_id);


--
-- Name: songs songs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.songs
    ADD CONSTRAINT songs_pkey PRIMARY KEY (id);


--
-- Name: trending_search_keywords trending_search_keywords_keyword_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trending_search_keywords
    ADD CONSTRAINT trending_search_keywords_keyword_key UNIQUE (keyword);


--
-- Name: trending_search_keywords trending_search_keywords_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trending_search_keywords
    ADD CONSTRAINT trending_search_keywords_pkey PRIMARY KEY (id);


--
-- Name: user_disliked_artists user_disliked_artists_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_disliked_artists
    ADD CONSTRAINT user_disliked_artists_pkey PRIMARY KEY (user_id, artist_id);


--
-- Name: user_disliked_songs user_disliked_songs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_disliked_songs
    ADD CONSTRAINT user_disliked_songs_pkey PRIMARY KEY (user_id, song_id);


--
-- Name: user_followed_artists user_followed_artists_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_followed_artists
    ADD CONSTRAINT user_followed_artists_pkey PRIMARY KEY (id);


--
-- Name: user_followed_artists user_followed_artists_user_artist_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_followed_artists
    ADD CONSTRAINT user_followed_artists_user_artist_unique UNIQUE (user_id, artist_id);


--
-- Name: user_player_state user_player_state_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_player_state
    ADD CONSTRAINT user_player_state_pkey PRIMARY KEY (user_id);


--
-- Name: user_preferred_artists user_preferred_artists_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_preferred_artists
    ADD CONSTRAINT user_preferred_artists_pkey PRIMARY KEY (user_id, artist_id);


--
-- Name: user_preferred_genres user_preferred_genres_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_preferred_genres
    ADD CONSTRAINT user_preferred_genres_pkey PRIMARY KEY (user_id, genre_id);


--
-- Name: user_recent_items user_recent_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_recent_items
    ADD CONSTRAINT user_recent_items_pkey PRIMARY KEY (id);


--
-- Name: user_recent_items user_recent_items_user_item_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_recent_items
    ADD CONSTRAINT user_recent_items_user_item_unique UNIQUE (user_id, item_type, item_key);


--
-- Name: user_recent_searches user_recent_searches_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_recent_searches
    ADD CONSTRAINT user_recent_searches_pkey PRIMARY KEY (id);


--
-- Name: user_recent_searches user_recent_searches_user_keyword_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_recent_searches
    ADD CONSTRAINT user_recent_searches_user_keyword_unique UNIQUE (user_id, keyword);


--
-- Name: user_saved_playlists user_saved_playlists_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_saved_playlists
    ADD CONSTRAINT user_saved_playlists_pkey PRIMARY KEY (id);


--
-- Name: user_saved_playlists user_saved_playlists_user_playlist_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_saved_playlists
    ADD CONSTRAINT user_saved_playlists_user_playlist_unique UNIQUE (user_id, playlist_id);


--
-- Name: idx_album_artists_album_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_album_artists_album_id ON public.album_artists USING btree (album_id);


--
-- Name: idx_album_artists_artist_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_album_artists_artist_id ON public.album_artists USING btree (artist_id);


--
-- Name: idx_album_songs_album_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_album_songs_album_id ON public.album_songs USING btree (album_id);


--
-- Name: idx_album_songs_song_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_album_songs_song_id ON public.album_songs USING btree (song_id);


--
-- Name: idx_albums_external_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_albums_external_id ON public.albums USING btree (external_id);


--
-- Name: idx_albums_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_albums_is_active ON public.albums USING btree (is_active);


--
-- Name: idx_albums_release_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_albums_release_date ON public.albums USING btree (release_date);


--
-- Name: idx_artists_monthly_current_month; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_artists_monthly_current_month ON public.artists USING btree (monthly_current_month);


--
-- Name: idx_artists_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_artists_name ON public.artists USING btree (name);


--
-- Name: idx_channel_subscriptions_channel_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_channel_subscriptions_channel_id ON public.channel_subscriptions USING btree (channel_id);


--
-- Name: idx_channel_subscriptions_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_channel_subscriptions_user_id ON public.channel_subscriptions USING btree (user_id);


--
-- Name: idx_favorites_song_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_favorites_song_id ON public.favorites USING btree (song_id);


--
-- Name: idx_favorites_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_favorites_user_id ON public.favorites USING btree (user_id);


--
-- Name: idx_genres_slug; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_genres_slug ON public.genres USING btree (slug);


--
-- Name: idx_hashtags_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_hashtags_active ON public.hashtags USING btree (is_active);


--
-- Name: idx_hashtags_slug; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_hashtags_slug ON public.hashtags USING btree (slug);


--
-- Name: idx_home_banners_order; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_home_banners_order ON public.home_banners USING btree (display_order, is_active);


--
-- Name: idx_home_section_items_section_order; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_home_section_items_section_order ON public.home_section_items USING btree (section_id, display_order, is_active);


--
-- Name: idx_home_sections_order; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_home_sections_order ON public.home_sections USING btree (display_order, is_active);


--
-- Name: idx_moods_slug; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_moods_slug ON public.moods USING btree (slug);


--
-- Name: idx_playlist_songs_playlist_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_playlist_songs_playlist_id ON public.playlist_songs USING btree (playlist_id);


--
-- Name: idx_playlist_songs_song_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_playlist_songs_song_id ON public.playlist_songs USING btree (song_id);


--
-- Name: idx_playlists_type_public; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_playlists_type_public ON public.playlists USING btree (playlist_type, is_public);


--
-- Name: idx_playlists_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_playlists_user_id ON public.playlists USING btree (user_id);


--
-- Name: idx_podcast_channels_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_podcast_channels_name ON public.podcast_channels USING btree (name);


--
-- Name: idx_podcast_listens_podcast_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_podcast_listens_podcast_id ON public.podcast_listens USING btree (podcast_id);


--
-- Name: idx_podcast_listens_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_podcast_listens_user_id ON public.podcast_listens USING btree (user_id);


--
-- Name: idx_podcasts_channel_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_podcasts_channel_id ON public.podcasts USING btree (channel_id);


--
-- Name: idx_podcasts_external_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_podcasts_external_id ON public.podcasts USING btree (external_id);


--
-- Name: idx_podcasts_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_podcasts_is_active ON public.podcasts USING btree (is_active);


--
-- Name: idx_song_artists_artist_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_song_artists_artist_id ON public.song_artists USING btree (artist_id);


--
-- Name: idx_song_artists_song_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_song_artists_song_id ON public.song_artists USING btree (song_id);


--
-- Name: idx_song_genres_genre_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_song_genres_genre_id ON public.song_genres USING btree (genre_id);


--
-- Name: idx_song_genres_song_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_song_genres_song_id ON public.song_genres USING btree (song_id);


--
-- Name: idx_song_hashtags_hashtag_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_song_hashtags_hashtag_id ON public.song_hashtags USING btree (hashtag_id);


--
-- Name: idx_song_hashtags_song_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_song_hashtags_song_id ON public.song_hashtags USING btree (song_id);


--
-- Name: idx_song_listens_listened_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_song_listens_listened_at ON public.song_listens USING btree (listened_at);


--
-- Name: idx_song_listens_song_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_song_listens_song_id ON public.song_listens USING btree (song_id);


--
-- Name: idx_song_listens_source_playlist_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_song_listens_source_playlist_id ON public.song_listens USING btree (source_playlist_id);


--
-- Name: idx_song_listens_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_song_listens_user_id ON public.song_listens USING btree (user_id);


--
-- Name: idx_song_moods_mood_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_song_moods_mood_id ON public.song_moods USING btree (mood_id);


--
-- Name: idx_song_moods_song_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_song_moods_song_id ON public.song_moods USING btree (song_id);


--
-- Name: idx_songs_album_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_songs_album_id ON public.songs USING btree (album_id);


--
-- Name: idx_songs_external_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_songs_external_id ON public.songs USING btree (external_id);


--
-- Name: idx_songs_is_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_songs_is_active ON public.songs USING btree (is_active);


--
-- Name: idx_songs_release_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_songs_release_date ON public.songs USING btree (release_date);


--
-- Name: idx_trending_search_keywords_score; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_trending_search_keywords_score ON public.trending_search_keywords USING btree (score DESC, updated_at DESC);


--
-- Name: idx_user_followed_artists_artist_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_followed_artists_artist_id ON public.user_followed_artists USING btree (artist_id);


--
-- Name: idx_user_followed_artists_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_followed_artists_user_id ON public.user_followed_artists USING btree (user_id);


--
-- Name: idx_user_player_state_playlist_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_player_state_playlist_id ON public.user_player_state USING btree (current_playlist_id);


--
-- Name: idx_user_player_state_song_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_player_state_song_id ON public.user_player_state USING btree (current_song_id);


--
-- Name: idx_user_preferred_artists_user_score; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_preferred_artists_user_score ON public.user_preferred_artists USING btree (user_id, score DESC);


--
-- Name: idx_user_preferred_genres_user_score; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_preferred_genres_user_score ON public.user_preferred_genres USING btree (user_id, score DESC);


--
-- Name: idx_user_recent_items_user_time; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_recent_items_user_time ON public.user_recent_items USING btree (user_id, last_interacted_at DESC);


--
-- Name: idx_user_recent_searches_user_time; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_recent_searches_user_time ON public.user_recent_searches USING btree (user_id, searched_at DESC);


--
-- Name: idx_user_saved_playlists_playlist_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_saved_playlists_playlist_id ON public.user_saved_playlists USING btree (playlist_id);


--
-- Name: idx_user_saved_playlists_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_saved_playlists_user_id ON public.user_saved_playlists USING btree (user_id);


--
-- Name: album_artists trg_album_artists_cache; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_album_artists_cache AFTER INSERT OR DELETE OR UPDATE ON public.album_artists FOR EACH ROW EXECUTE FUNCTION public.handle_album_artists_cache();


--
-- Name: album_songs trg_album_songs_cache; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_album_songs_cache AFTER INSERT OR DELETE OR UPDATE ON public.album_songs FOR EACH ROW EXECUTE FUNCTION public.handle_album_songs_cache();


--
-- Name: channel_subscriptions trg_channel_subscriptions_count; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_channel_subscriptions_count AFTER INSERT OR DELETE ON public.channel_subscriptions FOR EACH ROW EXECUTE FUNCTION public.handle_channel_subscription_count();


--
-- Name: favorites trg_favorites_like_count; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_favorites_like_count AFTER INSERT OR DELETE ON public.favorites FOR EACH ROW EXECUTE FUNCTION public.handle_favorites_like_count();


--
-- Name: playlist_songs trg_playlist_songs_cache; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_playlist_songs_cache AFTER INSERT OR DELETE OR UPDATE ON public.playlist_songs FOR EACH ROW EXECUTE FUNCTION public.handle_playlist_songs_cache();


--
-- Name: podcast_listens trg_podcast_listens_count; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_podcast_listens_count AFTER INSERT ON public.podcast_listens FOR EACH ROW EXECUTE FUNCTION public.handle_podcast_listen_count();


--
-- Name: song_artists trg_song_artists_cache; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_song_artists_cache AFTER INSERT OR DELETE OR UPDATE ON public.song_artists FOR EACH ROW EXECUTE FUNCTION public.handle_song_artists_cache();


--
-- Name: song_listens trg_song_listens_after_insert; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_song_listens_after_insert AFTER INSERT ON public.song_listens FOR EACH ROW EXECUTE FUNCTION public.handle_song_listen_after_insert();


--
-- Name: user_followed_artists trg_user_followed_artists_cache; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_user_followed_artists_cache AFTER INSERT OR DELETE ON public.user_followed_artists FOR EACH ROW EXECUTE FUNCTION public.handle_followed_artists_cache();


--
-- Name: user_recent_searches trg_user_recent_searches_trending; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_user_recent_searches_trending AFTER INSERT OR UPDATE ON public.user_recent_searches FOR EACH ROW EXECUTE FUNCTION public.handle_recent_searches_trending();


--
-- Name: user_saved_playlists trg_user_saved_playlists_cache; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_user_saved_playlists_cache AFTER INSERT OR DELETE ON public.user_saved_playlists FOR EACH ROW EXECUTE FUNCTION public.handle_saved_playlists_cache();


--
-- Name: album_artists album_artists_album_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.album_artists
    ADD CONSTRAINT album_artists_album_id_fkey FOREIGN KEY (album_id) REFERENCES public.albums(id) ON DELETE CASCADE;


--
-- Name: album_artists album_artists_artist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.album_artists
    ADD CONSTRAINT album_artists_artist_id_fkey FOREIGN KEY (artist_id) REFERENCES public.artists(id) ON DELETE CASCADE;


--
-- Name: album_songs album_songs_album_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.album_songs
    ADD CONSTRAINT album_songs_album_id_fkey FOREIGN KEY (album_id) REFERENCES public.albums(id) ON DELETE CASCADE;


--
-- Name: album_songs album_songs_song_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.album_songs
    ADD CONSTRAINT album_songs_song_id_fkey FOREIGN KEY (song_id) REFERENCES public.songs(id) ON DELETE CASCADE;


--
-- Name: channel_subscriptions channel_subscriptions_channel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.channel_subscriptions
    ADD CONSTRAINT channel_subscriptions_channel_id_fkey FOREIGN KEY (channel_id) REFERENCES public.podcast_channels(id) ON DELETE CASCADE;


--
-- Name: channel_subscriptions channel_subscriptions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.channel_subscriptions
    ADD CONSTRAINT channel_subscriptions_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: home_section_items home_section_items_section_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.home_section_items
    ADD CONSTRAINT home_section_items_section_id_fkey FOREIGN KEY (section_id) REFERENCES public.home_sections(id) ON DELETE CASCADE;


--
-- Name: listens listens_podcast_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.listens
    ADD CONSTRAINT listens_podcast_id_fkey FOREIGN KEY (podcast_id) REFERENCES public.podcasts(id) ON DELETE CASCADE;


--
-- Name: listens listens_song_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.listens
    ADD CONSTRAINT listens_song_id_fkey FOREIGN KEY (song_id) REFERENCES public.songs(id) ON DELETE CASCADE;


--
-- Name: listens listens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.listens
    ADD CONSTRAINT listens_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: playlist_songs playlist_songs_playlist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.playlist_songs
    ADD CONSTRAINT playlist_songs_playlist_id_fkey FOREIGN KEY (playlist_id) REFERENCES public.playlists(id) ON DELETE CASCADE;


--
-- Name: playlist_songs playlist_songs_song_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.playlist_songs
    ADD CONSTRAINT playlist_songs_song_id_fkey FOREIGN KEY (song_id) REFERENCES public.songs(id) ON DELETE CASCADE;


--
-- Name: playlists playlists_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.playlists
    ADD CONSTRAINT playlists_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- Name: podcast_favorites podcast_favorites_podcast_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.podcast_favorites
    ADD CONSTRAINT podcast_favorites_podcast_id_fkey FOREIGN KEY (podcast_id) REFERENCES public.podcasts(id) ON DELETE CASCADE;


--
-- Name: podcast_favorites podcast_favorites_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.podcast_favorites
    ADD CONSTRAINT podcast_favorites_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: podcast_listens podcast_listens_podcast_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.podcast_listens
    ADD CONSTRAINT podcast_listens_podcast_id_fkey FOREIGN KEY (podcast_id) REFERENCES public.podcasts(id) ON DELETE CASCADE;


--
-- Name: podcast_listens podcast_listens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.podcast_listens
    ADD CONSTRAINT podcast_listens_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE SET NULL;


--
-- Name: podcasts podcasts_channel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.podcasts
    ADD CONSTRAINT podcasts_channel_id_fkey FOREIGN KEY (channel_id) REFERENCES public.podcast_channels(id) ON DELETE CASCADE;


--
-- Name: song_artists song_artists_artist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.song_artists
    ADD CONSTRAINT song_artists_artist_id_fkey FOREIGN KEY (artist_id) REFERENCES public.artists(id) ON DELETE CASCADE;


--
-- Name: song_artists song_artists_song_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.song_artists
    ADD CONSTRAINT song_artists_song_id_fkey FOREIGN KEY (song_id) REFERENCES public.songs(id) ON DELETE CASCADE;


--
-- Name: song_genres song_genres_genre_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.song_genres
    ADD CONSTRAINT song_genres_genre_id_fkey FOREIGN KEY (genre_id) REFERENCES public.genres(id) ON DELETE CASCADE;


--
-- Name: song_genres song_genres_song_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.song_genres
    ADD CONSTRAINT song_genres_song_id_fkey FOREIGN KEY (song_id) REFERENCES public.songs(id) ON DELETE CASCADE;


--
-- Name: song_hashtags song_hashtags_hashtag_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.song_hashtags
    ADD CONSTRAINT song_hashtags_hashtag_id_fkey FOREIGN KEY (hashtag_id) REFERENCES public.hashtags(id) ON DELETE CASCADE;


--
-- Name: song_hashtags song_hashtags_song_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.song_hashtags
    ADD CONSTRAINT song_hashtags_song_id_fkey FOREIGN KEY (song_id) REFERENCES public.songs(id) ON DELETE CASCADE;


--
-- Name: song_moods song_moods_mood_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.song_moods
    ADD CONSTRAINT song_moods_mood_id_fkey FOREIGN KEY (mood_id) REFERENCES public.moods(id) ON DELETE CASCADE;


--
-- Name: song_moods song_moods_song_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.song_moods
    ADD CONSTRAINT song_moods_song_id_fkey FOREIGN KEY (song_id) REFERENCES public.songs(id) ON DELETE CASCADE;


--
-- Name: user_disliked_artists user_disliked_artists_artist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_disliked_artists
    ADD CONSTRAINT user_disliked_artists_artist_id_fkey FOREIGN KEY (artist_id) REFERENCES public.artists(id) ON DELETE CASCADE;


--
-- Name: user_disliked_artists user_disliked_artists_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_disliked_artists
    ADD CONSTRAINT user_disliked_artists_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- Name: user_disliked_songs user_disliked_songs_song_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_disliked_songs
    ADD CONSTRAINT user_disliked_songs_song_id_fkey FOREIGN KEY (song_id) REFERENCES public.songs(id) ON DELETE CASCADE;


--
-- Name: user_disliked_songs user_disliked_songs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_disliked_songs
    ADD CONSTRAINT user_disliked_songs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- Name: user_followed_artists user_followed_artists_artist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_followed_artists
    ADD CONSTRAINT user_followed_artists_artist_id_fkey FOREIGN KEY (artist_id) REFERENCES public.artists(id) ON DELETE CASCADE;


--
-- Name: user_followed_artists user_followed_artists_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_followed_artists
    ADD CONSTRAINT user_followed_artists_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- Name: user_preferred_artists user_preferred_artists_artist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_preferred_artists
    ADD CONSTRAINT user_preferred_artists_artist_id_fkey FOREIGN KEY (artist_id) REFERENCES public.artists(id) ON DELETE CASCADE;


--
-- Name: user_preferred_artists user_preferred_artists_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_preferred_artists
    ADD CONSTRAINT user_preferred_artists_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- Name: user_preferred_genres user_preferred_genres_genre_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_preferred_genres
    ADD CONSTRAINT user_preferred_genres_genre_id_fkey FOREIGN KEY (genre_id) REFERENCES public.genres(id) ON DELETE CASCADE;


--
-- Name: user_preferred_genres user_preferred_genres_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_preferred_genres
    ADD CONSTRAINT user_preferred_genres_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- Name: user_recent_items user_recent_items_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_recent_items
    ADD CONSTRAINT user_recent_items_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- Name: user_recent_searches user_recent_searches_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_recent_searches
    ADD CONSTRAINT user_recent_searches_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- Name: user_saved_playlists user_saved_playlists_playlist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_saved_playlists
    ADD CONSTRAINT user_saved_playlists_playlist_id_fkey FOREIGN KEY (playlist_id) REFERENCES public.playlists(id) ON DELETE CASCADE;


--
-- Name: user_saved_playlists user_saved_playlists_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_saved_playlists
    ADD CONSTRAINT user_saved_playlists_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- Name: listens Users can insert their own listens; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Users can insert their own listens" ON public.listens FOR INSERT WITH CHECK ((auth.uid() = user_id));


--
-- Name: user_recent_items Users can insert their own recent items; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Users can insert their own recent items" ON public.user_recent_items FOR INSERT WITH CHECK ((auth.uid() = user_id));


--
-- Name: listens Users can select their own listens; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Users can select their own listens" ON public.listens FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: user_recent_items Users can update their own recent items; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Users can update their own recent items" ON public.user_recent_items FOR UPDATE USING ((auth.uid() = user_id));


--
-- Name: user_recent_items Users can view their own recent items; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Users can view their own recent items" ON public.user_recent_items FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: album_artists; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.album_artists ENABLE ROW LEVEL SECURITY;

--
-- Name: album_artists album_artists_public_read; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY album_artists_public_read ON public.album_artists FOR SELECT TO authenticated, anon USING (true);


--
-- Name: album_songs; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.album_songs ENABLE ROW LEVEL SECURITY;

--
-- Name: album_songs album_songs_public_read; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY album_songs_public_read ON public.album_songs FOR SELECT TO authenticated, anon USING (true);


--
-- Name: albums; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.albums ENABLE ROW LEVEL SECURITY;

--
-- Name: albums albums_public_read_active; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY albums_public_read_active ON public.albums FOR SELECT TO authenticated, anon USING ((is_active = true));


--
-- Name: artists; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.artists ENABLE ROW LEVEL SECURITY;

--
-- Name: artists artists_public_read; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY artists_public_read ON public.artists FOR SELECT TO authenticated, anon USING (true);


--
-- Name: channel_subscriptions; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.channel_subscriptions ENABLE ROW LEVEL SECURITY;

--
-- Name: channel_subscriptions channel_subscriptions_delete_own; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY channel_subscriptions_delete_own ON public.channel_subscriptions FOR DELETE TO authenticated USING ((auth.uid() = user_id));


--
-- Name: channel_subscriptions channel_subscriptions_insert_own; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY channel_subscriptions_insert_own ON public.channel_subscriptions FOR INSERT TO authenticated WITH CHECK ((auth.uid() = user_id));


--
-- Name: channel_subscriptions channel_subscriptions_select_own; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY channel_subscriptions_select_own ON public.channel_subscriptions FOR SELECT TO authenticated USING ((auth.uid() = user_id));


--
-- Name: favorites; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.favorites ENABLE ROW LEVEL SECURITY;

--
-- Name: favorites favorites_delete_own; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY favorites_delete_own ON public.favorites FOR DELETE TO authenticated USING ((auth.uid() = user_id));


--
-- Name: favorites favorites_insert_own; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY favorites_insert_own ON public.favorites FOR INSERT TO authenticated WITH CHECK ((auth.uid() = user_id));


--
-- Name: favorites favorites_select_own; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY favorites_select_own ON public.favorites FOR SELECT TO authenticated USING ((auth.uid() = user_id));


--
-- Name: genres; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.genres ENABLE ROW LEVEL SECURITY;

--
-- Name: genres genres_public_read_active; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY genres_public_read_active ON public.genres FOR SELECT TO authenticated, anon USING ((is_active = true));


--
-- Name: hashtags; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.hashtags ENABLE ROW LEVEL SECURITY;

--
-- Name: hashtags hashtags_public_read_active; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY hashtags_public_read_active ON public.hashtags FOR SELECT TO authenticated, anon USING ((is_active = true));


--
-- Name: home_banners; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.home_banners ENABLE ROW LEVEL SECURITY;

--
-- Name: home_banners home_banners_public_read_active; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY home_banners_public_read_active ON public.home_banners FOR SELECT TO authenticated, anon USING ((is_active = true));


--
-- Name: home_section_items; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.home_section_items ENABLE ROW LEVEL SECURITY;

--
-- Name: home_section_items home_section_items_public_read_active; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY home_section_items_public_read_active ON public.home_section_items FOR SELECT TO authenticated, anon USING ((is_active = true));


--
-- Name: home_sections; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.home_sections ENABLE ROW LEVEL SECURITY;

--
-- Name: home_sections home_sections_public_read_active; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY home_sections_public_read_active ON public.home_sections FOR SELECT TO authenticated, anon USING ((is_active = true));


--
-- Name: listens; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.listens ENABLE ROW LEVEL SECURITY;

--
-- Name: moods; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.moods ENABLE ROW LEVEL SECURITY;

--
-- Name: moods moods_public_read_active; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY moods_public_read_active ON public.moods FOR SELECT TO authenticated, anon USING ((is_active = true));


--
-- Name: playlist_songs; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.playlist_songs ENABLE ROW LEVEL SECURITY;

--
-- Name: playlist_songs playlist_songs_delete_own; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY playlist_songs_delete_own ON public.playlist_songs FOR DELETE TO authenticated USING ((EXISTS ( SELECT 1
   FROM public.playlists p
  WHERE ((p.id = playlist_songs.playlist_id) AND (p.user_id = auth.uid()) AND (p.playlist_type = 'user'::text)))));


--
-- Name: playlist_songs playlist_songs_insert_own; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY playlist_songs_insert_own ON public.playlist_songs FOR INSERT TO authenticated WITH CHECK ((EXISTS ( SELECT 1
   FROM public.playlists p
  WHERE ((p.id = playlist_songs.playlist_id) AND (p.user_id = auth.uid()) AND (p.playlist_type = 'user'::text)))));


--
-- Name: playlist_songs playlist_songs_read_accessible_playlist; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY playlist_songs_read_accessible_playlist ON public.playlist_songs FOR SELECT TO authenticated, anon USING ((EXISTS ( SELECT 1
   FROM public.playlists p
  WHERE ((p.id = playlist_songs.playlist_id) AND ((p.playlist_type = 'system'::text) OR (p.is_public = true) OR (p.user_id = auth.uid()) OR (EXISTS ( SELECT 1
           FROM public.user_saved_playlists usp
          WHERE ((usp.playlist_id = p.id) AND (usp.user_id = auth.uid())))))))));


--
-- Name: playlist_songs playlist_songs_update_own; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY playlist_songs_update_own ON public.playlist_songs FOR UPDATE TO authenticated USING ((EXISTS ( SELECT 1
   FROM public.playlists p
  WHERE ((p.id = playlist_songs.playlist_id) AND (p.user_id = auth.uid()) AND (p.playlist_type = 'user'::text))))) WITH CHECK ((EXISTS ( SELECT 1
   FROM public.playlists p
  WHERE ((p.id = playlist_songs.playlist_id) AND (p.user_id = auth.uid()) AND (p.playlist_type = 'user'::text)))));


--
-- Name: playlists; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.playlists ENABLE ROW LEVEL SECURITY;

--
-- Name: playlists playlists_delete_own; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY playlists_delete_own ON public.playlists FOR DELETE TO authenticated USING (((user_id = auth.uid()) AND (playlist_type = 'user'::text) AND (is_system = false)));


--
-- Name: playlists playlists_insert_own; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY playlists_insert_own ON public.playlists FOR INSERT TO authenticated WITH CHECK (((user_id = auth.uid()) AND (playlist_type = 'user'::text) AND (is_system = false)));


--
-- Name: playlists playlists_public_read; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY playlists_public_read ON public.playlists FOR SELECT TO authenticated, anon USING (((playlist_type = 'system'::text) OR (is_public = true)));


--
-- Name: playlists playlists_select_own_or_saved; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY playlists_select_own_or_saved ON public.playlists FOR SELECT TO authenticated USING (((user_id = auth.uid()) OR (EXISTS ( SELECT 1
   FROM public.user_saved_playlists usp
  WHERE ((usp.playlist_id = playlists.id) AND (usp.user_id = auth.uid()))))));


--
-- Name: playlists playlists_update_own; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY playlists_update_own ON public.playlists FOR UPDATE TO authenticated USING (((user_id = auth.uid()) AND (playlist_type = 'user'::text) AND (is_system = false))) WITH CHECK (((user_id = auth.uid()) AND (playlist_type = 'user'::text) AND (is_system = false)));


--
-- Name: podcast_channels; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.podcast_channels ENABLE ROW LEVEL SECURITY;

--
-- Name: podcast_channels podcast_channels_public_read; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY podcast_channels_public_read ON public.podcast_channels FOR SELECT TO authenticated, anon USING (true);


--
-- Name: podcast_favorites; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.podcast_favorites ENABLE ROW LEVEL SECURITY;

--
-- Name: podcast_favorites podcast_favorites_delete_own; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY podcast_favorites_delete_own ON public.podcast_favorites FOR DELETE TO authenticated USING ((auth.uid() = user_id));


--
-- Name: podcast_favorites podcast_favorites_insert_own; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY podcast_favorites_insert_own ON public.podcast_favorites FOR INSERT TO authenticated WITH CHECK ((auth.uid() = user_id));


--
-- Name: podcast_favorites podcast_favorites_select_own; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY podcast_favorites_select_own ON public.podcast_favorites FOR SELECT TO authenticated USING ((auth.uid() = user_id));


--
-- Name: podcast_listens; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.podcast_listens ENABLE ROW LEVEL SECURITY;

--
-- Name: podcast_listens podcast_listens_insert_own; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY podcast_listens_insert_own ON public.podcast_listens FOR INSERT TO authenticated WITH CHECK ((auth.uid() = user_id));


--
-- Name: podcast_listens podcast_listens_select_own; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY podcast_listens_select_own ON public.podcast_listens FOR SELECT TO authenticated USING ((auth.uid() = user_id));


--
-- Name: podcasts; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.podcasts ENABLE ROW LEVEL SECURITY;

--
-- Name: podcasts podcasts_public_read_active; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY podcasts_public_read_active ON public.podcasts FOR SELECT TO authenticated, anon USING ((is_active = true));


--
-- Name: profiles; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

--
-- Name: profiles profiles_select_own; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY profiles_select_own ON public.profiles FOR SELECT TO authenticated USING ((auth.uid() = id));


--
-- Name: profiles profiles_update_own; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY profiles_update_own ON public.profiles FOR UPDATE TO authenticated USING ((auth.uid() = id)) WITH CHECK ((auth.uid() = id));


--
-- Name: song_artists; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.song_artists ENABLE ROW LEVEL SECURITY;

--
-- Name: song_artists song_artists_public_read; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY song_artists_public_read ON public.song_artists FOR SELECT TO authenticated, anon USING (true);


--
-- Name: song_genres; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.song_genres ENABLE ROW LEVEL SECURITY;

--
-- Name: song_genres song_genres_public_read; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY song_genres_public_read ON public.song_genres FOR SELECT TO authenticated, anon USING (true);


--
-- Name: song_hashtags; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.song_hashtags ENABLE ROW LEVEL SECURITY;

--
-- Name: song_hashtags song_hashtags_public_read; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY song_hashtags_public_read ON public.song_hashtags FOR SELECT TO authenticated, anon USING (true);


--
-- Name: song_listens; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.song_listens ENABLE ROW LEVEL SECURITY;

--
-- Name: song_listens song_listens_insert_own; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY song_listens_insert_own ON public.song_listens FOR INSERT TO authenticated WITH CHECK ((auth.uid() = user_id));


--
-- Name: song_listens song_listens_select_own; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY song_listens_select_own ON public.song_listens FOR SELECT TO authenticated USING ((auth.uid() = user_id));


--
-- Name: song_moods; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.song_moods ENABLE ROW LEVEL SECURITY;

--
-- Name: song_moods song_moods_public_read; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY song_moods_public_read ON public.song_moods FOR SELECT TO authenticated, anon USING (true);


--
-- Name: songs; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.songs ENABLE ROW LEVEL SECURITY;

--
-- Name: songs songs_public_read_active; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY songs_public_read_active ON public.songs FOR SELECT TO authenticated, anon USING ((is_active = true));


--
-- Name: trending_search_keywords; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.trending_search_keywords ENABLE ROW LEVEL SECURITY;

--
-- Name: trending_search_keywords trending_search_keywords_public_read; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY trending_search_keywords_public_read ON public.trending_search_keywords FOR SELECT TO authenticated, anon USING (true);


--
-- Name: user_disliked_artists; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.user_disliked_artists ENABLE ROW LEVEL SECURITY;

--
-- Name: user_disliked_artists user_disliked_artists_delete_own; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY user_disliked_artists_delete_own ON public.user_disliked_artists FOR DELETE TO authenticated USING ((auth.uid() = user_id));


--
-- Name: user_disliked_artists user_disliked_artists_insert_own; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY user_disliked_artists_insert_own ON public.user_disliked_artists FOR INSERT TO authenticated WITH CHECK ((auth.uid() = user_id));


--
-- Name: user_disliked_artists user_disliked_artists_select_own; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY user_disliked_artists_select_own ON public.user_disliked_artists FOR SELECT TO authenticated USING ((auth.uid() = user_id));


--
-- Name: user_disliked_artists user_disliked_artists_update_own; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY user_disliked_artists_update_own ON public.user_disliked_artists FOR UPDATE TO authenticated USING ((auth.uid() = user_id)) WITH CHECK ((auth.uid() = user_id));


--
-- Name: user_disliked_songs; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.user_disliked_songs ENABLE ROW LEVEL SECURITY;

--
-- Name: user_disliked_songs user_disliked_songs_delete_own; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY user_disliked_songs_delete_own ON public.user_disliked_songs FOR DELETE TO authenticated USING ((auth.uid() = user_id));


--
-- Name: user_disliked_songs user_disliked_songs_insert_own; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY user_disliked_songs_insert_own ON public.user_disliked_songs FOR INSERT TO authenticated WITH CHECK ((auth.uid() = user_id));


--
-- Name: user_disliked_songs user_disliked_songs_select_own; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY user_disliked_songs_select_own ON public.user_disliked_songs FOR SELECT TO authenticated USING ((auth.uid() = user_id));


--
-- Name: user_disliked_songs user_disliked_songs_update_own; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY user_disliked_songs_update_own ON public.user_disliked_songs FOR UPDATE TO authenticated USING ((auth.uid() = user_id)) WITH CHECK ((auth.uid() = user_id));


--
-- Name: user_followed_artists; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.user_followed_artists ENABLE ROW LEVEL SECURITY;

--
-- Name: user_followed_artists user_followed_artists_delete_own; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY user_followed_artists_delete_own ON public.user_followed_artists FOR DELETE TO authenticated USING ((auth.uid() = user_id));


--
-- Name: user_followed_artists user_followed_artists_insert_own; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY user_followed_artists_insert_own ON public.user_followed_artists FOR INSERT TO authenticated WITH CHECK ((auth.uid() = user_id));


--
-- Name: user_followed_artists user_followed_artists_select_own; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY user_followed_artists_select_own ON public.user_followed_artists FOR SELECT TO authenticated USING ((auth.uid() = user_id));


--
-- Name: user_player_state; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.user_player_state ENABLE ROW LEVEL SECURITY;

--
-- Name: user_player_state user_player_state_delete_own; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY user_player_state_delete_own ON public.user_player_state FOR DELETE TO authenticated USING ((auth.uid() = user_id));


--
-- Name: user_player_state user_player_state_insert_own; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY user_player_state_insert_own ON public.user_player_state FOR INSERT TO authenticated WITH CHECK ((auth.uid() = user_id));


--
-- Name: user_player_state user_player_state_select_own; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY user_player_state_select_own ON public.user_player_state FOR SELECT TO authenticated USING ((auth.uid() = user_id));


--
-- Name: user_player_state user_player_state_update_own; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY user_player_state_update_own ON public.user_player_state FOR UPDATE TO authenticated USING ((auth.uid() = user_id)) WITH CHECK ((auth.uid() = user_id));


--
-- Name: user_preferred_artists; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.user_preferred_artists ENABLE ROW LEVEL SECURITY;

--
-- Name: user_preferred_artists user_preferred_artists_select_own; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY user_preferred_artists_select_own ON public.user_preferred_artists FOR SELECT TO authenticated USING ((auth.uid() = user_id));


--
-- Name: user_preferred_genres; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.user_preferred_genres ENABLE ROW LEVEL SECURITY;

--
-- Name: user_preferred_genres user_preferred_genres_select_own; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY user_preferred_genres_select_own ON public.user_preferred_genres FOR SELECT TO authenticated USING ((auth.uid() = user_id));


--
-- Name: user_recent_items; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.user_recent_items ENABLE ROW LEVEL SECURITY;

--
-- Name: user_recent_items user_recent_items_delete_own; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY user_recent_items_delete_own ON public.user_recent_items FOR DELETE TO authenticated USING ((auth.uid() = user_id));


--
-- Name: user_recent_items user_recent_items_insert_own; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY user_recent_items_insert_own ON public.user_recent_items FOR INSERT TO authenticated WITH CHECK ((auth.uid() = user_id));


--
-- Name: user_recent_items user_recent_items_select_own; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY user_recent_items_select_own ON public.user_recent_items FOR SELECT TO authenticated USING ((auth.uid() = user_id));


--
-- Name: user_recent_items user_recent_items_update_own; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY user_recent_items_update_own ON public.user_recent_items FOR UPDATE TO authenticated USING ((auth.uid() = user_id)) WITH CHECK ((auth.uid() = user_id));


--
-- Name: user_recent_searches; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.user_recent_searches ENABLE ROW LEVEL SECURITY;

--
-- Name: user_recent_searches user_recent_searches_delete_own; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY user_recent_searches_delete_own ON public.user_recent_searches FOR DELETE TO authenticated USING ((auth.uid() = user_id));


--
-- Name: user_recent_searches user_recent_searches_insert_own; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY user_recent_searches_insert_own ON public.user_recent_searches FOR INSERT TO authenticated WITH CHECK ((auth.uid() = user_id));


--
-- Name: user_recent_searches user_recent_searches_select_own; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY user_recent_searches_select_own ON public.user_recent_searches FOR SELECT TO authenticated USING ((auth.uid() = user_id));


--
-- Name: user_recent_searches user_recent_searches_update_own; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY user_recent_searches_update_own ON public.user_recent_searches FOR UPDATE TO authenticated USING ((auth.uid() = user_id)) WITH CHECK ((auth.uid() = user_id));


--
-- Name: user_saved_playlists; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.user_saved_playlists ENABLE ROW LEVEL SECURITY;

--
-- Name: user_saved_playlists user_saved_playlists_delete_own; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY user_saved_playlists_delete_own ON public.user_saved_playlists FOR DELETE TO authenticated USING ((auth.uid() = user_id));


--
-- Name: user_saved_playlists user_saved_playlists_insert_own; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY user_saved_playlists_insert_own ON public.user_saved_playlists FOR INSERT TO authenticated WITH CHECK ((auth.uid() = user_id));


--
-- Name: user_saved_playlists user_saved_playlists_select_own; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY user_saved_playlists_select_own ON public.user_saved_playlists FOR SELECT TO authenticated USING ((auth.uid() = user_id));


--
-- Name: supabase_realtime; Type: PUBLICATION; Schema: -; Owner: postgres
--

CREATE PUBLICATION supabase_realtime WITH (publish = 'insert, update, delete, truncate');


ALTER PUBLICATION supabase_realtime OWNER TO postgres;

--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT USAGE ON SCHEMA public TO postgres;
GRANT USAGE ON SCHEMA public TO anon;
GRANT USAGE ON SCHEMA public TO authenticated;
GRANT USAGE ON SCHEMA public TO service_role;


--
-- Name: FUNCTION armor(bytea); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.armor(bytea) FROM postgres;
GRANT ALL ON FUNCTION extensions.armor(bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.armor(bytea) TO dashboard_user;


--
-- Name: FUNCTION armor(bytea, text[], text[]); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.armor(bytea, text[], text[]) FROM postgres;
GRANT ALL ON FUNCTION extensions.armor(bytea, text[], text[]) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.armor(bytea, text[], text[]) TO dashboard_user;


--
-- Name: FUNCTION crypt(text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.crypt(text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.crypt(text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.crypt(text, text) TO dashboard_user;


--
-- Name: FUNCTION dearmor(text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.dearmor(text) FROM postgres;
GRANT ALL ON FUNCTION extensions.dearmor(text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.dearmor(text) TO dashboard_user;


--
-- Name: FUNCTION decrypt(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.decrypt(bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.decrypt(bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.decrypt(bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION decrypt_iv(bytea, bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.decrypt_iv(bytea, bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.decrypt_iv(bytea, bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.decrypt_iv(bytea, bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION digest(bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.digest(bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.digest(bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.digest(bytea, text) TO dashboard_user;


--
-- Name: FUNCTION digest(text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.digest(text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.digest(text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.digest(text, text) TO dashboard_user;


--
-- Name: FUNCTION encrypt(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.encrypt(bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.encrypt(bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.encrypt(bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION encrypt_iv(bytea, bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.encrypt_iv(bytea, bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.encrypt_iv(bytea, bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.encrypt_iv(bytea, bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION gen_random_bytes(integer); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.gen_random_bytes(integer) FROM postgres;
GRANT ALL ON FUNCTION extensions.gen_random_bytes(integer) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.gen_random_bytes(integer) TO dashboard_user;


--
-- Name: FUNCTION gen_random_uuid(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.gen_random_uuid() FROM postgres;
GRANT ALL ON FUNCTION extensions.gen_random_uuid() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.gen_random_uuid() TO dashboard_user;


--
-- Name: FUNCTION gen_salt(text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.gen_salt(text) FROM postgres;
GRANT ALL ON FUNCTION extensions.gen_salt(text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.gen_salt(text) TO dashboard_user;


--
-- Name: FUNCTION gen_salt(text, integer); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.gen_salt(text, integer) FROM postgres;
GRANT ALL ON FUNCTION extensions.gen_salt(text, integer) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.gen_salt(text, integer) TO dashboard_user;


--
-- Name: FUNCTION hmac(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.hmac(bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.hmac(bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.hmac(bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION hmac(text, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.hmac(text, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.hmac(text, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.hmac(text, text, text) TO dashboard_user;


--
-- Name: FUNCTION pg_stat_statements(showtext boolean, OUT userid oid, OUT dbid oid, OUT toplevel boolean, OUT queryid bigint, OUT query text, OUT plans bigint, OUT total_plan_time double precision, OUT min_plan_time double precision, OUT max_plan_time double precision, OUT mean_plan_time double precision, OUT stddev_plan_time double precision, OUT calls bigint, OUT total_exec_time double precision, OUT min_exec_time double precision, OUT max_exec_time double precision, OUT mean_exec_time double precision, OUT stddev_exec_time double precision, OUT rows bigint, OUT shared_blks_hit bigint, OUT shared_blks_read bigint, OUT shared_blks_dirtied bigint, OUT shared_blks_written bigint, OUT local_blks_hit bigint, OUT local_blks_read bigint, OUT local_blks_dirtied bigint, OUT local_blks_written bigint, OUT temp_blks_read bigint, OUT temp_blks_written bigint, OUT shared_blk_read_time double precision, OUT shared_blk_write_time double precision, OUT local_blk_read_time double precision, OUT local_blk_write_time double precision, OUT temp_blk_read_time double precision, OUT temp_blk_write_time double precision, OUT wal_records bigint, OUT wal_fpi bigint, OUT wal_bytes numeric, OUT jit_functions bigint, OUT jit_generation_time double precision, OUT jit_inlining_count bigint, OUT jit_inlining_time double precision, OUT jit_optimization_count bigint, OUT jit_optimization_time double precision, OUT jit_emission_count bigint, OUT jit_emission_time double precision, OUT jit_deform_count bigint, OUT jit_deform_time double precision, OUT stats_since timestamp with time zone, OUT minmax_stats_since timestamp with time zone); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pg_stat_statements(showtext boolean, OUT userid oid, OUT dbid oid, OUT toplevel boolean, OUT queryid bigint, OUT query text, OUT plans bigint, OUT total_plan_time double precision, OUT min_plan_time double precision, OUT max_plan_time double precision, OUT mean_plan_time double precision, OUT stddev_plan_time double precision, OUT calls bigint, OUT total_exec_time double precision, OUT min_exec_time double precision, OUT max_exec_time double precision, OUT mean_exec_time double precision, OUT stddev_exec_time double precision, OUT rows bigint, OUT shared_blks_hit bigint, OUT shared_blks_read bigint, OUT shared_blks_dirtied bigint, OUT shared_blks_written bigint, OUT local_blks_hit bigint, OUT local_blks_read bigint, OUT local_blks_dirtied bigint, OUT local_blks_written bigint, OUT temp_blks_read bigint, OUT temp_blks_written bigint, OUT shared_blk_read_time double precision, OUT shared_blk_write_time double precision, OUT local_blk_read_time double precision, OUT local_blk_write_time double precision, OUT temp_blk_read_time double precision, OUT temp_blk_write_time double precision, OUT wal_records bigint, OUT wal_fpi bigint, OUT wal_bytes numeric, OUT jit_functions bigint, OUT jit_generation_time double precision, OUT jit_inlining_count bigint, OUT jit_inlining_time double precision, OUT jit_optimization_count bigint, OUT jit_optimization_time double precision, OUT jit_emission_count bigint, OUT jit_emission_time double precision, OUT jit_deform_count bigint, OUT jit_deform_time double precision, OUT stats_since timestamp with time zone, OUT minmax_stats_since timestamp with time zone) FROM postgres;
GRANT ALL ON FUNCTION extensions.pg_stat_statements(showtext boolean, OUT userid oid, OUT dbid oid, OUT toplevel boolean, OUT queryid bigint, OUT query text, OUT plans bigint, OUT total_plan_time double precision, OUT min_plan_time double precision, OUT max_plan_time double precision, OUT mean_plan_time double precision, OUT stddev_plan_time double precision, OUT calls bigint, OUT total_exec_time double precision, OUT min_exec_time double precision, OUT max_exec_time double precision, OUT mean_exec_time double precision, OUT stddev_exec_time double precision, OUT rows bigint, OUT shared_blks_hit bigint, OUT shared_blks_read bigint, OUT shared_blks_dirtied bigint, OUT shared_blks_written bigint, OUT local_blks_hit bigint, OUT local_blks_read bigint, OUT local_blks_dirtied bigint, OUT local_blks_written bigint, OUT temp_blks_read bigint, OUT temp_blks_written bigint, OUT shared_blk_read_time double precision, OUT shared_blk_write_time double precision, OUT local_blk_read_time double precision, OUT local_blk_write_time double precision, OUT temp_blk_read_time double precision, OUT temp_blk_write_time double precision, OUT wal_records bigint, OUT wal_fpi bigint, OUT wal_bytes numeric, OUT jit_functions bigint, OUT jit_generation_time double precision, OUT jit_inlining_count bigint, OUT jit_inlining_time double precision, OUT jit_optimization_count bigint, OUT jit_optimization_time double precision, OUT jit_emission_count bigint, OUT jit_emission_time double precision, OUT jit_deform_count bigint, OUT jit_deform_time double precision, OUT stats_since timestamp with time zone, OUT minmax_stats_since timestamp with time zone) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pg_stat_statements(showtext boolean, OUT userid oid, OUT dbid oid, OUT toplevel boolean, OUT queryid bigint, OUT query text, OUT plans bigint, OUT total_plan_time double precision, OUT min_plan_time double precision, OUT max_plan_time double precision, OUT mean_plan_time double precision, OUT stddev_plan_time double precision, OUT calls bigint, OUT total_exec_time double precision, OUT min_exec_time double precision, OUT max_exec_time double precision, OUT mean_exec_time double precision, OUT stddev_exec_time double precision, OUT rows bigint, OUT shared_blks_hit bigint, OUT shared_blks_read bigint, OUT shared_blks_dirtied bigint, OUT shared_blks_written bigint, OUT local_blks_hit bigint, OUT local_blks_read bigint, OUT local_blks_dirtied bigint, OUT local_blks_written bigint, OUT temp_blks_read bigint, OUT temp_blks_written bigint, OUT shared_blk_read_time double precision, OUT shared_blk_write_time double precision, OUT local_blk_read_time double precision, OUT local_blk_write_time double precision, OUT temp_blk_read_time double precision, OUT temp_blk_write_time double precision, OUT wal_records bigint, OUT wal_fpi bigint, OUT wal_bytes numeric, OUT jit_functions bigint, OUT jit_generation_time double precision, OUT jit_inlining_count bigint, OUT jit_inlining_time double precision, OUT jit_optimization_count bigint, OUT jit_optimization_time double precision, OUT jit_emission_count bigint, OUT jit_emission_time double precision, OUT jit_deform_count bigint, OUT jit_deform_time double precision, OUT stats_since timestamp with time zone, OUT minmax_stats_since timestamp with time zone) TO dashboard_user;


--
-- Name: FUNCTION pg_stat_statements_info(OUT dealloc bigint, OUT stats_reset timestamp with time zone); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pg_stat_statements_info(OUT dealloc bigint, OUT stats_reset timestamp with time zone) FROM postgres;
GRANT ALL ON FUNCTION extensions.pg_stat_statements_info(OUT dealloc bigint, OUT stats_reset timestamp with time zone) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pg_stat_statements_info(OUT dealloc bigint, OUT stats_reset timestamp with time zone) TO dashboard_user;


--
-- Name: FUNCTION pg_stat_statements_reset(userid oid, dbid oid, queryid bigint, minmax_only boolean); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pg_stat_statements_reset(userid oid, dbid oid, queryid bigint, minmax_only boolean) FROM postgres;
GRANT ALL ON FUNCTION extensions.pg_stat_statements_reset(userid oid, dbid oid, queryid bigint, minmax_only boolean) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pg_stat_statements_reset(userid oid, dbid oid, queryid bigint, minmax_only boolean) TO dashboard_user;


--
-- Name: FUNCTION pgp_armor_headers(text, OUT key text, OUT value text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_armor_headers(text, OUT key text, OUT value text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_armor_headers(text, OUT key text, OUT value text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_armor_headers(text, OUT key text, OUT value text) TO dashboard_user;


--
-- Name: FUNCTION pgp_key_id(bytea); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_key_id(bytea) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_key_id(bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_key_id(bytea) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_decrypt(bytea, bytea); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_decrypt(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_decrypt(bytea, bytea, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt(bytea, bytea, text, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_decrypt_bytea(bytea, bytea); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_decrypt_bytea(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_decrypt_bytea(bytea, bytea, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_decrypt_bytea(bytea, bytea, text, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_encrypt(text, bytea); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_encrypt(text, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt(text, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_encrypt_bytea(bytea, bytea); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea) TO dashboard_user;


--
-- Name: FUNCTION pgp_pub_encrypt_bytea(bytea, bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_pub_encrypt_bytea(bytea, bytea, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_decrypt(bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_decrypt(bytea, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt(bytea, text, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_decrypt_bytea(bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_decrypt_bytea(bytea, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_decrypt_bytea(bytea, text, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_encrypt(text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_encrypt(text, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt(text, text, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_encrypt_bytea(bytea, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text) TO dashboard_user;


--
-- Name: FUNCTION pgp_sym_encrypt_bytea(bytea, text, text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text, text) FROM postgres;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text, text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.pgp_sym_encrypt_bytea(bytea, text, text) TO dashboard_user;


--
-- Name: FUNCTION uuid_generate_v1(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_generate_v1() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_generate_v1() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_generate_v1() TO dashboard_user;


--
-- Name: FUNCTION uuid_generate_v1mc(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_generate_v1mc() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_generate_v1mc() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_generate_v1mc() TO dashboard_user;


--
-- Name: FUNCTION uuid_generate_v3(namespace uuid, name text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_generate_v3(namespace uuid, name text) FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_generate_v3(namespace uuid, name text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_generate_v3(namespace uuid, name text) TO dashboard_user;


--
-- Name: FUNCTION uuid_generate_v4(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_generate_v4() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_generate_v4() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_generate_v4() TO dashboard_user;


--
-- Name: FUNCTION uuid_generate_v5(namespace uuid, name text); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_generate_v5(namespace uuid, name text) FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_generate_v5(namespace uuid, name text) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_generate_v5(namespace uuid, name text) TO dashboard_user;


--
-- Name: FUNCTION uuid_nil(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_nil() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_nil() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_nil() TO dashboard_user;


--
-- Name: FUNCTION uuid_ns_dns(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_ns_dns() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_ns_dns() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_ns_dns() TO dashboard_user;


--
-- Name: FUNCTION uuid_ns_oid(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_ns_oid() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_ns_oid() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_ns_oid() TO dashboard_user;


--
-- Name: FUNCTION uuid_ns_url(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_ns_url() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_ns_url() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_ns_url() TO dashboard_user;


--
-- Name: FUNCTION uuid_ns_x500(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION extensions.uuid_ns_x500() FROM postgres;
GRANT ALL ON FUNCTION extensions.uuid_ns_x500() TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION extensions.uuid_ns_x500() TO dashboard_user;


--
-- Name: FUNCTION graphql("operationName" text, query text, variables jsonb, extensions jsonb); Type: ACL; Schema: graphql_public; Owner: supabase_admin
--

GRANT ALL ON FUNCTION graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb) TO postgres;
GRANT ALL ON FUNCTION graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb) TO anon;
GRANT ALL ON FUNCTION graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb) TO authenticated;
GRANT ALL ON FUNCTION graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb) TO service_role;


--
-- Name: FUNCTION pg_reload_conf(); Type: ACL; Schema: pg_catalog; Owner: supabase_admin
--

GRANT ALL ON FUNCTION pg_catalog.pg_reload_conf() TO postgres WITH GRANT OPTION;


--
-- Name: FUNCTION clear_user_player_state(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.clear_user_player_state() TO authenticated;
GRANT ALL ON FUNCTION public.clear_user_player_state() TO service_role;


--
-- Name: FUNCTION dislike_artist(p_artist_id uuid, p_reason text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.dislike_artist(p_artist_id uuid, p_reason text) TO authenticated;
GRANT ALL ON FUNCTION public.dislike_artist(p_artist_id uuid, p_reason text) TO service_role;


--
-- Name: FUNCTION dislike_song(p_song_id bigint, p_reason text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.dislike_song(p_song_id bigint, p_reason text) TO authenticated;
GRANT ALL ON FUNCTION public.dislike_song(p_song_id bigint, p_reason text) TO service_role;


--
-- Name: FUNCTION ensure_artist_month_rollover(p_artist_id uuid, p_reference_time timestamp with time zone); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.ensure_artist_month_rollover(p_artist_id uuid, p_reference_time timestamp with time zone) TO service_role;


--
-- Name: FUNCTION follow_artist(p_artist_id uuid, p_source_screen text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.follow_artist(p_artist_id uuid, p_source_screen text) TO authenticated;
GRANT ALL ON FUNCTION public.follow_artist(p_artist_id uuid, p_source_screen text) TO service_role;


--
-- Name: FUNCTION handle_album_artists_cache(); Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON FUNCTION public.handle_album_artists_cache() FROM PUBLIC;
GRANT ALL ON FUNCTION public.handle_album_artists_cache() TO service_role;


--
-- Name: FUNCTION handle_album_songs_cache(); Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON FUNCTION public.handle_album_songs_cache() FROM PUBLIC;
GRANT ALL ON FUNCTION public.handle_album_songs_cache() TO service_role;


--
-- Name: FUNCTION handle_channel_subscription_count(); Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON FUNCTION public.handle_channel_subscription_count() FROM PUBLIC;
GRANT ALL ON FUNCTION public.handle_channel_subscription_count() TO service_role;


--
-- Name: FUNCTION handle_favorites_like_count(); Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON FUNCTION public.handle_favorites_like_count() FROM PUBLIC;
GRANT ALL ON FUNCTION public.handle_favorites_like_count() TO service_role;


--
-- Name: FUNCTION handle_followed_artists_cache(); Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON FUNCTION public.handle_followed_artists_cache() FROM PUBLIC;
GRANT ALL ON FUNCTION public.handle_followed_artists_cache() TO service_role;


--
-- Name: FUNCTION handle_new_user(); Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON FUNCTION public.handle_new_user() FROM PUBLIC;
GRANT ALL ON FUNCTION public.handle_new_user() TO service_role;


--
-- Name: FUNCTION handle_playlist_songs_cache(); Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON FUNCTION public.handle_playlist_songs_cache() FROM PUBLIC;
GRANT ALL ON FUNCTION public.handle_playlist_songs_cache() TO service_role;


--
-- Name: FUNCTION handle_podcast_listen_count(); Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON FUNCTION public.handle_podcast_listen_count() FROM PUBLIC;
GRANT ALL ON FUNCTION public.handle_podcast_listen_count() TO service_role;


--
-- Name: FUNCTION handle_recent_searches_trending(); Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON FUNCTION public.handle_recent_searches_trending() FROM PUBLIC;
GRANT ALL ON FUNCTION public.handle_recent_searches_trending() TO service_role;


--
-- Name: FUNCTION handle_saved_playlists_cache(); Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON FUNCTION public.handle_saved_playlists_cache() FROM PUBLIC;
GRANT ALL ON FUNCTION public.handle_saved_playlists_cache() TO service_role;


--
-- Name: FUNCTION handle_song_artists_cache(); Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON FUNCTION public.handle_song_artists_cache() FROM PUBLIC;
GRANT ALL ON FUNCTION public.handle_song_artists_cache() TO service_role;


--
-- Name: FUNCTION handle_song_listen_after_insert(); Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON FUNCTION public.handle_song_listen_after_insert() FROM PUBLIC;
GRANT ALL ON FUNCTION public.handle_song_listen_after_insert() TO service_role;


--
-- Name: FUNCTION like_podcast(p_podcast_id uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.like_podcast(p_podcast_id uuid) TO authenticated;
GRANT ALL ON FUNCTION public.like_podcast(p_podcast_id uuid) TO service_role;


--
-- Name: FUNCTION like_song(p_song_id bigint, p_source_screen text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.like_song(p_song_id bigint, p_source_screen text) TO authenticated;
GRANT ALL ON FUNCTION public.like_song(p_song_id bigint, p_source_screen text) TO service_role;


--
-- Name: FUNCTION mark_album_opened(p_album_id bigint, p_source_screen text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.mark_album_opened(p_album_id bigint, p_source_screen text) TO authenticated;
GRANT ALL ON FUNCTION public.mark_album_opened(p_album_id bigint, p_source_screen text) TO service_role;


--
-- Name: FUNCTION mark_artist_opened(p_artist_id uuid, p_source_screen text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.mark_artist_opened(p_artist_id uuid, p_source_screen text) TO authenticated;
GRANT ALL ON FUNCTION public.mark_artist_opened(p_artist_id uuid, p_source_screen text) TO service_role;


--
-- Name: FUNCTION mark_hashtag_opened(p_hashtag_id bigint, p_source_screen text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.mark_hashtag_opened(p_hashtag_id bigint, p_source_screen text) TO authenticated;
GRANT ALL ON FUNCTION public.mark_hashtag_opened(p_hashtag_id bigint, p_source_screen text) TO service_role;


--
-- Name: FUNCTION mark_liked_songs_opened(p_source_screen text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.mark_liked_songs_opened(p_source_screen text) TO authenticated;
GRANT ALL ON FUNCTION public.mark_liked_songs_opened(p_source_screen text) TO service_role;


--
-- Name: FUNCTION mark_playlist_opened(p_playlist_id bigint, p_source_screen text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.mark_playlist_opened(p_playlist_id bigint, p_source_screen text) TO authenticated;
GRANT ALL ON FUNCTION public.mark_playlist_opened(p_playlist_id bigint, p_source_screen text) TO service_role;


--
-- Name: FUNCTION recalculate_album_track_cache(p_album_id bigint); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.recalculate_album_track_cache(p_album_id bigint) TO service_role;


--
-- Name: FUNCTION recalculate_artist_album_count(p_artist_id uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.recalculate_artist_album_count(p_artist_id uuid) TO service_role;


--
-- Name: FUNCTION recalculate_artist_song_count(p_artist_id uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.recalculate_artist_song_count(p_artist_id uuid) TO service_role;


--
-- Name: FUNCTION recalculate_playlist_song_count(p_playlist_id bigint); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.recalculate_playlist_song_count(p_playlist_id bigint) TO service_role;


--
-- Name: FUNCTION record_podcast_listen(p_podcast_id uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.record_podcast_listen(p_podcast_id uuid) TO authenticated;
GRANT ALL ON FUNCTION public.record_podcast_listen(p_podcast_id uuid) TO service_role;


--
-- Name: FUNCTION record_search_keyword(p_keyword text, p_source_screen text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.record_search_keyword(p_keyword text, p_source_screen text) TO authenticated;
GRANT ALL ON FUNCTION public.record_search_keyword(p_keyword text, p_source_screen text) TO service_role;


--
-- Name: FUNCTION record_song_listen(p_song_id bigint, p_source_playlist_id bigint, p_source_screen text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.record_song_listen(p_song_id bigint, p_source_playlist_id bigint, p_source_screen text) TO authenticated;
GRANT ALL ON FUNCTION public.record_song_listen(p_song_id bigint, p_source_playlist_id bigint, p_source_screen text) TO service_role;


--
-- Name: FUNCTION rollover_all_artists_monthly_stats(p_reference_time timestamp with time zone); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.rollover_all_artists_monthly_stats(p_reference_time timestamp with time zone) TO service_role;


--
-- Name: FUNCTION save_playlist(p_playlist_id bigint, p_source_screen text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.save_playlist(p_playlist_id bigint, p_source_screen text) TO authenticated;
GRANT ALL ON FUNCTION public.save_playlist(p_playlist_id bigint, p_source_screen text) TO service_role;


--
-- Name: FUNCTION set_user_player_state(p_song_id bigint, p_playlist_id bigint, p_position_seconds integer, p_is_playing boolean, p_shuffle_enabled boolean, p_repeat_mode text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.set_user_player_state(p_song_id bigint, p_playlist_id bigint, p_position_seconds integer, p_is_playing boolean, p_shuffle_enabled boolean, p_repeat_mode text) TO authenticated;
GRANT ALL ON FUNCTION public.set_user_player_state(p_song_id bigint, p_playlist_id bigint, p_position_seconds integer, p_is_playing boolean, p_shuffle_enabled boolean, p_repeat_mode text) TO service_role;


--
-- Name: FUNCTION subscribe_channel(p_channel_id uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.subscribe_channel(p_channel_id uuid) TO authenticated;
GRANT ALL ON FUNCTION public.subscribe_channel(p_channel_id uuid) TO service_role;


--
-- Name: FUNCTION subscribe_to_channel(p_channel_id uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.subscribe_to_channel(p_channel_id uuid) TO authenticated;
GRANT ALL ON FUNCTION public.subscribe_to_channel(p_channel_id uuid) TO service_role;


--
-- Name: FUNCTION undislike_artist(p_artist_id uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.undislike_artist(p_artist_id uuid) TO authenticated;
GRANT ALL ON FUNCTION public.undislike_artist(p_artist_id uuid) TO service_role;


--
-- Name: FUNCTION undislike_song(p_song_id bigint); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.undislike_song(p_song_id bigint) TO authenticated;
GRANT ALL ON FUNCTION public.undislike_song(p_song_id bigint) TO service_role;


--
-- Name: FUNCTION unfollow_artist(p_artist_id uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.unfollow_artist(p_artist_id uuid) TO authenticated;
GRANT ALL ON FUNCTION public.unfollow_artist(p_artist_id uuid) TO service_role;


--
-- Name: FUNCTION unlike_podcast(p_podcast_id uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.unlike_podcast(p_podcast_id uuid) TO authenticated;
GRANT ALL ON FUNCTION public.unlike_podcast(p_podcast_id uuid) TO service_role;


--
-- Name: FUNCTION unlike_song(p_song_id bigint); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.unlike_song(p_song_id bigint) TO authenticated;
GRANT ALL ON FUNCTION public.unlike_song(p_song_id bigint) TO service_role;


--
-- Name: FUNCTION unsave_playlist(p_playlist_id bigint); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.unsave_playlist(p_playlist_id bigint) TO authenticated;
GRANT ALL ON FUNCTION public.unsave_playlist(p_playlist_id bigint) TO service_role;


--
-- Name: FUNCTION unsubscribe_channel(p_channel_id uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.unsubscribe_channel(p_channel_id uuid) TO authenticated;
GRANT ALL ON FUNCTION public.unsubscribe_channel(p_channel_id uuid) TO service_role;


--
-- Name: FUNCTION unsubscribe_from_channel(p_channel_id uuid); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.unsubscribe_from_channel(p_channel_id uuid) TO authenticated;
GRANT ALL ON FUNCTION public.unsubscribe_from_channel(p_channel_id uuid) TO service_role;


--
-- Name: FUNCTION upsert_user_recent_item(p_user_id uuid, p_item_type text, p_item_key text, p_time timestamp with time zone, p_interaction_type text, p_source_screen text); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.upsert_user_recent_item(p_user_id uuid, p_item_type text, p_item_key text, p_time timestamp with time zone, p_interaction_type text, p_source_screen text) TO service_role;


--
-- Name: FUNCTION _crypto_aead_det_decrypt(message bytea, additional bytea, key_id bigint, context bytea, nonce bytea); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION vault._crypto_aead_det_decrypt(message bytea, additional bytea, key_id bigint, context bytea, nonce bytea) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION vault._crypto_aead_det_decrypt(message bytea, additional bytea, key_id bigint, context bytea, nonce bytea) TO service_role;


--
-- Name: FUNCTION create_secret(new_secret text, new_name text, new_description text, new_key_id uuid); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION vault.create_secret(new_secret text, new_name text, new_description text, new_key_id uuid) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION vault.create_secret(new_secret text, new_name text, new_description text, new_key_id uuid) TO service_role;


--
-- Name: FUNCTION update_secret(secret_id uuid, new_secret text, new_name text, new_description text, new_key_id uuid); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION vault.update_secret(secret_id uuid, new_secret text, new_name text, new_description text, new_key_id uuid) TO postgres WITH GRANT OPTION;
GRANT ALL ON FUNCTION vault.update_secret(secret_id uuid, new_secret text, new_name text, new_description text, new_key_id uuid) TO service_role;


--
-- Name: TABLE pg_stat_statements; Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON TABLE extensions.pg_stat_statements FROM postgres;
GRANT ALL ON TABLE extensions.pg_stat_statements TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE extensions.pg_stat_statements TO dashboard_user;


--
-- Name: TABLE pg_stat_statements_info; Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON TABLE extensions.pg_stat_statements_info FROM postgres;
GRANT ALL ON TABLE extensions.pg_stat_statements_info TO postgres WITH GRANT OPTION;
GRANT ALL ON TABLE extensions.pg_stat_statements_info TO dashboard_user;


--
-- Name: TABLE album_artists; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.album_artists TO anon;
GRANT ALL ON TABLE public.album_artists TO authenticated;
GRANT ALL ON TABLE public.album_artists TO service_role;


--
-- Name: TABLE album_songs; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.album_songs TO anon;
GRANT ALL ON TABLE public.album_songs TO authenticated;
GRANT ALL ON TABLE public.album_songs TO service_role;


--
-- Name: TABLE albums; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.albums TO anon;
GRANT ALL ON TABLE public.albums TO authenticated;
GRANT ALL ON TABLE public.albums TO service_role;


--
-- Name: SEQUENCE albums_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.albums_id_seq TO anon;
GRANT ALL ON SEQUENCE public.albums_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.albums_id_seq TO service_role;


--
-- Name: TABLE artists; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.artists TO anon;
GRANT ALL ON TABLE public.artists TO authenticated;
GRANT ALL ON TABLE public.artists TO service_role;


--
-- Name: TABLE channel_subscriptions; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.channel_subscriptions TO anon;
GRANT ALL ON TABLE public.channel_subscriptions TO authenticated;
GRANT ALL ON TABLE public.channel_subscriptions TO service_role;


--
-- Name: TABLE favorites; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.favorites TO anon;
GRANT ALL ON TABLE public.favorites TO authenticated;
GRANT ALL ON TABLE public.favorites TO service_role;


--
-- Name: SEQUENCE favorites_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.favorites_id_seq TO anon;
GRANT ALL ON SEQUENCE public.favorites_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.favorites_id_seq TO service_role;


--
-- Name: TABLE genres; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.genres TO anon;
GRANT ALL ON TABLE public.genres TO authenticated;
GRANT ALL ON TABLE public.genres TO service_role;


--
-- Name: SEQUENCE genres_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.genres_id_seq TO anon;
GRANT ALL ON SEQUENCE public.genres_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.genres_id_seq TO service_role;


--
-- Name: TABLE hashtags; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.hashtags TO anon;
GRANT ALL ON TABLE public.hashtags TO authenticated;
GRANT ALL ON TABLE public.hashtags TO service_role;


--
-- Name: SEQUENCE hashtags_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.hashtags_id_seq TO anon;
GRANT ALL ON SEQUENCE public.hashtags_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.hashtags_id_seq TO service_role;


--
-- Name: TABLE home_banners; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.home_banners TO anon;
GRANT ALL ON TABLE public.home_banners TO authenticated;
GRANT ALL ON TABLE public.home_banners TO service_role;


--
-- Name: SEQUENCE home_banners_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.home_banners_id_seq TO anon;
GRANT ALL ON SEQUENCE public.home_banners_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.home_banners_id_seq TO service_role;


--
-- Name: TABLE home_section_items; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.home_section_items TO anon;
GRANT ALL ON TABLE public.home_section_items TO authenticated;
GRANT ALL ON TABLE public.home_section_items TO service_role;


--
-- Name: SEQUENCE home_section_items_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.home_section_items_id_seq TO anon;
GRANT ALL ON SEQUENCE public.home_section_items_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.home_section_items_id_seq TO service_role;


--
-- Name: TABLE home_sections; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.home_sections TO anon;
GRANT ALL ON TABLE public.home_sections TO authenticated;
GRANT ALL ON TABLE public.home_sections TO service_role;


--
-- Name: SEQUENCE home_sections_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.home_sections_id_seq TO anon;
GRANT ALL ON SEQUENCE public.home_sections_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.home_sections_id_seq TO service_role;


--
-- Name: TABLE listens; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.listens TO anon;
GRANT ALL ON TABLE public.listens TO authenticated;
GRANT ALL ON TABLE public.listens TO service_role;


--
-- Name: SEQUENCE listens_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.listens_id_seq TO anon;
GRANT ALL ON SEQUENCE public.listens_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.listens_id_seq TO service_role;


--
-- Name: TABLE moods; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.moods TO anon;
GRANT ALL ON TABLE public.moods TO authenticated;
GRANT ALL ON TABLE public.moods TO service_role;


--
-- Name: SEQUENCE moods_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.moods_id_seq TO anon;
GRANT ALL ON SEQUENCE public.moods_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.moods_id_seq TO service_role;


--
-- Name: TABLE playlist_songs; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.playlist_songs TO anon;
GRANT ALL ON TABLE public.playlist_songs TO authenticated;
GRANT ALL ON TABLE public.playlist_songs TO service_role;


--
-- Name: SEQUENCE playlist_songs_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.playlist_songs_id_seq TO anon;
GRANT ALL ON SEQUENCE public.playlist_songs_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.playlist_songs_id_seq TO service_role;


--
-- Name: TABLE playlists; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.playlists TO anon;
GRANT ALL ON TABLE public.playlists TO authenticated;
GRANT ALL ON TABLE public.playlists TO service_role;


--
-- Name: SEQUENCE playlists_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.playlists_id_seq TO anon;
GRANT ALL ON SEQUENCE public.playlists_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.playlists_id_seq TO service_role;


--
-- Name: TABLE podcast_channels; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.podcast_channels TO anon;
GRANT ALL ON TABLE public.podcast_channels TO authenticated;
GRANT ALL ON TABLE public.podcast_channels TO service_role;


--
-- Name: TABLE podcast_favorites; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.podcast_favorites TO anon;
GRANT ALL ON TABLE public.podcast_favorites TO authenticated;
GRANT ALL ON TABLE public.podcast_favorites TO service_role;


--
-- Name: TABLE podcast_listens; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.podcast_listens TO anon;
GRANT ALL ON TABLE public.podcast_listens TO authenticated;
GRANT ALL ON TABLE public.podcast_listens TO service_role;


--
-- Name: SEQUENCE podcast_listens_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.podcast_listens_id_seq TO anon;
GRANT ALL ON SEQUENCE public.podcast_listens_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.podcast_listens_id_seq TO service_role;


--
-- Name: TABLE podcasts; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.podcasts TO anon;
GRANT ALL ON TABLE public.podcasts TO authenticated;
GRANT ALL ON TABLE public.podcasts TO service_role;


--
-- Name: TABLE profiles; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.profiles TO anon;
GRANT ALL ON TABLE public.profiles TO authenticated;
GRANT ALL ON TABLE public.profiles TO service_role;


--
-- Name: TABLE song_artists; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.song_artists TO anon;
GRANT ALL ON TABLE public.song_artists TO authenticated;
GRANT ALL ON TABLE public.song_artists TO service_role;


--
-- Name: TABLE song_genres; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.song_genres TO anon;
GRANT ALL ON TABLE public.song_genres TO authenticated;
GRANT ALL ON TABLE public.song_genres TO service_role;


--
-- Name: TABLE song_hashtags; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.song_hashtags TO anon;
GRANT ALL ON TABLE public.song_hashtags TO authenticated;
GRANT ALL ON TABLE public.song_hashtags TO service_role;


--
-- Name: SEQUENCE song_hashtags_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.song_hashtags_id_seq TO anon;
GRANT ALL ON SEQUENCE public.song_hashtags_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.song_hashtags_id_seq TO service_role;


--
-- Name: TABLE song_listens; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.song_listens TO anon;
GRANT ALL ON TABLE public.song_listens TO authenticated;
GRANT ALL ON TABLE public.song_listens TO service_role;


--
-- Name: SEQUENCE song_listens_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.song_listens_id_seq TO anon;
GRANT ALL ON SEQUENCE public.song_listens_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.song_listens_id_seq TO service_role;


--
-- Name: TABLE song_moods; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.song_moods TO anon;
GRANT ALL ON TABLE public.song_moods TO authenticated;
GRANT ALL ON TABLE public.song_moods TO service_role;


--
-- Name: TABLE songs; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.songs TO anon;
GRANT ALL ON TABLE public.songs TO authenticated;
GRANT ALL ON TABLE public.songs TO service_role;


--
-- Name: SEQUENCE songs_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.songs_id_seq TO anon;
GRANT ALL ON SEQUENCE public.songs_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.songs_id_seq TO service_role;


--
-- Name: TABLE trending_search_keywords; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.trending_search_keywords TO anon;
GRANT ALL ON TABLE public.trending_search_keywords TO authenticated;
GRANT ALL ON TABLE public.trending_search_keywords TO service_role;


--
-- Name: SEQUENCE trending_search_keywords_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.trending_search_keywords_id_seq TO anon;
GRANT ALL ON SEQUENCE public.trending_search_keywords_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.trending_search_keywords_id_seq TO service_role;


--
-- Name: TABLE user_disliked_artists; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.user_disliked_artists TO anon;
GRANT ALL ON TABLE public.user_disliked_artists TO authenticated;
GRANT ALL ON TABLE public.user_disliked_artists TO service_role;


--
-- Name: TABLE user_disliked_songs; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.user_disliked_songs TO anon;
GRANT ALL ON TABLE public.user_disliked_songs TO authenticated;
GRANT ALL ON TABLE public.user_disliked_songs TO service_role;


--
-- Name: TABLE user_followed_artists; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.user_followed_artists TO anon;
GRANT ALL ON TABLE public.user_followed_artists TO authenticated;
GRANT ALL ON TABLE public.user_followed_artists TO service_role;


--
-- Name: SEQUENCE user_followed_artists_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.user_followed_artists_id_seq TO anon;
GRANT ALL ON SEQUENCE public.user_followed_artists_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.user_followed_artists_id_seq TO service_role;


--
-- Name: TABLE user_player_state; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.user_player_state TO anon;
GRANT ALL ON TABLE public.user_player_state TO authenticated;
GRANT ALL ON TABLE public.user_player_state TO service_role;


--
-- Name: TABLE user_preferred_artists; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.user_preferred_artists TO anon;
GRANT ALL ON TABLE public.user_preferred_artists TO authenticated;
GRANT ALL ON TABLE public.user_preferred_artists TO service_role;


--
-- Name: TABLE user_preferred_genres; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.user_preferred_genres TO anon;
GRANT ALL ON TABLE public.user_preferred_genres TO authenticated;
GRANT ALL ON TABLE public.user_preferred_genres TO service_role;


--
-- Name: TABLE user_recent_items; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.user_recent_items TO anon;
GRANT ALL ON TABLE public.user_recent_items TO authenticated;
GRANT ALL ON TABLE public.user_recent_items TO service_role;


--
-- Name: SEQUENCE user_recent_items_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.user_recent_items_id_seq TO anon;
GRANT ALL ON SEQUENCE public.user_recent_items_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.user_recent_items_id_seq TO service_role;


--
-- Name: TABLE user_recent_searches; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.user_recent_searches TO anon;
GRANT ALL ON TABLE public.user_recent_searches TO authenticated;
GRANT ALL ON TABLE public.user_recent_searches TO service_role;


--
-- Name: SEQUENCE user_recent_searches_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.user_recent_searches_id_seq TO anon;
GRANT ALL ON SEQUENCE public.user_recent_searches_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.user_recent_searches_id_seq TO service_role;


--
-- Name: TABLE user_saved_playlists; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.user_saved_playlists TO anon;
GRANT ALL ON TABLE public.user_saved_playlists TO authenticated;
GRANT ALL ON TABLE public.user_saved_playlists TO service_role;


--
-- Name: SEQUENCE user_saved_playlists_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.user_saved_playlists_id_seq TO anon;
GRANT ALL ON SEQUENCE public.user_saved_playlists_id_seq TO authenticated;
GRANT ALL ON SEQUENCE public.user_saved_playlists_id_seq TO service_role;


--
-- Name: TABLE v_album_details_for_app; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.v_album_details_for_app TO anon;
GRANT ALL ON TABLE public.v_album_details_for_app TO authenticated;
GRANT ALL ON TABLE public.v_album_details_for_app TO service_role;


--
-- Name: TABLE v_albums_for_app; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.v_albums_for_app TO anon;
GRANT ALL ON TABLE public.v_albums_for_app TO authenticated;
GRANT ALL ON TABLE public.v_albums_for_app TO service_role;


--
-- Name: TABLE v_artist_details_for_app; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.v_artist_details_for_app TO anon;
GRANT ALL ON TABLE public.v_artist_details_for_app TO authenticated;
GRANT ALL ON TABLE public.v_artist_details_for_app TO service_role;


--
-- Name: TABLE v_artists_for_app; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.v_artists_for_app TO anon;
GRANT ALL ON TABLE public.v_artists_for_app TO authenticated;
GRANT ALL ON TABLE public.v_artists_for_app TO service_role;


--
-- Name: TABLE v_favorite_podcasts_for_app; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.v_favorite_podcasts_for_app TO anon;
GRANT ALL ON TABLE public.v_favorite_podcasts_for_app TO authenticated;
GRANT ALL ON TABLE public.v_favorite_podcasts_for_app TO service_role;


--
-- Name: TABLE v_genres_for_app; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.v_genres_for_app TO anon;
GRANT ALL ON TABLE public.v_genres_for_app TO authenticated;
GRANT ALL ON TABLE public.v_genres_for_app TO service_role;


--
-- Name: TABLE v_hashtags_for_app; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.v_hashtags_for_app TO anon;
GRANT ALL ON TABLE public.v_hashtags_for_app TO authenticated;
GRANT ALL ON TABLE public.v_hashtags_for_app TO service_role;


--
-- Name: TABLE v_home_banners_for_app; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.v_home_banners_for_app TO anon;
GRANT ALL ON TABLE public.v_home_banners_for_app TO authenticated;
GRANT ALL ON TABLE public.v_home_banners_for_app TO service_role;


--
-- Name: TABLE v_home_section_items_for_app; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.v_home_section_items_for_app TO anon;
GRANT ALL ON TABLE public.v_home_section_items_for_app TO authenticated;
GRANT ALL ON TABLE public.v_home_section_items_for_app TO service_role;


--
-- Name: TABLE v_home_sections_for_app; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.v_home_sections_for_app TO anon;
GRANT ALL ON TABLE public.v_home_sections_for_app TO authenticated;
GRANT ALL ON TABLE public.v_home_sections_for_app TO service_role;


--
-- Name: TABLE v_library_playlists_for_app; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.v_library_playlists_for_app TO anon;
GRANT ALL ON TABLE public.v_library_playlists_for_app TO authenticated;
GRANT ALL ON TABLE public.v_library_playlists_for_app TO service_role;


--
-- Name: TABLE v_moods_for_app; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.v_moods_for_app TO anon;
GRANT ALL ON TABLE public.v_moods_for_app TO authenticated;
GRANT ALL ON TABLE public.v_moods_for_app TO service_role;


--
-- Name: TABLE v_player_state_for_app; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.v_player_state_for_app TO anon;
GRANT ALL ON TABLE public.v_player_state_for_app TO authenticated;
GRANT ALL ON TABLE public.v_player_state_for_app TO service_role;


--
-- Name: TABLE v_podcasts; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.v_podcasts TO anon;
GRANT ALL ON TABLE public.v_podcasts TO authenticated;
GRANT ALL ON TABLE public.v_podcasts TO service_role;


--
-- Name: TABLE v_recent_items_for_app; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.v_recent_items_for_app TO anon;
GRANT ALL ON TABLE public.v_recent_items_for_app TO authenticated;
GRANT ALL ON TABLE public.v_recent_items_for_app TO service_role;


--
-- Name: TABLE v_recent_searches_for_app; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.v_recent_searches_for_app TO anon;
GRANT ALL ON TABLE public.v_recent_searches_for_app TO authenticated;
GRANT ALL ON TABLE public.v_recent_searches_for_app TO service_role;


--
-- Name: TABLE v_recent_song_history_for_app; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.v_recent_song_history_for_app TO anon;
GRANT ALL ON TABLE public.v_recent_song_history_for_app TO authenticated;
GRANT ALL ON TABLE public.v_recent_song_history_for_app TO service_role;


--
-- Name: TABLE v_song_details; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.v_song_details TO anon;
GRANT ALL ON TABLE public.v_song_details TO authenticated;
GRANT ALL ON TABLE public.v_song_details TO service_role;


--
-- Name: TABLE v_songs_by_hashtag_for_app; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.v_songs_by_hashtag_for_app TO anon;
GRANT ALL ON TABLE public.v_songs_by_hashtag_for_app TO authenticated;
GRANT ALL ON TABLE public.v_songs_by_hashtag_for_app TO service_role;


--
-- Name: TABLE v_songs_for_app; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.v_songs_for_app TO anon;
GRANT ALL ON TABLE public.v_songs_for_app TO authenticated;
GRANT ALL ON TABLE public.v_songs_for_app TO service_role;


--
-- Name: TABLE v_trending_search_keywords_for_app; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.v_trending_search_keywords_for_app TO anon;
GRANT ALL ON TABLE public.v_trending_search_keywords_for_app TO authenticated;
GRANT ALL ON TABLE public.v_trending_search_keywords_for_app TO service_role;


--
-- Name: TABLE secrets; Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT SELECT,REFERENCES,DELETE,TRUNCATE ON TABLE vault.secrets TO postgres WITH GRANT OPTION;
GRANT SELECT,DELETE ON TABLE vault.secrets TO service_role;


--
-- Name: TABLE decrypted_secrets; Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT SELECT,REFERENCES,DELETE,TRUNCATE ON TABLE vault.decrypted_secrets TO postgres WITH GRANT OPTION;
GRANT SELECT,DELETE ON TABLE vault.decrypted_secrets TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON SEQUENCES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON FUNCTIONS TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA graphql_public GRANT ALL ON TABLES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON TABLES TO service_role;


--
-- Name: issue_graphql_placeholder; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER issue_graphql_placeholder ON sql_drop
         WHEN TAG IN ('DROP EXTENSION')
   EXECUTE FUNCTION extensions.set_graphql_placeholder();


ALTER EVENT TRIGGER issue_graphql_placeholder OWNER TO supabase_admin;

--
-- Name: issue_pg_cron_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER issue_pg_cron_access ON ddl_command_end
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION extensions.grant_pg_cron_access();


ALTER EVENT TRIGGER issue_pg_cron_access OWNER TO supabase_admin;

--
-- Name: issue_pg_graphql_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER issue_pg_graphql_access ON ddl_command_end
         WHEN TAG IN ('CREATE FUNCTION')
   EXECUTE FUNCTION extensions.grant_pg_graphql_access();


ALTER EVENT TRIGGER issue_pg_graphql_access OWNER TO supabase_admin;

--
-- Name: issue_pg_net_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER issue_pg_net_access ON ddl_command_end
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION extensions.grant_pg_net_access();


ALTER EVENT TRIGGER issue_pg_net_access OWNER TO supabase_admin;

--
-- Name: pgrst_ddl_watch; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER pgrst_ddl_watch ON ddl_command_end
   EXECUTE FUNCTION extensions.pgrst_ddl_watch();


ALTER EVENT TRIGGER pgrst_ddl_watch OWNER TO supabase_admin;

--
-- Name: pgrst_drop_watch; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER pgrst_drop_watch ON sql_drop
   EXECUTE FUNCTION extensions.pgrst_drop_watch();


ALTER EVENT TRIGGER pgrst_drop_watch OWNER TO supabase_admin;

--
-- PostgreSQL database dump complete
--

\unrestrict iNWr7apgr2iSZtpAkVs84lMeetbzjbpfmkSDjczggckHYxgb1fdtIVjOOYAu2wD

