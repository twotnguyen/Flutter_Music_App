--
-- PostgreSQL database dump
--

\restrict q5UIohGgtZUb9exTGdiDQdWut1MHP8gQKD7s77y1uyp7QaS0QBzMNhoYvNN2T4x

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.11 (Debian 17.11-1.pgdg13+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: albums; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.albums (id, external_id, title, cover_file, cover_url, description, release_date, album_type, is_active, total_tracks_cache, total_duration_seconds_cache, created_at) FROM stdin;
1	album_01	Sơn Tùng MTP Collection	theresnooneatall.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/theresnooneatall.jpg	Tuyển tập bài hát nổi bật của Sơn Tùng MTP	2024-06-10	compilation	t	4	0	2026-03-23 01:17:10.637931+00
2	album_02	The Weeknd Highlights	DieForYou.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/DieForYou.jpg	Những ca khúc nổi bật của The Weeknd	2024-03-01	compilation	t	3	0	2026-03-23 01:17:10.637931+00
3	album_03	Billie Eilish Mix	BIRDSOFAFEATHER.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/BIRDSOFAFEATHER.jpg	Album tổng hợp các bài nổi bật của Billie Eilish	2024-07-15	compilation	t	4	0	2026-03-23 01:17:10.637931+00
4	album_04	B Ray Collection	FeelAtHome.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/FeelAtHome.jpg	Các bài hát nổi bật của B Ray	2024-08-20	compilation	t	4	0	2026-03-23 01:17:10.637931+00
5	album_05	RPT MCK Night Vibes	ToiNayTaDiDauNho.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/ToiNayTaDiDauNho.jpg	Những bài phù hợp cho đêm khuya	2024-05-05	album	t	3	0	2026-03-23 01:17:10.637931+00
6	album_06	Chill Việt Vol.1	binhyen.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/binhyen.jpg	Những bài chill nhẹ nhàng của Việt Nam	2024-03-18	compilation	t	5	0	2026-03-23 01:17:10.637931+00
7	album_07	International Viral Hits	DieWithASmile.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/DieWithASmile.jpg	Bộ sưu tập nhạc quốc tế viral	2024-02-14	compilation	t	3	0	2026-03-23 01:17:10.637931+00
8	album_08	Dangrangto Essentials	totchoanh.png	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/totchoanh.png	Những bài nổi bật của Dangrangto	2024-04-10	compilation	t	3	0	2026-03-23 01:17:10.637931+00
\.


--
-- Data for Name: artists; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.artists (id, name, avatar_file, avatar_url, cover_url, bio, verified, country, debut_year, followers_count_cache, songs_count_cache, albums_count_cache, monthly_listeners_previous, monthly_listeners_current, monthly_previous_month, monthly_current_month, created_at, updated_at, user_id) FROM stdin;
0b208b81-4be1-42f9-97a7-36d16f72ba49	Vũ	Vu.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/Vu.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/Vu.jpg	\N	f	\N	\N	0	1	1	0	13	\N	2026-03-01	2026-03-23 01:17:10.637931+00	2026-03-27 20:59:48.876434+00	\N
b96e41ee-da36-4680-bcb1-880d847a13db	The Flob	TheFlob.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/TheFlob.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/TheFlob.jpg	\N	f	\N	\N	0	1	0	0	0	\N	2026-03-01	2026-03-23 01:17:10.637931+00	2026-03-23 01:17:10.637931+00	\N
2c54789f-18bd-4896-ade7-eab81414eb00	CHIN	Chin.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/Chin.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/Chin.jpg	\N	f	\N	\N	0	1	0	0	0	\N	2026-03-01	2026-03-23 01:17:10.637931+00	2026-03-23 01:17:10.637931+00	\N
f957e5f1-9264-437f-984d-381651e7b4ee	Hà Lê	HaLe.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/HaLe.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/HaLe.jpg	\N	f	\N	\N	0	1	0	0	0	\N	2026-03-01	2026-03-23 01:17:10.637931+00	2026-03-23 01:17:10.637931+00	\N
8a5446b3-7072-44e9-bf5b-24ad8a4415cd	LVK	LVK.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/LVK.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/LVK.jpg	\N	f	\N	\N	0	1	0	0	0	\N	2026-03-01	2026-03-23 01:17:10.637931+00	2026-03-23 01:17:10.637931+00	\N
cbe6dabd-7354-4086-948a-8dc4e9d35070	RPT Groovie	RPTGroovie.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/RPTGroovie.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/RPTGroovie.jpg	\N	f	\N	\N	0	1	0	0	4	\N	2026-03-01	2026-03-23 01:17:10.637931+00	2026-03-24 23:03:54.034369+00	\N
b1bf7bb9-5c3a-4313-a384-b82acbb48283	tlinh	tlinh.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/tlinh.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/tlinh.jpg	\N	f	\N	\N	0	4	0	5	5	\N	2026-03-01	2026-03-23 01:17:10.637931+00	2026-03-24 23:03:54.034369+00	\N
438b19f6-e22c-41f0-9ef8-d76fdb281e6e	Binz	Binz.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/Binz.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/Binz.jpg	\N	f	\N	\N	0	2	0	0	13	\N	2026-03-01	2026-03-23 01:17:10.637931+00	2026-03-27 20:59:48.876434+00	\N
2c432bc5-6d7c-4de1-9154-0d034396f500	TeuYungBoy	TeuYungBoy.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/TeuYungBoy.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/TeuYungBoy.jpg	\N	f	\N	\N	0	2	0	0	0	\N	2026-03-01	2026-03-23 01:17:10.637931+00	2026-03-23 01:17:10.637931+00	\N
a0a852dd-1cf9-4c3a-9094-1c485ff3aec7	Wxrdie	Wxrdie.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/Wxrdie.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/Wxrdie.jpg	\N	f	\N	\N	0	4	0	0	3	\N	2026-03-01	2026-03-23 01:17:10.637931+00	2026-03-24 23:09:11.183052+00	\N
4da91679-8a35-479b-a12a-b91031da063a	Táo	Tao.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/Tao.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/Tao.jpg	\N	f	\N	\N	0	1	0	0	2	\N	2026-03-01	2026-03-23 01:17:10.637931+00	2026-03-31 07:13:45.009427+00	\N
8de0ac59-ebcc-401e-84c0-bfedd47e5ad5	Thắng	Thang.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/Thang.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/Thang.jpg	\N	f	\N	\N	1	1	0	0	0	\N	2026-03-01	2026-03-23 01:17:10.637931+00	2026-04-05 10:34:49.534633+00	\N
860f19de-29a2-4a2a-8e28-3a0feb576f07	NHONHO	NHONHO.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/NHONHO.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/NHONHO.jpg	\N	f	\N	\N	1	1	0	0	0	\N	2026-03-01	2026-03-23 01:17:10.637931+00	2026-04-05 11:06:33.226375+00	\N
a0a60440-9df7-4ccd-8021-c7027b1298ea	HIEUTHUHAI	HIEUTHUHAI.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/HIEUTHUHAI.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/HIEUTHUHAI.jpg	\N	f	\N	\N	0	2	0	0	0	\N	2026-03-01	2026-03-23 01:17:10.637931+00	2026-03-23 01:17:10.637931+00	\N
0a7cadbf-5842-4d61-a901-94718f7cbd46	DMT	DMT.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/DMT.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/DMT.jpg	\N	f	\N	\N	0	1	0	0	0	\N	2026-03-01	2026-03-23 01:17:10.637931+00	2026-03-23 01:17:10.637931+00	\N
282f88e3-637b-44a5-bd65-eb19e16bdb37	Khoi Vu	KhoiVu.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/KhoiVu.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/KhoiVu.jpg	\N	f	\N	\N	0	1	0	0	0	\N	2026-03-01	2026-03-23 01:17:10.637931+00	2026-03-23 01:17:10.637931+00	\N
3c1543e9-e414-48c9-bcc0-90f2208640e5	MAYDAYs	MAYDAYs.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/MAYDAYs.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/MAYDAYs.jpg	\N	f	\N	\N	0	1	0	0	0	\N	2026-03-01	2026-03-23 01:17:10.637931+00	2026-03-23 01:17:10.637931+00	\N
d367e696-a291-44d1-aef7-d62092a7cf3d	Minh Tốc	MinhToc.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/MinhToc.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/MinhToc.jpg	\N	f	\N	\N	0	1	0	0	0	\N	2026-03-01	2026-03-23 01:17:10.637931+00	2026-03-23 01:17:10.637931+00	\N
82afc3dc-30df-4a60-a5a0-a43506efcfda	buitruonglinh	buitruonglinh.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/buitruonglinh.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/buitruonglinh.jpg	\N	f	\N	\N	0	1	0	0	0	\N	2026-03-01	2026-03-23 01:17:10.637931+00	2026-03-23 01:17:10.637931+00	\N
89416404-1f37-40f7-974c-6921f23792e6	vuphungtien	vuphungtien.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/vuphungtien.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/vuphungtien.jpg	\N	f	\N	\N	0	1	0	0	0	\N	2026-03-01	2026-03-23 01:17:10.637931+00	2026-03-23 01:17:10.637931+00	\N
69aebe09-58f2-4c82-a98f-067f458a8b68	Dương Domic	DuongDomic.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/DuongDomic.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/DuongDomic.jpg	\N	f	\N	\N	0	1	0	0	0	\N	2026-03-01	2026-03-23 01:17:10.637931+00	2026-03-23 01:17:10.637931+00	\N
da00a97c-9f38-4830-918b-1682133e554a	Khalid	Khalid.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/Khalid.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/Khalid.jpg	\N	f	\N	\N	0	1	0	0	2	\N	2026-03-01	2026-03-23 01:17:10.637931+00	2026-03-24 14:17:09.980007+00	\N
ae7f7346-a837-47ea-a00e-2d90630de3a7	Obito	Obito.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/Obito.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/Obito.jpg	\N	f	\N	\N	0	3	0	0	0	\N	2026-03-01	2026-03-23 01:17:10.637931+00	2026-03-23 01:17:10.637931+00	\N
99d1a5e7-09bf-4426-81db-d3205afeec25	Cao Minh Thiên Tùng	CaoMinhThienTung.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/CaoMinhThienTung.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/CaoMinhThienTung.jpg	\N	f	\N	\N	0	1	0	0	0	\N	2026-03-01	2026-03-23 01:17:10.637931+00	2026-03-23 01:17:10.637931+00	\N
126403af-6197-4acb-9596-14e44bf9480f	Playboi Carti	PlayboiCarti.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/PlayboiCarti.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/PlayboiCarti.jpg	\N	f	\N	\N	0	2	0	0	1	\N	2026-03-01	2026-03-23 01:17:10.637931+00	2026-03-24 14:02:39.550902+00	\N
cf8db550-c1b1-4d1a-9476-72a2e6f07351	Shiki	Shiki.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/Shiki.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/Shiki.jpg	\N	f	\N	\N	1	1	0	0	0	\N	2026-03-01	2026-03-23 01:17:10.637931+00	2026-04-03 07:15:24.807604+00	\N
1070aeb4-69a6-4a75-9ec1-28da1b455cdc	Travis Scott	TravisScott.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/TravisScott.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/TravisScott.jpg	\N	f	\N	\N	0	1	0	0	1	\N	2026-03-01	2026-03-23 01:17:10.637931+00	2026-03-24 14:02:39.550902+00	\N
1ba78362-f6f5-4070-aa80-ee2dffa0f316	tangduytan	TangDuyTan.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/TangDuyTan.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/TangDuyTan.jpg	\N	f	\N	\N	0	1	0	0	1	\N	2026-03-01	2026-03-23 01:17:10.637931+00	2026-03-24 16:16:02.665307+00	\N
75da20e9-d8f2-4025-b4d2-b56d710aebd0	Roddy Ricch	RoddyRicch.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/RoddyRicch.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/RoddyRicch.jpg	\N	f	\N	\N	0	1	0	0	0	\N	2026-03-01	2026-03-23 01:17:10.637931+00	2026-03-23 01:17:10.637931+00	\N
26a3c206-fc12-47b0-a7eb-a733dc2c68ac	7dnight	7dnight.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/7dnight.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/7dnight.jpg	\N	f	\N	\N	0	1	0	0	0	\N	2026-03-01	2026-03-23 01:17:10.637931+00	2026-03-23 01:17:10.637931+00	\N
79fdd720-1d63-4d94-bce7-197ed89f5fb7	MONO	Mono.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/Mono.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/Mono.jpg	\N	f	\N	\N	0	1	0	0	0	\N	2026-03-01	2026-03-23 01:17:10.637931+00	2026-03-23 01:17:10.637931+00	\N
275f3f7c-ff8e-4112-8c08-a5ab71a33d57	XXXTENTACION	XXXTENTACION.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/XXXTENTACION.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/XXXTENTACION.jpg	\N	f	\N	\N	0	1	0	0	0	\N	2026-03-01	2026-03-23 01:17:10.637931+00	2026-03-23 01:17:10.637931+00	\N
c1558f28-48b4-4c56-81bc-22956238afc7	Richie D. ICY	RichieDICY.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/RichieDICY.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/RichieDICY.jpg	\N	f	\N	\N	0	1	0	0	0	\N	2026-03-01	2026-03-23 01:17:10.637931+00	2026-03-23 01:17:10.637931+00	\N
d76686d4-d196-433a-b87b-921e3b7da72f	Phong Max	PhongMax.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/PhongMax.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/PhongMax.jpg	\N	f	\N	\N	0	1	0	0	1	\N	2026-03-01	2026-03-23 01:17:10.637931+00	2026-03-24 16:16:02.665307+00	\N
6158d472-3722-46d5-9fe5-1a3101d6e24b	Low G	LowG.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/LowG.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/LowG.jpg	\N	f	\N	\N	1	1	0	0	0	\N	2026-03-01	2026-03-23 01:17:10.637931+00	2026-04-03 07:15:08.661642+00	\N
5eeeea72-b859-445d-80c2-7dd524208cff	T.R.I	TRI.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/TRI.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/TRI.jpg	\N	f	\N	\N	0	1	0	0	1	\N	2026-03-01	2026-03-23 01:17:10.637931+00	2026-03-24 16:16:02.665307+00	\N
58d12164-cf39-4ecb-ae2e-dfa0f76809e4	Lady Gaga	LadyGaga.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/LadyGaga.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/LadyGaga.jpg	\N	f	\N	\N	0	1	1	0	1	\N	2026-03-01	2026-03-23 01:17:10.637931+00	2026-03-23 03:18:05.587109+00	\N
1d01f8d4-af31-4271-a972-23e70eab8a6d	The Weeknd	TheWeeknd.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/TheWeeknd.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/TheWeeknd.jpg	\N	f	\N	\N	0	3	1	0	0	\N	2026-03-01	2026-03-23 01:17:10.637931+00	2026-03-23 01:17:10.637931+00	\N
941294a4-a8d6-40c6-9d79-d71f96fd3be2	RPT MCK	RPTMCK.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/RPTMCK.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/RPTMCK.jpg	\N	f	\N	\N	0	4	1	0	9	\N	2026-03-01	2026-03-23 01:17:10.637931+00	2026-03-24 23:03:54.034369+00	\N
7da092c2-9fbe-4171-96b6-a6e2a6b82042	52Hz	52Hz.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/52Hz.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/52Hz.jpg	\N	f	\N	\N	0	1	1	0	0	\N	2026-03-01	2026-03-23 01:17:10.637931+00	2026-03-23 01:17:10.637931+00	\N
a1cf6887-2d7b-43eb-abed-c009b1f2dbb8	Thịnh Suy	ThinhSuy.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/ThinhSuy.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/ThinhSuy.jpg	\N	f	\N	\N	0	1	1	0	0	\N	2026-03-01	2026-03-23 01:17:10.637931+00	2026-03-23 01:17:10.637931+00	\N
7ae8f347-8fda-4db7-af7f-521914e3944d	WREN EVANS	WrenEvans.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/WrenEvans.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/WrenEvans.jpg	\N	f	\N	\N	0	1	1	0	0	\N	2026-03-01	2026-03-23 01:17:10.637931+00	2026-03-23 01:17:10.637931+00	\N
644c5c8b-a4b5-4514-bb6b-f3ec0c66a96f	LIL BABY	LilBaby.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/LilBaby.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/LilBaby.jpg	\N	f	\N	\N	0	1	1	0	0	\N	2026-03-01	2026-03-23 01:17:10.637931+00	2026-03-23 01:17:10.637931+00	\N
8b4ceb2e-0366-493d-83a0-2a9320fedfd7	CENTRAL CEE	CentralCee.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/CentralCee.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/CentralCee.jpg	\N	f	\N	\N	0	1	1	0	0	\N	2026-03-01	2026-03-23 01:17:10.637931+00	2026-03-23 01:17:10.637931+00	\N
661c1836-ae0a-4ac3-a452-ecdb5bc81e89	Kalmi	Kalmi.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/Kalmi.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/Kalmi.jpg	\N	f	\N	\N	0	1	1	0	1	\N	2026-03-01	2026-03-23 01:17:10.637931+00	2026-03-23 03:18:10.396546+00	\N
2faf0c38-90eb-4e4d-b385-60702b1c1633	Bruno Mars	BrunoMars.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/BrunoMars.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/BrunoMars.jpg	\N	f	\N	\N	0	1	1	0	1	\N	2026-03-01	2026-03-23 01:17:10.637931+00	2026-03-23 03:18:05.587109+00	\N
f678e8c8-57cf-4ced-a787-83b35788b7c8	Billie Eilish	BillieEilish.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/BillieEilish.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/BillieEilish.jpg	\N	f	\N	\N	0	4	1	0	2	\N	2026-03-01	2026-03-23 01:17:10.637931+00	2026-03-24 14:17:09.980007+00	\N
9fb2ae7f-b38f-4e78-ae2f-c6f58d4549fa	Hanumankind	Hanumankind.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/Hanumankind.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/Hanumankind.jpg	\N	f	\N	\N	0	1	1	0	1	\N	2026-03-01	2026-03-23 01:17:10.637931+00	2026-03-23 03:18:10.396546+00	\N
55e33fdc-9249-4eac-8a32-80d8af20aec2	Sơn Tùng MTP	SonTungMTP.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/SonTungMTP.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/SonTungMTP.jpg	\N	f	\N	\N	0	4	1	0	28	\N	2026-03-01	2026-03-23 01:17:10.637931+00	2026-03-24 14:02:42.290304+00	\N
770f6054-f072-49cf-a30a-5712175060cf	Trung Trần	TrungTran.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/TrungTran.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/TrungTran.jpg	\N	f	\N	\N	0	1	0	0	2	\N	2026-03-01	2026-03-23 01:17:10.637931+00	2026-03-24 16:15:49.779727+00	\N
2951ece2-3d85-49e5-a605-776ebfe81425	Dangrangto	Dangrangto.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/Dangrangto.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/Dangrangto.jpg	\N	f	\N	\N	0	5	1	0	2	\N	2026-03-01	2026-03-23 01:17:10.637931+00	2026-03-24 23:09:47.620324+00	\N
83fc2a9a-e886-4ef3-8a85-1d4d1e4af867	B Ray	BRay.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/BRay.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/BRay.jpg	\N	f	\N	\N	0	4	1	0	5	\N	2026-03-01	2026-03-23 01:17:10.637931+00	2026-03-31 08:38:57.47791+00	\N
9f07ef2d-ebc4-4aa6-af1d-1aef3c99b23b	Vũ Cát Tường	VuCatTuong.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/VuCatTuong.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/artist-avatars/VuCatTuong.jpg	\N	f	\N	\N	1	1	1	0	0	\N	2026-03-01	2026-03-23 01:17:10.637931+00	2026-04-03 07:14:53.038646+00	\N
\.


--
-- Data for Name: album_artists; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.album_artists (album_id, artist_id, artist_order, role, created_at) FROM stdin;
1	55e33fdc-9249-4eac-8a32-80d8af20aec2	1	primary	2026-03-23 01:17:10.637931+00
2	1d01f8d4-af31-4271-a972-23e70eab8a6d	1	primary	2026-03-23 01:17:10.637931+00
3	f678e8c8-57cf-4ced-a787-83b35788b7c8	1	primary	2026-03-23 01:17:10.637931+00
4	83fc2a9a-e886-4ef3-8a85-1d4d1e4af867	1	primary	2026-03-23 01:17:10.637931+00
5	941294a4-a8d6-40c6-9d79-d71f96fd3be2	1	primary	2026-03-23 01:17:10.637931+00
6	7da092c2-9fbe-4171-96b6-a6e2a6b82042	5	featured	2026-03-23 01:17:10.637931+00
6	a1cf6887-2d7b-43eb-abed-c009b1f2dbb8	4	featured	2026-03-23 01:17:10.637931+00
6	7ae8f347-8fda-4db7-af7f-521914e3944d	3	featured	2026-03-23 01:17:10.637931+00
6	9f07ef2d-ebc4-4aa6-af1d-1aef3c99b23b	2	featured	2026-03-23 01:17:10.637931+00
6	0b208b81-4be1-42f9-97a7-36d16f72ba49	1	primary	2026-03-23 01:17:10.637931+00
7	661c1836-ae0a-4ac3-a452-ecdb5bc81e89	6	featured	2026-03-23 01:17:10.637931+00
7	9fb2ae7f-b38f-4e78-ae2f-c6f58d4549fa	5	featured	2026-03-23 01:17:10.637931+00
7	644c5c8b-a4b5-4514-bb6b-f3ec0c66a96f	4	featured	2026-03-23 01:17:10.637931+00
7	8b4ceb2e-0366-493d-83a0-2a9320fedfd7	3	featured	2026-03-23 01:17:10.637931+00
7	2faf0c38-90eb-4e4d-b385-60702b1c1633	2	featured	2026-03-23 01:17:10.637931+00
7	58d12164-cf39-4ecb-ae2e-dfa0f76809e4	1	primary	2026-03-23 01:17:10.637931+00
8	2951ece2-3d85-49e5-a605-776ebfe81425	1	primary	2026-03-23 01:17:10.637931+00
\.


--
-- Data for Name: songs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.songs (id, external_id, title, artist, album_id, release_date, cover_file, cover_url, audio_file, audio_url, lyrics_file, lyrics_url, duration_seconds, total_listens, like_count_cache, is_active, created_at) FROM stdin;
2	song_02	Khế Ước	The Flob ft CHIN ft Hà Lê	\N	\N	kheuoc.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/kheuoc.jpg	kheuoc.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/song-files/kheuoc.mp3	kheuoc.lrc	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/lyrics-files/kheuoc.lrc	0	0	0	t	2026-03-23 01:17:10.637931+00
15	song_15	2GOILAYS	DMT ft Dangrangto ft TeuYungBoy	\N	\N	2GOILAYS.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/2GOILAYS.jpg	2GOILAYS.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/song-files/2GOILAYS.mp3	2GOILAYS.lrc	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/lyrics-files/2GOILAYS.lrc	0	0	0	t	2026-03-23 01:17:10.637931+00
5	song_05	Xích Thêm Chút	RPT Groovie ft tlinh ft RPT MCK	\N	\N	xtc.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/xtc.jpg	xtc.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/song-files/xtc.mp3	xtc.lrc	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/lyrics-files/xtc.lrc	0	4	1	t	2026-03-23 01:17:10.637931+00
3	song_03	Tim anh ghen	Wxrdie ft LVK ft Dangrangto ft TeuYungBoy	\N	\N	timanhghen.png	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/timanhghen.png	timanhghen.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/song-files/timanhghen.mp3	timanhghen.lrc	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/lyrics-files/timanhghen.lrc	0	0	0	t	2026-03-23 01:17:10.637931+00
13	song_13	NOLOVENOLIFE	HIEUTHUHAI	\N	\N	NOLOVENOLIFE.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/NOLOVENOLIFE.jpg	NOLOVENOLIFE.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/song-files/NOLOVENOLIFE.mp3	NOLOVENOLIFE.lrc	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/lyrics-files/NOLOVENOLIFE.lrc	0	0	0	t	2026-03-23 01:17:10.637931+00
16	song_16	Dạo Bước HongKong 1999	NHONHO	\N	\N	DAOBUOCHONGKONG1999.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/DAOBUOCHONGKONG1999.jpg	DAOBUOCHONGKONG1999.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/song-files/DAOBUOCHONGKONG1999.mp3	DAOBUOCHONGKONG1999.lrc	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/lyrics-files/DAOBUOCHONGKONG1999.lrc	0	0	1	t	2026-03-23 01:17:10.637931+00
18	song_18	BERLIN	Khoi Vu	\N	\N	BERLIN.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/BERLIN.jpg	BERLIN.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/song-files/BERLIN.mp3	BERLIN.lrc	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/lyrics-files/BERLIN.lrc	0	0	0	t	2026-03-23 01:17:10.637931+00
24	song_24	Phép Màu	MAYDAYs ft Minh Tốc	\N	\N	PhepMau.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/PhepMau.jpg	PhepMau.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/song-files/PhepMau.mp3	PhepMau.lrc	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/lyrics-files/PhepMau.lrc	0	0	0	t	2026-03-23 01:17:10.637931+00
27	song_27	Em	Binz	\N	\N	Em.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/Em.jpg	Em.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/song-files/Em.mp3	Em.lrc	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/lyrics-files/Em.lrc	0	0	0	t	2026-03-23 01:17:10.637931+00
28	song_28	1000 Ánh Mắt	Shiki ft Obito	\N	\N	1000AnhMat.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/1000AnhMat.jpg	1000AnhMat.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/song-files/1000AnhMat.mp3	1000AnhMat.lrc	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/lyrics-files/1000AnhMat.lrc	0	0	0	t	2026-03-23 01:17:10.637931+00
29	song_29	Tháp Yêu	Cao Minh Thiên Tùng	\N	\N	ThapYeu.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/ThapYeu.jpg	ThapYeu.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/song-files/ThapYeu.mp3	ThapYeu.lrc	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/lyrics-files/ThapYeu.lrc	0	0	0	t	2026-03-23 01:17:10.637931+00
30	song_30	Sài Gòn Ơi	Obito	\N	\N	SaiGonOi.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/SaiGonOi.jpg	SaiGonOi.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/song-files/SaiGonOi.mp3	SaiGonOi.lrc	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/lyrics-files/SaiGonOi.lrc	0	0	0	t	2026-03-23 01:17:10.637931+00
34	song_34	EVILJ0RDAN	Playboi Carti	\N	\N	EVILJ0RDAN.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/EVILJ0RDAN.jpg	EVILJ0RDAN.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/song-files/EVILJ0RDAN.mp3	EVILJ0RDAN.lrc	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/lyrics-files/EVILJ0RDAN.lrc	0	0	0	t	2026-03-23 01:17:10.637931+00
35	song_35	The Box	Roddy Ricch	\N	\N	TheBox.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/TheBox.jpg	TheBox.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/song-files/TheBox.mp3	TheBox.lrc	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/lyrics-files/TheBox.lrc	0	0	0	t	2026-03-23 01:17:10.637931+00
36	song_36	Cơm Áo Gạo Tiền	7dnight	\N	\N	ComAoGaoTien.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/ComAoGaoTien.jpg	ComAoGaoTien.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/song-files/ComAoGaoTien.mp3	ComAoGaoTien.lrc	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/lyrics-files/ComAoGaoTien.lrc	0	0	0	t	2026-03-23 01:17:10.637931+00
26	song_26	Mất Kết Nối	Dương Domic	\N	\N	MatKetNoi.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/MatKetNoi.jpg	MatKetNoi.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/song-files/MatKetNoi.mp3	MatKetNoi.lrc	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/lyrics-files/MatKetNoi.lrc	0	0	0	t	2026-03-23 01:17:10.637931+00
25	song_25	Em Không Khóc	buitruonglinh ft vuphungtien	\N	\N	EmKhongKhoc.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/EmKhongKhoc.jpg	EmKhongKhoc.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/song-files/EmKhongKhoc.mp3	EmKhongKhoc.lrc	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/lyrics-files/EmKhongKhoc.lrc	0	0	1	t	2026-03-23 01:17:10.637931+00
19	song_19	Blue Tequile	Táo	\N	\N	BlueTequile.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/BlueTequile.jpg	BlueTequile.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/song-files/BlueTequile.mp3	BlueTequile.lrc	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/lyrics-files/BlueTequile.lrc	0	2	0	t	2026-03-23 01:17:10.637931+00
37	song_37	FE!N	Travis Scott ft Playboi Carti	\N	\N	FE!N.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/FE!N.jpg	FE!N.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/song-files/FE!N.mp3	FE!N.lrc	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/lyrics-files/FE!N.lrc	0	1	0	t	2026-03-23 01:17:10.637931+00
22	song_22	Trước Khi Em Tồn Tại	Thắng	\N	\N	TruocKhiEmTonTai.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/TruocKhiEmTonTai.jpg	TruocKhiEmTonTai.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/song-files/TruocKhiEmTonTai.mp3	TruocKhiEmTonTai.lrc	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/lyrics-files/TruocKhiEmTonTai.lrc	0	0	0	t	2026-03-23 01:17:10.637931+00
44	song_44	SAD!	XXXTENTACION	\N	\N	SAD.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/SAD.jpg	SAD.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/song-files/SAD.mp3	SAD.lrc	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/lyrics-files/SAD.lrc	0	0	0	t	2026-03-23 01:17:10.637931+00
46	song_46	Giờ Thì Ai Cười	HIEUTHUHAI	\N	\N	GioThiAiCuoi.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/GioThiAiCuoi.jpg	GioThiAiCuoi.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/song-files/GioThiAiCuoi.mp3	GioThiAiCuoi.lrc	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/lyrics-files/GioThiAiCuoi.lrc	0	0	0	t	2026-03-23 01:17:10.637931+00
47	song_47	PHÓNG ZÌN ZÌN	Low G x tlinh	\N	\N	PHONGZINZIN.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/PHONGZINZIN.jpg	PHONGZINZIN.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/song-files/PHONGZINZIN.mp3	PHONGZINZIN.lrc	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/lyrics-files/PHONGZINZIN.lrc	0	0	0	t	2026-03-23 01:17:10.637931+00
48	song_48	nếu lúc đó	tlinh	\N	\N	neulucdo.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/neulucdo.jpg	neulucdo.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/song-files/neulucdo.mp3	neulucdo.lrc	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/lyrics-files/neulucdo.lrc	0	0	0	t	2026-03-23 01:17:10.637931+00
55	song_55	CẦN GÌ NÓI IU	Wxrdie	\N	\N	CANGINoIU.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/CANGINoIU.jpg	CANGINoIU.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/song-files/CANGINoIU.mp3	CANGINoIU.lrc	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/lyrics-files/CANGINoIU.lrc	0	0	0	t	2026-03-23 01:17:10.637931+00
49	song_49	nữ siêu anh hùng	tlinh	\N	\N	nusuAnhHung.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/nusuAnhHung.jpg	nusuAnhHung.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/song-files/nusuAnhHung.mp3	nusuAnhHung.lrc	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/lyrics-files/nusuAnhHung.lrc	0	1	0	t	2026-03-23 01:17:10.637931+00
53	song_53	NU CEP	Wxrdie	\N	\N	NUCEP.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/NUCEP.jpg	NUCEP.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/song-files/NUCEP.mp3	NUCEP.lrc	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/lyrics-files/NUCEP.lrc	0	1	0	t	2026-03-23 01:17:10.637931+00
40	song_40	05 (Không Phai)	tangduytan ft T.R.I ft Phong Max	\N	\N	05KhongPhai.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/05KhongPhai.jpg	05KhongPhai.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/song-files/05KhongPhai.mp3	05KhongPhai.lrc	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/lyrics-files/05KhongPhai.lrc	0	1	0	t	2026-03-23 01:17:10.637931+00
45	song_45	MAY KIN THANH DO	Obito ft Richie D ICY	\N	\N	MAYKINTHANHDO.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/MAYKINTHANHDO.jpg	MAYKINTHANHDO.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/song-files/MAYKINTHANHDO.mp3	MAYKINTHANHDO.lrc	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/lyrics-files/MAYKINTHANHDO.lrc	0	0	0	t	2026-03-23 01:17:10.637931+00
54	song_54	0 AI NGHĨ	Wxrdie	\N	\N	0AINGHI.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/0AINGHI.jpg	0AINGHI.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/song-files/0AINGHI.mp3	0AINGHI.lrc	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/lyrics-files/0AINGHI.lrc	0	2	1	t	2026-03-23 01:17:10.637931+00
39	song_39	Waiting For You	MONO	\N	\N	WaitingForYou.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/WaitingForYou.jpg	WaitingForYou.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/song-files/WaitingForYou.mp3	WaitingForYou.lrc	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/lyrics-files/WaitingForYou.lrc	0	0	0	t	2026-03-23 01:17:10.637931+00
12	song_12	One Of The Girls	The Weeknd	2	2024-03-01	OneOfTheGirls.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/OneOfTheGirls.jpg	OneOfTheGirls.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/song-files/OneOfTheGirls.mp3	OneOfTheGirls.lrc	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/lyrics-files/OneOfTheGirls.lrc	0	0	0	t	2026-03-23 01:17:10.637931+00
11	song_11	Timeless	The Weeknd	2	2024-03-01	Timeless.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/Timeless.jpg	Timeless.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/song-files/Timeless.mp3	Timeless.lrc	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/lyrics-files/Timeless.lrc	0	0	0	t	2026-03-23 01:17:10.637931+00
10	song_10	Die For You	The Weeknd	2	2024-03-01	DieForYou.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/DieForYou.jpg	DieForYou.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/song-files/DieForYou.mp3	DieForYou.lrc	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/lyrics-files/DieForYou.lrc	0	0	0	t	2026-03-23 01:17:10.637931+00
43	song_43	when the party's over	Billie Eilish	3	2024-07-15	whenthepartysover.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/whenthepartysover.jpg	whenthepartysover.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/song-files/whenthepartysover.mp3	whenthepartysover.lrc	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/lyrics-files/whenthepartysover.lrc	0	0	0	t	2026-03-23 01:17:10.637931+00
42	song_42	bad guy	Billie Eilish	3	2024-07-15	badguy.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/badguy.jpg	badguy.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/song-files/badguy.mp3	badguy.lrc	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/lyrics-files/badguy.lrc	0	0	0	t	2026-03-23 01:17:10.637931+00
20	song_20	BIRDS OF A FEATHER	Billie Eilish	3	2024-07-15	BIRDSOFAFEATHER.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/BIRDSOFAFEATHER.jpg	BIRDSOFAFEATHER.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/song-files/BIRDSOFAFEATHER.mp3	BIRDSOFAFEATHER.lrc	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/lyrics-files/BIRDSOFAFEATHER.lrc	0	0	0	t	2026-03-23 01:17:10.637931+00
59	song_59	BẢN NHẠC BUỒN	B Ray	4	2024-08-20	BANNHACBUON.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/BANNHACBUON.jpg	BANNHACBUON.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/song-files/BANNHACBUON.mp3	BANNHACBUON.lrc	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/lyrics-files/BANNHACBUON.lrc	0	0	0	t	2026-03-23 01:17:10.637931+00
38	song_38	Em Của Ngày Hôm Qua	Sơn Tùng MTP	1	2024-06-10	EmCuaNgayHomQua.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/EmCuaNgayHomQua.jpg	EmCuaNgayHomQua.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/song-files/EmCuaNgayHomQua.mp3	EmCuaNgayHomQua.lrc	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/lyrics-files/EmCuaNgayHomQua.lrc	0	5	0	t	2026-03-23 01:17:10.637931+00
8	song_08	Chúng Ta Không Thuộc Về Nhau	Sơn Tùng MTP	1	2024-06-10	ChungtaKhongThuocVeNhau.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/ChungtaKhongThuocVeNhau.jpg	ChungtaKhongThuocVeNhau.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/song-files/ChungtaKhongThuocVeNhau.mp3	ChungtaKhongThuocVeNhau.lrc	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/lyrics-files/ChungtaKhongThuocVeNhau.lrc	0	7	0	t	2026-03-23 01:17:10.637931+00
7	song_07	Đừng Làm Trái Tim Anh Đau	Sơn Tùng MTP	1	2024-06-10	Dunglamtraitimanhdau.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/Dunglamtraitimanhdau.jpg	Dunglamtraitimanhdau.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/song-files/Dunglamtraitimanhdau.mp3	Dunglamtraitimanhdau.lrc	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/lyrics-files/Dunglamtraitimanhdau.lrc	0	9	0	t	2026-03-23 01:17:10.637931+00
41	song_41	lovely	Billie Eilish ft Khalid	3	2024-07-15	lovely.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/lovely.jpg	lovely.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/song-files/lovely.mp3	lovely.lrc	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/lyrics-files/lovely.lrc	0	2	0	t	2026-03-23 01:17:10.637931+00
60	song_60	BẢN NHẠC CUỐI (cho em)	B Ray	4	2024-08-20	BANNHACCUOI.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/BANNHACCUOI.jpg	BANNHACCUOI.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/song-files/BANNHACCUOI.mp3	BANNHACCUOI.lrc	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/lyrics-files/BANNHACCUOI.lrc	0	3	0	t	2026-03-23 01:17:10.637931+00
6	song_06	THERE'S NO ONE AT ALL	Sơn Tùng MTP	1	2024-06-10	theresnooneatall.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/theresnooneatall.jpg	theresnooneatall.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/song-files/theresnooneatall.mp3	theresnooneatall.lrc	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/lyrics-files/theresnooneatall.lrc	0	7	0	t	2026-03-23 01:17:10.637931+00
52	song_52	Cuốn Cho Anh Một Điếu Nữa Đi	RPT MCK	5	2024-05-05	CuonChoAnhMotDieuNuaDi.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/CuonChoAnhMotDieuNuaDi.jpg	CuonChoAnhMotDieuNuaDi.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/song-files/CuonChoAnhMotDieuNuaDi.mp3	CuonChoAnhMotDieuNuaDi.lrc	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/lyrics-files/CuonChoAnhMotDieuNuaDi.lrc	0	0	0	t	2026-03-23 01:17:10.637931+00
23	song_23	tinylove	Thịnh Suy	6	2024-03-18	tinylove.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/tinylove.jpg	tinylove.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/song-files/tinylove.mp3	tinylove.lrc	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/lyrics-files/tinylove.lrc	0	0	0	t	2026-03-23 01:17:10.637931+00
17	song_17	Từng Quen	WREN EVANS	6	2024-03-18	TUNGQUEN.png	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/TUNGQUEN.png	TUNGQUEN.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/song-files/TUNGQUEN.mp3	TUNGQUEN.lrc	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/lyrics-files/TUNGQUEN.lrc	0	0	0	t	2026-03-23 01:17:10.637931+00
9	song_09	Từng Là	Vũ Cát Tường	6	2024-03-18	TungLa.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/TungLa.jpg	TungLa.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/song-files/TungLa.mp3	TungLa.lrc	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/lyrics-files/TungLa.lrc	0	0	0	t	2026-03-23 01:17:10.637931+00
4	song_04	Tốt cho anh	Dangrangto	8	2024-04-10	totchoanh.png	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/totchoanh.png	totchoanh.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/song-files/totchoanh.mp3	totchoanh.lrc	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/lyrics-files/totchoanh.lrc	0	0	0	t	2026-03-23 01:17:10.637931+00
21	song_21	Die With A Smile	Lady Gaga ft Bruno Mars	7	2024-02-14	DieWithASmile.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/DieWithASmile.jpg	DieWithASmile.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/song-files/DieWithASmile.mp3	DieWithASmile.lrc	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/lyrics-files/DieWithASmile.lrc	0	1	0	t	2026-03-23 01:17:10.637931+00
14	song_14	Tối Nay Ta Đi Đâu Nhờ	RPT MCK	5	2024-05-05	ToiNayTaDiDauNho.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/ToiNayTaDiDauNho.jpg	ToiNayTaDiDauNho.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/song-files/ToiNayTaDiDauNho.mp3	ToiNayTaDiDauNho.lrc	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/lyrics-files/ToiNayTaDiDauNho.lrc	0	3	0	t	2026-03-23 01:17:10.637931+00
58	song_58	Y Chang Em	B Ray	4	2024-08-20	YChangEm.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/YChangEm.jpg	YChangEm.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/song-files/YChangEm.mp3	YChangEm.lrc	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/lyrics-files/YChangEm.lrc	0	2	0	t	2026-03-23 01:17:10.637931+00
32	song_32	BAND4BAND	CENTRAL CEE FT LIL BABY	7	2024-02-14	BAND4BAND.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/BAND4BAND.jpg	BAND4BAND.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/song-files/BAND4BAND.mp3	BAND4BAND.lrc	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/lyrics-files/BAND4BAND.lrc	0	0	0	t	2026-03-23 01:17:10.637931+00
51	song_51	Chìm Sâu	RPT MCK ft Trung Trần	5	2024-05-05	ChimSau.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/ChimSau.jpg	ChimSau.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/song-files/ChimSau.mp3	ChimSau.lrc	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/lyrics-files/ChimSau.lrc	0	2	0	t	2026-03-23 01:17:10.637931+00
33	song_33	BigDawgs	Hanumankind Ft Kalmi	7	2024-02-14	BigDawgs.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/BigDawgs.jpg	BigDawgs.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/song-files/BigDawgs.mp3	BigDawgs.lrc	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/lyrics-files/BigDawgs.lrc	0	1	0	t	2026-03-23 01:17:10.637931+00
56	song_56	MOIEM	Dangrangto	8	2024-04-10	MOIEM.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/MOIEM.jpg	MOIEM.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/song-files/MOIEM.mp3	MOIEM.lrc	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/lyrics-files/MOIEM.lrc	0	1	0	t	2026-03-23 01:17:10.637931+00
31	song_31	Love is	Dangrangto	8	2024-04-10	Loveis.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/Loveis.jpg	Loveis.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/song-files/Loveis.mp3	Loveis.lrc	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/lyrics-files/Loveis.lrc	0	1	1	t	2026-03-23 01:17:10.637931+00
57	song_57	Feel At Home	B Ray	4	2024-08-20	FeelAtHome.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/FeelAtHome.jpg	FeelAtHome.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/song-files/FeelAtHome.mp3	FeelAtHome.lrc	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/lyrics-files/FeelAtHome.lrc	0	0	0	t	2026-03-23 01:17:10.637931+00
50	song_50	Đợi	52Hz	6	2024-03-18	DOI.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/DOI.jpg	DOI.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/song-files/DOI.mp3	DOI.lrc	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/lyrics-files/DOI.lrc	0	0	0	t	2026-03-23 01:17:10.637931+00
1	song_01	Bình yên	Vũ ft Binz	6	2024-03-18	binhyen.jpg	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/binhyen.jpg	binhyen.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/song-files/binhyen.mp3	binhyen.lrc	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/lyrics-files/binhyen.lrc	0	13	1	t	2026-03-23 01:17:10.637931+00
\.


--
-- Data for Name: album_songs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.album_songs (album_id, song_id, track_number, disc_number, created_at) FROM stdin;
1	38	4	1	2026-03-23 01:17:10.637931+00
1	8	3	1	2026-03-23 01:17:10.637931+00
1	7	2	1	2026-03-23 01:17:10.637931+00
1	6	1	1	2026-03-23 01:17:10.637931+00
2	12	3	1	2026-03-23 01:17:10.637931+00
2	11	2	1	2026-03-23 01:17:10.637931+00
2	10	1	1	2026-03-23 01:17:10.637931+00
3	43	4	1	2026-03-23 01:17:10.637931+00
3	42	3	1	2026-03-23 01:17:10.637931+00
3	41	2	1	2026-03-23 01:17:10.637931+00
3	20	1	1	2026-03-23 01:17:10.637931+00
4	60	4	1	2026-03-23 01:17:10.637931+00
4	59	3	1	2026-03-23 01:17:10.637931+00
4	58	2	1	2026-03-23 01:17:10.637931+00
4	57	1	1	2026-03-23 01:17:10.637931+00
5	52	3	1	2026-03-23 01:17:10.637931+00
5	51	2	1	2026-03-23 01:17:10.637931+00
5	14	1	1	2026-03-23 01:17:10.637931+00
6	50	5	1	2026-03-23 01:17:10.637931+00
6	23	4	1	2026-03-23 01:17:10.637931+00
6	17	3	1	2026-03-23 01:17:10.637931+00
6	9	2	1	2026-03-23 01:17:10.637931+00
6	1	1	1	2026-03-23 01:17:10.637931+00
7	33	3	1	2026-03-23 01:17:10.637931+00
7	32	2	1	2026-03-23 01:17:10.637931+00
7	21	1	1	2026-03-23 01:17:10.637931+00
8	56	3	1	2026-03-23 01:17:10.637931+00
8	31	2	1	2026-03-23 01:17:10.637931+00
8	4	1	1	2026-03-23 01:17:10.637931+00
\.


--
-- Data for Name: podcast_channels; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.podcast_channels (id, name, avatar_url, subscriber_count, created_at) FROM stdin;
a15ee6da-8083-4cfc-9b57-95fe76fa59eb	Vì sao thế nhỉ ?	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/channel-avatars/ViSaoTheNhi.jpg	0	2026-03-23 01:17:10.637931+00
3f4121fc-8b13-42d8-bcb8-34e7bbc9932a	SuperTeo	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/channel-avatars/SuperTeo.jpg	0	2026-03-23 01:17:10.637931+00
257008db-0c77-4ce2-9d22-73b8623cab90	Beyond Limits	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/channel-avatars/BeyondLimits.jpg	0	2026-03-23 01:17:10.637931+00
a767ec26-4075-4611-b357-982559259230	The English Class	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/channel-avatars/TheEnglishClass.jpg	0	2026-03-23 01:17:10.637931+00
d5f0edbd-6aa5-43f4-8575-11438250b18d	Ruby Nguyen	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/channel-avatars/RubyNguyen.jpg	0	2026-03-23 01:17:10.637931+00
f7954bd7-5a02-44ea-bc85-d75ba150661b	Đom Đóm Studios	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/channel-avatars/DomDomStudios.jpg	0	2026-03-23 01:17:10.637931+00
dbbe8e5b-8abb-4301-9785-f73eb74d4a55	Breath	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/channel-avatars/Breath.jpg	0	2026-03-23 01:17:10.637931+00
1ada4a9a-e6c2-4784-8407-08ffb80a23e7	Ngọc Tiệp Minato	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/channel-avatars/NgocTiepMinato.jpg	1	2026-03-23 01:17:10.637931+00
9b6228a0-89b7-4054-963e-8a6a51899301	Web5Ngay	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/channel-avatars/Web5Ngay.jpg	1	2026-03-23 01:17:10.637931+00
\.


--
-- Data for Name: channel_subscriptions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.channel_subscriptions (id, user_id, channel_id, created_at) FROM stdin;
5a498694-5df3-44da-9077-f7cfe1351b2e	bb659d1e-e400-4fac-9125-b34873a5bd94	1ada4a9a-e6c2-4784-8407-08ffb80a23e7	2026-03-23 03:17:29.011289+00
89a1a3d5-76cb-4468-bb2d-238dfe102fde	bb659d1e-e400-4fac-9125-b34873a5bd94	9b6228a0-89b7-4054-963e-8a6a51899301	2026-04-01 20:25:20.784034+00
64703fd8-33a2-46ca-9402-a9eec942c2e4	bb659d1e-e400-4fac-9125-b34873a5bd94	dbbe8e5b-8abb-4301-9785-f73eb74d4a55	2026-04-05 11:30:38.886934+00
\.


--
-- Data for Name: favorites; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.favorites (id, user_id, song_id, created_at) FROM stdin;
1	bb659d1e-e400-4fac-9125-b34873a5bd94	54	2026-03-24 23:04:37.219132+00
5	bb659d1e-e400-4fac-9125-b34873a5bd94	1	2026-03-31 23:31:49.989373+00
6	bb659d1e-e400-4fac-9125-b34873a5bd94	31	2026-04-01 08:32:48.331027+00
7	bb659d1e-e400-4fac-9125-b34873a5bd94	25	2026-04-01 08:39:22.074517+00
9	bb659d1e-e400-4fac-9125-b34873a5bd94	16	2026-04-01 08:40:52.325657+00
10	bb659d1e-e400-4fac-9125-b34873a5bd94	5	2026-04-01 08:40:55.212263+00
\.


--
-- Data for Name: genres; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.genres (id, name, slug, description, cover_url, is_active, created_at) FROM stdin;
1	Pop	pop	Những bài nhạc pop dễ nghe và phổ biến	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/WaitingForYou.jpg	t	2026-03-23 01:17:10.637931+00
2	Rap	rap	Nhịp điệu mạnh, lời rap nổi bật	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/ToiNayTaDiDauNho.jpg	t	2026-03-23 01:17:10.637931+00
3	Indie	indie	Nhạc indie nhẹ nhàng và cảm xúc	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/binhyen.jpg	t	2026-03-23 01:17:10.637931+00
4	Lofi	lofi	Chậm rãi, thư giãn, phù hợp khi học tập	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/ChimSau.jpg	t	2026-03-23 01:17:10.637931+00
5	R&B	rnb	Mềm mại, hiện đại, giàu cảm xúc	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/DieWithASmile.jpg	t	2026-03-23 01:17:10.637931+00
6	Hip Hop	hip-hop	Hip hop và trap hiện đại	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/PHONGZINZIN.jpg	t	2026-03-23 01:17:10.637931+00
\.


--
-- Data for Name: hashtags; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.hashtags (id, name, slug, description, cover_url, is_active, created_at, updated_at) FROM stdin;
1	#nhachaynhatthang3	nhachaynhatthang3	Những bài nổi bật và được nghe nhiều trong tháng 3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/theresnooneatall.jpg	t	2026-03-23 01:17:10.637931+00	2026-03-23 01:17:10.637931+00
2	#chillcuoituan	chillcuoituan	Nhạc chill nhẹ cho cuối tuần	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/binhyen.jpg	t	2026-03-23 01:17:10.637931+00	2026-03-23 01:17:10.637931+00
3	#nhaccodedem	nhaccodedem	Những bài phù hợp khi học hoặc code đêm	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/ChimSau.jpg	t	2026-03-23 01:17:10.637931+00	2026-03-23 01:17:10.637931+00
4	#buontamtrang	buontamtrang	Các bài hát buồn, suy tư	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/DOI.jpg	t	2026-03-23 01:17:10.637931+00	2026-03-23 01:17:10.637931+00
5	#viralquocTe	viralquocte	Bài hát quốc tế đang viral và dễ được đề xuất	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/DieWithASmile.jpg	t	2026-03-23 01:17:10.637931+00	2026-03-23 01:17:10.637931+00
\.


--
-- Data for Name: home_banners; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.home_banners (id, title, subtitle, image_url, action_type, action_value, display_order, is_active, starts_at, ends_at, created_at) FROM stdin;
1	Playlist tuần này	Top Hits và những bài đang được nghe nhiều	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/theresnooneatall.jpg	playlist	1	1	t	\N	\N	2026-03-23 01:17:10.637931+00
2	#nhachaynhatthang3	Khám phá chủ đề đang được đề xuất trên trang tìm kiếm	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/WaitingForYou.jpg	hashtag	1	2	t	\N	\N	2026-03-23 01:17:10.637931+00
3	Album mới phát hành	Mở nhanh các album nổi bật trong app	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/DieWithASmile.jpg	album	3	3	t	\N	\N	2026-03-23 01:17:10.637931+00
\.


--
-- Data for Name: home_sections; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.home_sections (id, code, title, subtitle, section_type, display_order, item_limit, is_active, created_at) FROM stdin;
1	recently_played	Nghe gần đây	Lấy từ lịch sử của từng user	recent	1	10	t	2026-03-23 01:17:10.637931+00
2	featured_playlists	Playlist tuần này	Các playlist hệ thống và nổi bật	playlist	2	10	t	2026-03-23 01:17:10.637931+00
3	featured_artists	Nghệ sĩ nổi bật	Theo dõi và nghe nhiều trong tháng	artist	3	10	t	2026-03-23 01:17:10.637931+00
4	new_albums	Album mới phát hành	Những album vừa thêm vào hệ thống	album	4	10	t	2026-03-23 01:17:10.637931+00
5	mood_focus	Tập trung học tập	Đề xuất theo tâm trạng	mood	5	10	t	2026-03-23 01:17:10.637931+00
6	trending_hashtags	Hashtag nổi bật	Chủ đề và bộ sưu tập đang được đề xuất	hashtag	6	10	t	2026-03-23 01:17:10.637931+00
\.


--
-- Data for Name: home_section_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.home_section_items (id, section_id, item_type, item_key, display_order, is_active, created_at) FROM stdin;
1	2	playlist	1	1	t	2026-03-23 01:17:10.637931+00
2	2	playlist	2	2	t	2026-03-23 01:17:10.637931+00
3	2	playlist	3	3	t	2026-03-23 01:17:10.637931+00
4	2	playlist	4	4	t	2026-03-23 01:17:10.637931+00
5	3	artist	55e33fdc-9249-4eac-8a32-80d8af20aec2	1	t	2026-03-23 01:17:10.637931+00
6	3	artist	1d01f8d4-af31-4271-a972-23e70eab8a6d	2	t	2026-03-23 01:17:10.637931+00
7	3	artist	f678e8c8-57cf-4ced-a787-83b35788b7c8	3	t	2026-03-23 01:17:10.637931+00
8	3	artist	83fc2a9a-e886-4ef3-8a85-1d4d1e4af867	4	t	2026-03-23 01:17:10.637931+00
9	4	album	1	1	t	2026-03-23 01:17:10.637931+00
10	4	album	3	2	t	2026-03-23 01:17:10.637931+00
11	4	album	5	3	t	2026-03-23 01:17:10.637931+00
12	4	album	8	4	t	2026-03-23 01:17:10.637931+00
13	5	mood	4	1	t	2026-03-23 01:17:10.637931+00
14	5	mood	1	2	t	2026-03-23 01:17:10.637931+00
15	5	mood	3	3	t	2026-03-23 01:17:10.637931+00
16	6	hashtag	1	1	t	2026-03-23 01:17:10.637931+00
17	6	hashtag	2	2	t	2026-03-23 01:17:10.637931+00
18	6	hashtag	3	3	t	2026-03-23 01:17:10.637931+00
19	6	hashtag	5	4	t	2026-03-23 01:17:10.637931+00
\.


--
-- Data for Name: podcasts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.podcasts (id, external_id, title, channel_id, audio_url, cover_url, lyrics_url, duration_seconds, listen_count, is_active, created_at) FROM stdin;
626288b2-939a-4a1f-b73d-318fad0aecb0	podcast_08	YÊU THƯƠNG BẢN THÂN & TỰ CHỮA LÀNH	d5f0edbd-6aa5-43f4-8575-11438250b18d	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/podcast-files/YeuThuongBanThanVaTuChuaLanh.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/podcast-covers/YeuThuongBanThanVaTuChuaLanh.jpg	\N	0	0	t	2026-03-23 01:17:10.637931+00
f4552a82-50c7-46ef-bdb1-64c8d3e36e51	podcast_09	Tự học và CHINH PHỤC MỌI KỸ NĂNG chỉ trong 20 giờ	257008db-0c77-4ce2-9d22-73b8623cab90	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/podcast-files/TuHocVaChinhPhucMoiKyNangChiTrong20Gio.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/podcast-covers/TuHocVaChinhPhucMoiKyNangChiTrong20Gio.jpg	\N	0	0	t	2026-03-23 01:17:10.637931+00
17cba416-0a32-46bc-be89-7d3927280d9a	podcast_10	6 BÍ KÍP CẢI THIỆN KỸ NĂNG GIAO TIẾP	f7954bd7-5a02-44ea-bc85-d75ba150661b	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/podcast-files/6BiKipCaiThienKyNangGiaoTiep.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/podcast-covers/6BiKipCaiThienKyNangGiaoTiep.jpg	\N	0	0	t	2026-03-23 01:17:10.637931+00
5442963e-396d-48ee-b170-6a0e8ea548e3	podcast_04	7 phút thiền buổi sáng	dbbe8e5b-8abb-4301-9785-f73eb74d4a55	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/podcast-files/7phutthienbuoisang.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/podcast-covers/7phutthienbuoisang.jpg	\N	0	1	t	2026-03-23 01:17:10.637931+00
02cddb96-843a-4ac7-b584-4ded977bf448	podcast_03	Đừng bao giờ từ bỏ con đường học	1ada4a9a-e6c2-4784-8407-08ffb80a23e7	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/podcast-files/DungBaoGioTuBoConDuongHoc.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/podcast-covers/DungBaoGioTuBoConDuongHoc.jpg	\N	0	2	t	2026-03-23 01:17:10.637931+00
96dd8651-4044-4008-b35e-fce298fadb4f	podcast_02	Tham Vọng nhưng Lười Biếng	3f4121fc-8b13-42d8-bcb8-34e7bbc9932a	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/podcast-files/ThamVongNhungLuiBieng.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/podcast-covers/ThamVongNhungLuiBieng.jpg	\N	0	9	t	2026-03-23 01:17:10.637931+00
c7806c11-64d0-4491-a567-e6925ab44d5e	podcast_06	Làm sao để NGHIỆN HỌC NHƯ NGHIỆN MẠNG XÃ HỘI?	257008db-0c77-4ce2-9d22-73b8623cab90	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/podcast-files/LamSaoDeNghienHocNhuNghienMangXaHoi.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/podcast-covers/LamSaoDeNghienHocNhuNghienMangXaHoi.jpg	\N	0	1	t	2026-03-23 01:17:10.637931+00
c61b8dcf-e714-4495-a1ee-53209222b70b	podcast_05	Hoàn Thành Mọi Việc Quá Dễ	9b6228a0-89b7-4054-963e-8a6a51899301	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/podcast-files/HoanThanhMoiViecQuaDe.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/podcast-covers/HoanThanhMoiViecQuaDe.jpg	\N	0	1	t	2026-03-23 01:17:10.637931+00
f5251bd3-61b5-432f-bd9f-6d94d5c7c88e	podcast_07	How to Understand English Movies Without Subtitles	a767ec26-4075-4611-b357-982559259230	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/podcast-files/HowToUnderstandEnglishMoviesWithoutSubtitles.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/podcast-covers/HowToUnderstandEnglishMoviesWithoutSubtitles.jpg	\N	0	1	t	2026-03-23 01:17:10.637931+00
03522121-a4d2-4165-bffa-78de86409c76	podcast_01	Tôi lắng nghe họ, rồi ai sẽ lắng nghe tôi?	a15ee6da-8083-4cfc-9b57-95fe76fa59eb	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/podcast-files/ToiLangNgheHo.mp3	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/podcast-covers/ToiLangNgheHo.jpg	\N	0	5	t	2026-03-23 01:17:10.637931+00
\.


--
-- Data for Name: listens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.listens (id, user_id, song_id, podcast_id, listened_at) FROM stdin;
1	4db4556a-5a64-48cd-842f-6d733e6fe3e6	2	\N	2026-04-01 20:57:19.166726+00
2	19f7c722-41e5-4b99-a0c9-6f8c35521465	2	\N	2026-04-01 20:57:19.166726+00
3	6a848573-2697-4628-9a5c-8d65adad84de	2	\N	2026-04-01 20:57:19.166726+00
4	bb659d1e-e400-4fac-9125-b34873a5bd94	2	\N	2026-04-01 20:57:19.166726+00
5	4db4556a-5a64-48cd-842f-6d733e6fe3e6	3	\N	2026-04-01 20:52:19.166726+00
6	19f7c722-41e5-4b99-a0c9-6f8c35521465	3	\N	2026-04-01 20:52:19.166726+00
7	6a848573-2697-4628-9a5c-8d65adad84de	3	\N	2026-04-01 20:52:19.166726+00
8	bb659d1e-e400-4fac-9125-b34873a5bd94	3	\N	2026-04-01 20:52:19.166726+00
9	4db4556a-5a64-48cd-842f-6d733e6fe3e6	5	\N	2026-04-01 20:42:19.166726+00
10	19f7c722-41e5-4b99-a0c9-6f8c35521465	5	\N	2026-04-01 20:42:19.166726+00
11	6a848573-2697-4628-9a5c-8d65adad84de	5	\N	2026-04-01 20:42:19.166726+00
12	bb659d1e-e400-4fac-9125-b34873a5bd94	5	\N	2026-04-01 20:42:19.166726+00
13	4db4556a-5a64-48cd-842f-6d733e6fe3e6	6	\N	2026-04-01 20:37:19.166726+00
14	19f7c722-41e5-4b99-a0c9-6f8c35521465	6	\N	2026-04-01 20:37:19.166726+00
15	6a848573-2697-4628-9a5c-8d65adad84de	6	\N	2026-04-01 20:37:19.166726+00
16	bb659d1e-e400-4fac-9125-b34873a5bd94	6	\N	2026-04-01 20:37:19.166726+00
17	4db4556a-5a64-48cd-842f-6d733e6fe3e6	4	\N	2026-04-01 20:47:19.166726+00
18	19f7c722-41e5-4b99-a0c9-6f8c35521465	4	\N	2026-04-01 20:47:19.166726+00
19	6a848573-2697-4628-9a5c-8d65adad84de	4	\N	2026-04-01 20:47:19.166726+00
20	bb659d1e-e400-4fac-9125-b34873a5bd94	4	\N	2026-04-01 20:47:19.166726+00
21	4db4556a-5a64-48cd-842f-6d733e6fe3e6	1	\N	2026-04-01 21:02:19.166726+00
22	19f7c722-41e5-4b99-a0c9-6f8c35521465	1	\N	2026-04-01 21:02:19.166726+00
23	6a848573-2697-4628-9a5c-8d65adad84de	1	\N	2026-04-01 21:02:19.166726+00
24	bb659d1e-e400-4fac-9125-b34873a5bd94	1	\N	2026-04-01 21:02:19.166726+00
25	bb659d1e-e400-4fac-9125-b34873a5bd94	1	\N	2026-04-02 04:12:10.432+00
26	bb659d1e-e400-4fac-9125-b34873a5bd94	6	\N	2026-04-02 04:12:12.922+00
27	bb659d1e-e400-4fac-9125-b34873a5bd94	2	\N	2026-04-02 04:12:15.763+00
28	bb659d1e-e400-4fac-9125-b34873a5bd94	35	\N	2026-04-02 04:12:17.823+00
29	bb659d1e-e400-4fac-9125-b34873a5bd94	59	\N	2026-04-02 04:12:19.361+00
30	bb659d1e-e400-4fac-9125-b34873a5bd94	5	\N	2026-04-02 04:12:21.032+00
31	bb659d1e-e400-4fac-9125-b34873a5bd94	20	\N	2026-04-02 04:12:35.735+00
32	bb659d1e-e400-4fac-9125-b34873a5bd94	36	\N	2026-04-02 04:13:39.709+00
33	bb659d1e-e400-4fac-9125-b34873a5bd94	36	\N	2026-04-02 10:24:58.029+00
36	bb659d1e-e400-4fac-9125-b34873a5bd94	38	\N	2026-04-03 13:52:12.649+00
37	bb659d1e-e400-4fac-9125-b34873a5bd94	57	\N	2026-04-03 14:05:54.727+00
38	bb659d1e-e400-4fac-9125-b34873a5bd94	52	\N	2026-04-03 14:05:55.485+00
39	bb659d1e-e400-4fac-9125-b34873a5bd94	14	\N	2026-04-03 14:09:02.142+00
40	bb659d1e-e400-4fac-9125-b34873a5bd94	58	\N	2026-04-03 14:10:51.817+00
41	bb659d1e-e400-4fac-9125-b34873a5bd94	17	\N	2026-04-03 14:10:58.364+00
42	bb659d1e-e400-4fac-9125-b34873a5bd94	9	\N	2026-04-03 14:13:55.629+00
43	bb659d1e-e400-4fac-9125-b34873a5bd94	5	\N	2026-04-03 14:18:10.797+00
44	bb659d1e-e400-4fac-9125-b34873a5bd94	16	\N	2026-04-03 14:18:10.86+00
45	bb659d1e-e400-4fac-9125-b34873a5bd94	25	\N	2026-04-03 14:21:41.495+00
46	bb659d1e-e400-4fac-9125-b34873a5bd94	52	\N	2026-04-03 14:21:56.123+00
47	bb659d1e-e400-4fac-9125-b34873a5bd94	59	\N	2026-04-03 14:21:58.041+00
48	bb659d1e-e400-4fac-9125-b34873a5bd94	45	\N	2026-04-03 14:21:58.955+00
49	bb659d1e-e400-4fac-9125-b34873a5bd94	53	\N	2026-04-03 14:21:59.429+00
50	bb659d1e-e400-4fac-9125-b34873a5bd94	44	\N	2026-04-03 14:21:59.877+00
51	bb659d1e-e400-4fac-9125-b34873a5bd94	37	\N	2026-04-03 14:22:00.351+00
52	bb659d1e-e400-4fac-9125-b34873a5bd94	60	\N	2026-04-03 14:23:26.428+00
53	4db4556a-5a64-48cd-842f-6d733e6fe3e6	38	\N	2026-04-05 00:07:57.92446+00
54	4db4556a-5a64-48cd-842f-6d733e6fe3e6	38	\N	2026-04-05 00:08:02.173391+00
55	4db4556a-5a64-48cd-842f-6d733e6fe3e6	8	\N	2026-04-05 00:08:02.32515+00
56	bb659d1e-e400-4fac-9125-b34873a5bd94	19	\N	2026-04-05 17:33:44.65+00
57	bb659d1e-e400-4fac-9125-b34873a5bd94	44	\N	2026-04-05 17:33:45.095+00
58	bb659d1e-e400-4fac-9125-b34873a5bd94	59	\N	2026-04-05 17:34:00.703+00
59	bb659d1e-e400-4fac-9125-b34873a5bd94	22	\N	2026-04-05 17:34:17.651+00
60	bb659d1e-e400-4fac-9125-b34873a5bd94	38	\N	2026-04-05 17:35:08.498+00
61	bb659d1e-e400-4fac-9125-b34873a5bd94	40	\N	2026-04-05 17:39:17.614+00
62	bb659d1e-e400-4fac-9125-b34873a5bd94	12	\N	2026-04-05 17:39:20.143+00
63	bb659d1e-e400-4fac-9125-b34873a5bd94	49	\N	2026-04-05 17:39:24.012+00
64	bb659d1e-e400-4fac-9125-b34873a5bd94	45	\N	2026-04-05 17:39:24.988+00
65	bb659d1e-e400-4fac-9125-b34873a5bd94	37	\N	2026-04-05 17:39:27.048+00
66	bb659d1e-e400-4fac-9125-b34873a5bd94	1	\N	2026-04-05 17:48:49.098+00
67	bb659d1e-e400-4fac-9125-b34873a5bd94	23	\N	2026-04-05 17:52:14.224+00
68	bb659d1e-e400-4fac-9125-b34873a5bd94	25	\N	2026-04-05 17:55:02.997+00
69	bb659d1e-e400-4fac-9125-b34873a5bd94	7	\N	2026-04-05 17:59:35.202+00
70	bb659d1e-e400-4fac-9125-b34873a5bd94	16	\N	2026-04-05 18:03:25.925+00
71	bb659d1e-e400-4fac-9125-b34873a5bd94	5	\N	2026-04-05 18:03:25.844+00
72	bb659d1e-e400-4fac-9125-b34873a5bd94	25	\N	2026-04-05 18:06:38.095+00
76	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	5442963e-396d-48ee-b170-6a0e8ea548e3	2026-04-05 18:30:33.103+00
77	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	5442963e-396d-48ee-b170-6a0e8ea548e3	2026-04-05 18:30:44.06+00
78	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	96dd8651-4044-4008-b35e-fce298fadb4f	2026-04-05 18:30:44.104+00
79	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	02cddb96-843a-4ac7-b584-4ded977bf448	2026-04-05 18:31:02.986+00
80	bb659d1e-e400-4fac-9125-b34873a5bd94	40	\N	2026-04-05 18:32:16.68+00
81	bb659d1e-e400-4fac-9125-b34873a5bd94	44	\N	2026-04-05 18:32:16.754+00
\.


--
-- Data for Name: moods; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.moods (id, name, slug, description, cover_url, is_active, created_at) FROM stdin;
1	Chill	chill	Thư giãn nhẹ nhàng, phù hợp buổi tối	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/binhyen.jpg	t	2026-03-23 01:17:10.637931+00
2	Buồn	buon	Tâm trạng lắng đọng và suy tư	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/DOI.jpg	t	2026-03-23 01:17:10.637931+00
3	Tích cực	tich-cuc	Năng lượng tốt và cảm hứng	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/WaitingForYou.jpg	t	2026-03-23 01:17:10.637931+00
4	Tập trung	tap-trung	Phù hợp học tập và làm việc	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/ChimSau.jpg	t	2026-03-23 01:17:10.637931+00
5	Romantic	romantic	Lãng mạn và dễ rung động	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/DieWithASmile.jpg	t	2026-03-23 01:17:10.637931+00
\.


--
-- Data for Name: profiles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.profiles (id, email, display_name, created_at, avatar_url, updated_at, is_artist, password) FROM stdin;
19f7c722-41e5-4b99-a0c9-6f8c35521465	user1@gmail.com	User1	2026-03-23 01:17:10.637931+00	\N	2026-03-24 13:19:23.205176+00	f	123456
6a848573-2697-4628-9a5c-8d65adad84de	tinh.musicapp@gmail.com	Nguyễn Ngọc Tình	2026-03-23 01:17:10.637931+00	\N	2026-03-24 13:19:23.205176+00	f	123456
09491769-38ec-4b9d-ab02-71655d779076	nguyenlebaoquan1404@gmail.com	QuanQuan	2026-04-06 05:14:34.255557+00	https://ui-avatars.com/api/?name=QuanQuan22&background=random	2026-04-06 05:16:54.421044+00	f	Quan2209@
bb659d1e-e400-4fac-9125-b34873a5bd94	nguyenngoctinh011258@gmail.com	Twot	2026-03-23 01:17:10.637931+00	/uploads/avatars/avatar_bb659d1e-e400-4fac-9125-b34873a5bd94_639112334191643490.png	2026-04-08 01:23:39.168838+00	f	123456
\.


--
-- Data for Name: playlists; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.playlists (id, user_id, name, description, cover_url, playlist_type, is_system, is_public, songs_count_cache, saves_count_cache, total_listens_cache, created_at) FROM stdin;
1	\N	Top Hits	Playlist hệ thống nổi bật	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/theresnooneatall.jpg	system	t	t	5	0	0	2026-03-23 01:17:10.637931+00
2	\N	Chill Cuối Tuần	Playlist thư giãn cuối tuần	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/binhyen.jpg	system	t	t	5	0	0	2026-03-23 01:17:10.637931+00
3	\N	Nhạc Code Đêm	Playlist nghe khi làm việc đêm	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/ChimSau.jpg	system	t	t	5	0	0	2026-03-23 01:17:10.637931+00
55	bb659d1e-e400-4fac-9125-b34873a5bd94	Test 2	đang test	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/theresnooneatall.jpg	user	f	f	8	0	0	2026-04-05 10:39:13.554673+00
4	\N	Giai điệu đề xuất	Playlist gợi ý từ hệ thống	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/WaitingForYou.jpg	system	t	t	5	0	0	2026-03-23 01:17:10.637931+00
40	bb659d1e-e400-4fac-9125-b34873a5bd94	Nguyen Ngoc Tinh	\N	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/WaitingForYou.jpg	user	f	f	0	0	0	2026-03-24 21:51:16.260657+00
41	bb659d1e-e400-4fac-9125-b34873a5bd94	Tui Tên Tình	\N	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/ChimSau.jpg	user	f	f	1	0	0	2026-03-24 23:07:07.612161+00
42	bb659d1e-e400-4fac-9125-b34873a5bd94	Hi hi he he	\N	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/theresnooneatall.jpg	user	f	f	9	0	0	2026-03-31 23:35:58.093886+00
43	bb659d1e-e400-4fac-9125-b34873a5bd94	Hip Hop	các bản nhạc hip hop hay nhất của tình	https://znmfjbyvmiumctouolde.supabase.co/storage/v1/object/public/cover-images/0AINGHI.jpg	user	f	f	11	0	0	2026-04-03 07:21:39.379253+00
\.


--
-- Data for Name: playlist_songs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.playlist_songs (id, playlist_id, song_id, "position", created_at) FROM stdin;
1	1	6	1	2026-03-23 01:17:10.637931+00
2	1	7	2	2026-03-23 01:17:10.637931+00
3	1	8	3	2026-03-23 01:17:10.637931+00
4	1	39	4	2026-03-23 01:17:10.637931+00
5	1	20	5	2026-03-23 01:17:10.637931+00
6	2	1	1	2026-03-23 01:17:10.637931+00
7	2	9	2	2026-03-23 01:17:10.637931+00
8	2	17	3	2026-03-23 01:17:10.637931+00
9	2	23	4	2026-03-23 01:17:10.637931+00
10	2	50	5	2026-03-23 01:17:10.637931+00
11	3	14	1	2026-03-23 01:17:10.637931+00
12	3	51	2	2026-03-23 01:17:10.637931+00
13	3	52	3	2026-03-23 01:17:10.637931+00
14	3	57	4	2026-03-23 01:17:10.637931+00
15	3	58	5	2026-03-23 01:17:10.637931+00
16	4	10	1	2026-03-23 01:17:10.637931+00
17	4	21	2	2026-03-23 01:17:10.637931+00
18	4	41	3	2026-03-23 01:17:10.637931+00
19	4	46	4	2026-03-23 01:17:10.637931+00
20	4	60	5	2026-03-23 01:17:10.637931+00
21	41	1	1	2026-03-31 23:31:54.344288+00
22	42	25	1	2026-03-31 23:35:58.914237+00
23	42	31	2	2026-03-31 23:35:58.914237+00
24	42	22	3	2026-03-31 23:35:58.914237+00
25	42	35	4	2026-03-31 23:35:58.914237+00
26	42	30	5	2026-03-31 23:35:58.914237+00
27	42	46	6	2026-03-31 23:35:58.914237+00
28	42	48	7	2026-03-31 23:35:58.914237+00
29	42	40	8	2026-03-31 23:35:58.914237+00
30	42	20	9	2026-03-31 23:35:58.914237+00
31	43	54	1	2026-04-03 07:21:40.098133+00
32	43	5	2	2026-04-03 07:21:40.098133+00
33	43	34	3	2026-04-03 07:21:40.098133+00
34	43	35	4	2026-04-03 07:21:40.098133+00
35	43	36	5	2026-04-03 07:21:40.098133+00
36	43	37	6	2026-04-03 07:21:40.098133+00
37	43	44	7	2026-04-03 07:21:40.098133+00
38	43	53	8	2026-04-03 07:21:40.098133+00
39	43	45	9	2026-04-03 07:21:40.098133+00
40	43	59	10	2026-04-03 07:21:40.098133+00
41	43	52	11	2026-04-03 07:21:40.098133+00
69	55	6	1	2026-04-05 10:39:14.097561+00
71	55	25	3	2026-04-05 10:39:14.097561+00
73	55	13	5	2026-04-05 10:39:14.097561+00
74	55	19	6	2026-04-05 10:39:14.097561+00
75	55	37	7	2026-04-05 10:39:14.097561+00
76	55	45	8	2026-04-05 10:39:14.097561+00
77	55	49	9	2026-04-05 10:39:14.097561+00
78	55	12	10	2026-04-05 10:39:14.097561+00
\.


--
-- Data for Name: podcast_favorites; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.podcast_favorites (id, user_id, podcast_id, created_at) FROM stdin;
\.


--
-- Data for Name: podcast_listens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.podcast_listens (id, podcast_id, user_id, created_at) FROM stdin;
1	03522121-a4d2-4165-bffa-78de86409c76	bb659d1e-e400-4fac-9125-b34873a5bd94	2026-03-23 02:45:03.488476+00
2	03522121-a4d2-4165-bffa-78de86409c76	bb659d1e-e400-4fac-9125-b34873a5bd94	2026-03-23 02:45:03.821231+00
3	03522121-a4d2-4165-bffa-78de86409c76	bb659d1e-e400-4fac-9125-b34873a5bd94	2026-03-23 02:45:04.187413+00
4	96dd8651-4044-4008-b35e-fce298fadb4f	bb659d1e-e400-4fac-9125-b34873a5bd94	2026-03-23 02:45:13.782892+00
5	96dd8651-4044-4008-b35e-fce298fadb4f	bb659d1e-e400-4fac-9125-b34873a5bd94	2026-03-23 02:45:14.06479+00
6	96dd8651-4044-4008-b35e-fce298fadb4f	bb659d1e-e400-4fac-9125-b34873a5bd94	2026-03-23 02:45:14.86112+00
7	96dd8651-4044-4008-b35e-fce298fadb4f	bb659d1e-e400-4fac-9125-b34873a5bd94	2026-03-23 02:45:17.232512+00
8	96dd8651-4044-4008-b35e-fce298fadb4f	bb659d1e-e400-4fac-9125-b34873a5bd94	2026-03-23 02:45:18.920893+00
9	03522121-a4d2-4165-bffa-78de86409c76	bb659d1e-e400-4fac-9125-b34873a5bd94	2026-03-23 02:45:33.230452+00
10	03522121-a4d2-4165-bffa-78de86409c76	bb659d1e-e400-4fac-9125-b34873a5bd94	2026-03-23 02:45:33.417263+00
11	96dd8651-4044-4008-b35e-fce298fadb4f	bb659d1e-e400-4fac-9125-b34873a5bd94	2026-03-23 02:45:46.956014+00
12	96dd8651-4044-4008-b35e-fce298fadb4f	bb659d1e-e400-4fac-9125-b34873a5bd94	2026-03-23 02:45:47.391863+00
13	02cddb96-843a-4ac7-b584-4ded977bf448	bb659d1e-e400-4fac-9125-b34873a5bd94	2026-03-23 03:16:24.452332+00
14	5442963e-396d-48ee-b170-6a0e8ea548e3	bb659d1e-e400-4fac-9125-b34873a5bd94	2026-03-23 03:16:54.895086+00
15	02cddb96-843a-4ac7-b584-4ded977bf448	bb659d1e-e400-4fac-9125-b34873a5bd94	2026-03-23 03:16:59.632395+00
16	96dd8651-4044-4008-b35e-fce298fadb4f	bb659d1e-e400-4fac-9125-b34873a5bd94	2026-03-24 14:16:20.037758+00
17	96dd8651-4044-4008-b35e-fce298fadb4f	bb659d1e-e400-4fac-9125-b34873a5bd94	2026-03-24 14:16:56.436508+00
18	c7806c11-64d0-4491-a567-e6925ab44d5e	bb659d1e-e400-4fac-9125-b34873a5bd94	2026-03-24 22:27:04.988685+00
19	c61b8dcf-e714-4495-a1ee-53209222b70b	bb659d1e-e400-4fac-9125-b34873a5bd94	2026-03-27 10:31:53.121403+00
20	f5251bd3-61b5-432f-bd9f-6d94d5c7c88e	bb659d1e-e400-4fac-9125-b34873a5bd94	2026-03-27 20:38:09.501019+00
\.


--
-- Data for Name: song_artists; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.song_artists (song_id, artist_id, artist_order, role, created_at) FROM stdin;
1	0b208b81-4be1-42f9-97a7-36d16f72ba49	1	primary	2026-03-23 01:17:10.637931+00
27	438b19f6-e22c-41f0-9ef8-d76fdb281e6e	1	primary	2026-03-23 01:17:10.637931+00
1	438b19f6-e22c-41f0-9ef8-d76fdb281e6e	2	featured	2026-03-23 01:17:10.637931+00
2	b96e41ee-da36-4680-bcb1-880d847a13db	1	primary	2026-03-23 01:17:10.637931+00
2	2c54789f-18bd-4896-ade7-eab81414eb00	2	featured	2026-03-23 01:17:10.637931+00
2	f957e5f1-9264-437f-984d-381651e7b4ee	3	featured	2026-03-23 01:17:10.637931+00
55	a0a852dd-1cf9-4c3a-9094-1c485ff3aec7	1	primary	2026-03-23 01:17:10.637931+00
54	a0a852dd-1cf9-4c3a-9094-1c485ff3aec7	1	primary	2026-03-23 01:17:10.637931+00
53	a0a852dd-1cf9-4c3a-9094-1c485ff3aec7	1	primary	2026-03-23 01:17:10.637931+00
3	a0a852dd-1cf9-4c3a-9094-1c485ff3aec7	1	primary	2026-03-23 01:17:10.637931+00
3	8a5446b3-7072-44e9-bf5b-24ad8a4415cd	2	featured	2026-03-23 01:17:10.637931+00
56	2951ece2-3d85-49e5-a605-776ebfe81425	1	primary	2026-03-23 01:17:10.637931+00
31	2951ece2-3d85-49e5-a605-776ebfe81425	1	primary	2026-03-23 01:17:10.637931+00
15	2951ece2-3d85-49e5-a605-776ebfe81425	2	featured	2026-03-23 01:17:10.637931+00
4	2951ece2-3d85-49e5-a605-776ebfe81425	1	primary	2026-03-23 01:17:10.637931+00
3	2951ece2-3d85-49e5-a605-776ebfe81425	3	featured	2026-03-23 01:17:10.637931+00
15	2c432bc5-6d7c-4de1-9154-0d034396f500	3	featured	2026-03-23 01:17:10.637931+00
3	2c432bc5-6d7c-4de1-9154-0d034396f500	4	featured	2026-03-23 01:17:10.637931+00
5	cbe6dabd-7354-4086-948a-8dc4e9d35070	1	primary	2026-03-23 01:17:10.637931+00
49	b1bf7bb9-5c3a-4313-a384-b82acbb48283	1	primary	2026-03-23 01:17:10.637931+00
48	b1bf7bb9-5c3a-4313-a384-b82acbb48283	1	primary	2026-03-23 01:17:10.637931+00
47	b1bf7bb9-5c3a-4313-a384-b82acbb48283	2	featured	2026-03-23 01:17:10.637931+00
5	b1bf7bb9-5c3a-4313-a384-b82acbb48283	2	featured	2026-03-23 01:17:10.637931+00
52	941294a4-a8d6-40c6-9d79-d71f96fd3be2	1	primary	2026-03-23 01:17:10.637931+00
51	941294a4-a8d6-40c6-9d79-d71f96fd3be2	1	primary	2026-03-23 01:17:10.637931+00
14	941294a4-a8d6-40c6-9d79-d71f96fd3be2	1	primary	2026-03-23 01:17:10.637931+00
5	941294a4-a8d6-40c6-9d79-d71f96fd3be2	3	featured	2026-03-23 01:17:10.637931+00
38	55e33fdc-9249-4eac-8a32-80d8af20aec2	1	primary	2026-03-23 01:17:10.637931+00
8	55e33fdc-9249-4eac-8a32-80d8af20aec2	1	primary	2026-03-23 01:17:10.637931+00
7	55e33fdc-9249-4eac-8a32-80d8af20aec2	1	primary	2026-03-23 01:17:10.637931+00
6	55e33fdc-9249-4eac-8a32-80d8af20aec2	1	primary	2026-03-23 01:17:10.637931+00
9	9f07ef2d-ebc4-4aa6-af1d-1aef3c99b23b	1	primary	2026-03-23 01:17:10.637931+00
12	1d01f8d4-af31-4271-a972-23e70eab8a6d	1	primary	2026-03-23 01:17:10.637931+00
11	1d01f8d4-af31-4271-a972-23e70eab8a6d	1	primary	2026-03-23 01:17:10.637931+00
10	1d01f8d4-af31-4271-a972-23e70eab8a6d	1	primary	2026-03-23 01:17:10.637931+00
46	a0a60440-9df7-4ccd-8021-c7027b1298ea	1	primary	2026-03-23 01:17:10.637931+00
13	a0a60440-9df7-4ccd-8021-c7027b1298ea	1	primary	2026-03-23 01:17:10.637931+00
15	0a7cadbf-5842-4d61-a901-94718f7cbd46	1	primary	2026-03-23 01:17:10.637931+00
16	860f19de-29a2-4a2a-8e28-3a0feb576f07	1	primary	2026-03-23 01:17:10.637931+00
17	7ae8f347-8fda-4db7-af7f-521914e3944d	1	primary	2026-03-23 01:17:10.637931+00
18	282f88e3-637b-44a5-bd65-eb19e16bdb37	1	primary	2026-03-23 01:17:10.637931+00
19	4da91679-8a35-479b-a12a-b91031da063a	1	primary	2026-03-23 01:17:10.637931+00
43	f678e8c8-57cf-4ced-a787-83b35788b7c8	1	primary	2026-03-23 01:17:10.637931+00
42	f678e8c8-57cf-4ced-a787-83b35788b7c8	1	primary	2026-03-23 01:17:10.637931+00
41	f678e8c8-57cf-4ced-a787-83b35788b7c8	1	primary	2026-03-23 01:17:10.637931+00
20	f678e8c8-57cf-4ced-a787-83b35788b7c8	1	primary	2026-03-23 01:17:10.637931+00
21	58d12164-cf39-4ecb-ae2e-dfa0f76809e4	1	primary	2026-03-23 01:17:10.637931+00
21	2faf0c38-90eb-4e4d-b385-60702b1c1633	2	featured	2026-03-23 01:17:10.637931+00
22	8de0ac59-ebcc-401e-84c0-bfedd47e5ad5	1	primary	2026-03-23 01:17:10.637931+00
23	a1cf6887-2d7b-43eb-abed-c009b1f2dbb8	1	primary	2026-03-23 01:17:10.637931+00
24	3c1543e9-e414-48c9-bcc0-90f2208640e5	1	primary	2026-03-23 01:17:10.637931+00
24	d367e696-a291-44d1-aef7-d62092a7cf3d	2	featured	2026-03-23 01:17:10.637931+00
25	82afc3dc-30df-4a60-a5a0-a43506efcfda	1	primary	2026-03-23 01:17:10.637931+00
25	89416404-1f37-40f7-974c-6921f23792e6	2	featured	2026-03-23 01:17:10.637931+00
26	69aebe09-58f2-4c82-a98f-067f458a8b68	1	primary	2026-03-23 01:17:10.637931+00
28	cf8db550-c1b1-4d1a-9476-72a2e6f07351	1	primary	2026-03-23 01:17:10.637931+00
45	ae7f7346-a837-47ea-a00e-2d90630de3a7	1	primary	2026-03-23 01:17:10.637931+00
30	ae7f7346-a837-47ea-a00e-2d90630de3a7	1	primary	2026-03-23 01:17:10.637931+00
28	ae7f7346-a837-47ea-a00e-2d90630de3a7	2	featured	2026-03-23 01:17:10.637931+00
29	99d1a5e7-09bf-4426-81db-d3205afeec25	1	primary	2026-03-23 01:17:10.637931+00
32	8b4ceb2e-0366-493d-83a0-2a9320fedfd7	1	primary	2026-03-23 01:17:10.637931+00
32	644c5c8b-a4b5-4514-bb6b-f3ec0c66a96f	2	featured	2026-03-23 01:17:10.637931+00
33	9fb2ae7f-b38f-4e78-ae2f-c6f58d4549fa	1	primary	2026-03-23 01:17:10.637931+00
33	661c1836-ae0a-4ac3-a452-ecdb5bc81e89	2	featured	2026-03-23 01:17:10.637931+00
37	126403af-6197-4acb-9596-14e44bf9480f	2	featured	2026-03-23 01:17:10.637931+00
34	126403af-6197-4acb-9596-14e44bf9480f	1	primary	2026-03-23 01:17:10.637931+00
35	75da20e9-d8f2-4025-b4d2-b56d710aebd0	1	primary	2026-03-23 01:17:10.637931+00
36	26a3c206-fc12-47b0-a7eb-a733dc2c68ac	1	primary	2026-03-23 01:17:10.637931+00
37	1070aeb4-69a6-4a75-9ec1-28da1b455cdc	1	primary	2026-03-23 01:17:10.637931+00
39	79fdd720-1d63-4d94-bce7-197ed89f5fb7	1	primary	2026-03-23 01:17:10.637931+00
40	1ba78362-f6f5-4070-aa80-ee2dffa0f316	1	primary	2026-03-23 01:17:10.637931+00
40	5eeeea72-b859-445d-80c2-7dd524208cff	2	featured	2026-03-23 01:17:10.637931+00
40	d76686d4-d196-433a-b87b-921e3b7da72f	3	featured	2026-03-23 01:17:10.637931+00
41	da00a97c-9f38-4830-918b-1682133e554a	2	featured	2026-03-23 01:17:10.637931+00
44	275f3f7c-ff8e-4112-8c08-a5ab71a33d57	1	primary	2026-03-23 01:17:10.637931+00
45	c1558f28-48b4-4c56-81bc-22956238afc7	2	featured	2026-03-23 01:17:10.637931+00
47	6158d472-3722-46d5-9fe5-1a3101d6e24b	1	primary	2026-03-23 01:17:10.637931+00
50	7da092c2-9fbe-4171-96b6-a6e2a6b82042	1	primary	2026-03-23 01:17:10.637931+00
60	83fc2a9a-e886-4ef3-8a85-1d4d1e4af867	1	primary	2026-03-23 01:17:10.637931+00
59	83fc2a9a-e886-4ef3-8a85-1d4d1e4af867	1	primary	2026-03-23 01:17:10.637931+00
58	83fc2a9a-e886-4ef3-8a85-1d4d1e4af867	1	primary	2026-03-23 01:17:10.637931+00
57	83fc2a9a-e886-4ef3-8a85-1d4d1e4af867	1	primary	2026-03-23 01:17:10.637931+00
51	770f6054-f072-49cf-a30a-5712175060cf	2	featured	2026-03-23 01:17:10.637931+00
\.


--
-- Data for Name: song_genres; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.song_genres (song_id, genre_id, created_at) FROM stdin;
5	6	2026-03-23 01:17:10.637931+00
13	6	2026-03-23 01:17:10.637931+00
39	1	2026-03-23 01:17:10.637931+00
46	6	2026-03-23 01:17:10.637931+00
8	1	2026-03-23 01:17:10.637931+00
7	1	2026-03-23 01:17:10.637931+00
6	1	2026-03-23 01:17:10.637931+00
12	5	2026-03-23 01:17:10.637931+00
11	5	2026-03-23 01:17:10.637931+00
10	5	2026-03-23 01:17:10.637931+00
41	5	2026-03-23 01:17:10.637931+00
20	1	2026-03-23 01:17:10.637931+00
60	2	2026-03-23 01:17:10.637931+00
59	2	2026-03-23 01:17:10.637931+00
58	2	2026-03-23 01:17:10.637931+00
57	2	2026-03-23 01:17:10.637931+00
52	6	2026-03-23 01:17:10.637931+00
51	6	2026-03-23 01:17:10.637931+00
14	6	2026-03-23 01:17:10.637931+00
50	3	2026-03-23 01:17:10.637931+00
23	3	2026-03-23 01:17:10.637931+00
17	3	2026-03-23 01:17:10.637931+00
1	3	2026-03-23 01:17:10.637931+00
21	1	2026-03-23 01:17:10.637931+00
4	2	2026-03-23 01:17:10.637931+00
\.


--
-- Data for Name: song_hashtags; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.song_hashtags (id, song_id, hashtag_id, created_at) FROM stdin;
1	6	1	2026-03-23 01:17:10.637931+00
2	7	1	2026-03-23 01:17:10.637931+00
3	8	1	2026-03-23 01:17:10.637931+00
4	46	1	2026-03-23 01:17:10.637931+00
5	39	1	2026-03-23 01:17:10.637931+00
6	1	2	2026-03-23 01:17:10.637931+00
7	9	2	2026-03-23 01:17:10.637931+00
8	17	2	2026-03-23 01:17:10.637931+00
9	23	2	2026-03-23 01:17:10.637931+00
10	50	2	2026-03-23 01:17:10.637931+00
11	14	3	2026-03-23 01:17:10.637931+00
12	51	3	2026-03-23 01:17:10.637931+00
13	52	3	2026-03-23 01:17:10.637931+00
14	57	3	2026-03-23 01:17:10.637931+00
15	58	3	2026-03-23 01:17:10.637931+00
16	23	4	2026-03-23 01:17:10.637931+00
17	50	4	2026-03-23 01:17:10.637931+00
18	59	4	2026-03-23 01:17:10.637931+00
19	60	4	2026-03-23 01:17:10.637931+00
20	22	4	2026-03-23 01:17:10.637931+00
21	21	5	2026-03-23 01:17:10.637931+00
22	20	5	2026-03-23 01:17:10.637931+00
23	41	5	2026-03-23 01:17:10.637931+00
24	42	5	2026-03-23 01:17:10.637931+00
25	10	5	2026-03-23 01:17:10.637931+00
\.


--
-- Data for Name: song_listens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.song_listens (id, song_id, user_id, source_playlist_id, source_screen, listened_at) FROM stdin;
1	7	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	player	2026-03-23 03:10:58.437401+00
2	38	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	player	2026-03-23 03:11:01.098177+00
3	8	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	player	2026-03-23 03:11:01.62483+00
4	7	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	player	2026-03-23 03:11:02.245149+00
5	6	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	player	2026-03-23 03:11:03.206921+00
6	7	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	player	2026-03-23 03:11:03.697043+00
7	38	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	player	2026-03-23 03:11:04.233035+00
8	8	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	player	2026-03-23 03:11:04.815406+00
9	7	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	player	2026-03-23 03:11:05.244308+00
10	6	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	player	2026-03-23 03:11:05.759509+00
11	7	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	player	2026-03-23 03:11:06.201267+00
12	8	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	player	2026-03-23 03:11:06.928005+00
13	38	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	player	2026-03-23 03:11:07.4235+00
14	8	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	player	2026-03-23 03:11:07.903264+00
15	7	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	player	2026-03-23 03:11:08.381122+00
16	6	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	player	2026-03-23 03:11:08.812714+00
17	7	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	player	2026-03-23 03:11:09.277585+00
18	8	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	player	2026-03-23 03:11:09.770435+00
19	38	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	player	2026-03-23 03:11:10.277277+00
20	8	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	player	2026-03-23 03:11:10.733641+00
21	7	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	player	2026-03-23 03:11:11.247869+00
22	8	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	player	2026-03-23 03:11:11.726547+00
23	38	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	player	2026-03-23 03:11:15.197362+00
24	7	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	player	2026-03-23 03:11:16.21029+00
25	21	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	player	2026-03-23 03:18:05.587109+00
26	33	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	player	2026-03-23 03:18:10.396546+00
27	49	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	player	2026-03-23 03:31:11.304053+00
28	53	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	player	2026-03-23 03:34:46.267013+00
29	6	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	player	2026-03-24 13:59:24.24099+00
30	58	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	player	2026-03-24 14:00:05.852716+00
31	6	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	player	2026-03-24 14:00:10.544493+00
32	58	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	player	2026-03-24 14:00:49.579135+00
33	6	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	player	2026-03-24 14:01:00.835062+00
34	37	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	player	2026-03-24 14:02:39.550902+00
35	6	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	player	2026-03-24 14:02:42.290304+00
36	14	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	player	2026-03-24 14:15:19.434416+00
37	60	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	player	2026-03-24 14:15:36.567548+00
38	60	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	player	2026-03-24 14:15:55.688694+00
39	41	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	player	2026-03-24 14:16:04.558987+00
40	41	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	player	2026-03-24 14:17:09.980007+00
41	14	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	player	2026-03-24 14:17:46.921944+00
42	5	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	player	2026-03-24 14:22:17.997522+00
43	14	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	player	2026-03-24 14:22:22.424531+00
44	5	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	player	2026-03-24 14:22:23.34485+00
45	51	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	player	2026-03-24 14:22:26.612273+00
46	51	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	player	2026-03-24 16:15:49.779727+00
47	40	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	player	2026-03-24 16:16:02.665307+00
48	19	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	player	2026-03-24 19:52:28.103759+00
49	5	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	player	2026-03-24 19:53:42.728224+00
50	5	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	player	2026-03-24 23:03:54.034369+00
51	54	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	player	2026-03-24 23:04:21.54631+00
52	31	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	player	2026-03-24 23:05:15.88978+00
53	54	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	player	2026-03-24 23:09:11.183052+00
54	1	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	player	2026-03-24 23:09:22.375671+00
55	56	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	player	2026-03-24 23:09:47.620324+00
56	1	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	playlist	2026-03-27 20:59:43.781469+00
58	1	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	playlist	2026-03-27 20:59:43.761736+00
57	1	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	playlist	2026-03-27 20:59:43.757817+00
59	1	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	playlist	2026-03-27 20:59:43.757136+00
60	1	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	playlist	2026-03-27 20:59:43.761736+00
61	1	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	playlist	2026-03-27 20:59:44.43908+00
62	1	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	playlist	2026-03-27 20:59:44.544965+00
63	1	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	playlist	2026-03-27 20:59:44.548676+00
64	1	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	playlist	2026-03-27 20:59:44.540224+00
65	1	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	playlist	2026-03-27 20:59:45.839393+00
66	1	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	playlist	2026-03-27 20:59:48.874485+00
67	1	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	library_recent	2026-03-27 20:59:48.876434+00
68	19	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	player	2026-03-31 07:13:45.009427+00
69	60	bb659d1e-e400-4fac-9125-b34873a5bd94	\N	player	2026-03-31 08:38:57.47791+00
\.


--
-- Data for Name: song_moods; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.song_moods (song_id, mood_id, created_at) FROM stdin;
22	2	2026-03-23 01:17:10.637931+00
39	3	2026-03-23 01:17:10.637931+00
41	5	2026-03-23 01:17:10.637931+00
20	3	2026-03-23 01:17:10.637931+00
60	2	2026-03-23 01:17:10.637931+00
59	2	2026-03-23 01:17:10.637931+00
58	3	2026-03-23 01:17:10.637931+00
57	4	2026-03-23 01:17:10.637931+00
52	4	2026-03-23 01:17:10.637931+00
51	4	2026-03-23 01:17:10.637931+00
14	4	2026-03-23 01:17:10.637931+00
50	2	2026-03-23 01:17:10.637931+00
23	2	2026-03-23 01:17:10.637931+00
17	1	2026-03-23 01:17:10.637931+00
9	1	2026-03-23 01:17:10.637931+00
1	1	2026-03-23 01:17:10.637931+00
21	5	2026-03-23 01:17:10.637931+00
\.


--
-- Data for Name: trending_search_keywords; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.trending_search_keywords (id, keyword, score, updated_at) FROM stdin;
1	Sơn Tùng MTP	25	2026-03-23 01:17:10.637931+00
2	#nhachaynhatthang3	22	2026-03-23 01:17:10.637931+00
3	Billie Eilish	20	2026-03-23 01:17:10.637931+00
4	Nhạc chill đêm	18	2026-03-23 01:17:10.637931+00
5	RPT MCK	16	2026-03-23 01:17:10.637931+00
\.


--
-- Data for Name: user_disliked_artists; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_disliked_artists (user_id, artist_id, reason, created_at) FROM stdin;
\.


--
-- Data for Name: user_disliked_songs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_disliked_songs (user_id, song_id, reason, created_at) FROM stdin;
\.


--
-- Data for Name: user_followed_artists; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_followed_artists (id, user_id, artist_id, created_at) FROM stdin;
1	bb659d1e-e400-4fac-9125-b34873a5bd94	9f07ef2d-ebc4-4aa6-af1d-1aef3c99b23b	2026-04-03 07:14:53.038646+00
2	bb659d1e-e400-4fac-9125-b34873a5bd94	6158d472-3722-46d5-9fe5-1a3101d6e24b	2026-04-03 07:15:08.661642+00
3	bb659d1e-e400-4fac-9125-b34873a5bd94	cf8db550-c1b1-4d1a-9476-72a2e6f07351	2026-04-03 07:15:24.807604+00
4	bb659d1e-e400-4fac-9125-b34873a5bd94	8de0ac59-ebcc-401e-84c0-bfedd47e5ad5	2026-04-05 10:34:49.534633+00
5	bb659d1e-e400-4fac-9125-b34873a5bd94	860f19de-29a2-4a2a-8e28-3a0feb576f07	2026-04-05 11:06:33.226375+00
\.


--
-- Data for Name: user_player_state; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_player_state (user_id, current_song_id, current_playlist_id, position_seconds, is_playing, shuffle_enabled, repeat_mode, updated_at) FROM stdin;
019d5e74-59e6-7501-901c-2be146a81ff4	\N	\N	0	f	f	none	2026-04-05 16:22:56.017571+00
019d5e74-5e91-7cd5-815e-57787ca2f9d9	\N	\N	0	f	f	none	2026-04-05 16:22:57.222014+00
bb659d1e-e400-4fac-9125-b34873a5bd94	44	\N	2	f	f	off	2026-04-05 18:32:29.838+00
019d5dfe-e7c7-7f1c-929f-d6dcf0e09760	\N	\N	0	f	f	none	2026-04-05 14:14:39.05712+00
019d5dff-c8b9-7287-9ea3-53a30be11033	\N	\N	0	f	f	none	2026-04-05 14:15:36.698842+00
019d5dff-d91f-7040-b096-7fe7ffe161c7	\N	\N	0	f	f	none	2026-04-05 14:15:40.843686+00
019d5dff-dedb-7b11-9de3-175661830949	\N	\N	0	f	f	none	2026-04-05 14:15:42.37193+00
019d5e00-0db9-7347-9a28-8be8186e28c6	\N	\N	0	f	f	none	2026-04-05 14:15:54.358955+00
019d5e00-3c1b-738c-a1c6-fa4b4c101e88	\N	\N	0	f	f	none	2026-04-05 14:16:06.219564+00
019d5e00-466e-74e2-969a-3ccb8ffbd629	\N	\N	0	f	f	none	2026-04-05 14:16:08.88434+00
019d5e00-5c67-7464-8c3e-ce0cfe9a7076	\N	\N	0	f	f	none	2026-04-05 14:16:14.434635+00
019d5e00-666c-7a0a-a33a-3b2bf3ed2851	\N	\N	0	f	f	none	2026-04-05 14:16:17.068583+00
019d5e00-83e3-71b0-b1ae-8608bf3076ca	\N	\N	0	f	f	none	2026-04-05 14:16:24.291534+00
019d5e00-87a6-71dc-a755-31d98785e38b	\N	\N	0	f	f	none	2026-04-05 14:16:25.503581+00
019d5e00-9573-776a-b0c6-109389ab4c42	\N	\N	0	f	f	none	2026-04-05 14:16:29.095453+00
019d5e00-9bc3-7e6b-8e10-47a0c96892c5	\N	\N	0	f	f	none	2026-04-05 14:16:30.705137+00
019d5e00-c2ed-7ab8-9192-78faa61daf28	\N	\N	0	f	f	none	2026-04-05 14:16:40.70774+00
019d5e00-d4a3-7ee8-a095-ac7d7c93c7fe	\N	\N	0	f	f	none	2026-04-05 14:16:45.106269+00
019d5e00-e563-7e3d-9f04-183c553903a7	\N	\N	0	f	f	none	2026-04-05 14:16:49.533639+00
019d5e00-e97d-7bd6-ab0c-bb68c1cd9cc6	\N	\N	0	f	f	none	2026-04-05 14:16:50.63749+00
019d5e00-ecff-7a38-8441-a5d47fc6a77b	\N	\N	0	f	f	none	2026-04-05 14:16:51.517196+00
019d5e00-efe4-70e5-bf2b-c617e4b72779	\N	\N	0	f	f	none	2026-04-05 14:16:52.262509+00
019d5e00-f2e5-77aa-a2db-61732455c94d	\N	\N	0	f	f	none	2026-04-05 14:16:53.019046+00
019d5e00-f55b-70b7-9192-ec790a9093e0	\N	\N	0	f	f	none	2026-04-05 14:16:53.635113+00
019d5e00-f75f-77d3-ab28-0537e7dcc53d	\N	\N	0	f	f	none	2026-04-05 14:16:54.153247+00
019d5e00-f99c-76e3-abfd-72a53f2e3abf	\N	\N	0	f	f	none	2026-04-05 14:16:54.733686+00
019d5e00-fb74-71f1-ac1e-94a2f2d9574a	\N	\N	0	f	f	none	2026-04-05 14:16:55.216408+00
019d5e00-fec2-7174-8239-04790bfa6280	\N	\N	0	f	f	none	2026-04-05 14:16:56.089044+00
019d5e00-ffc6-7048-8c5d-584caf12e803	\N	\N	0	f	f	none	2026-04-05 14:16:56.341714+00
019d5e01-4981-70f7-8690-ca87e8ab9562	\N	\N	0	f	f	none	2026-04-05 14:17:15.151957+00
019d5e03-061b-7a81-88e0-4c67806ebbf1	\N	\N	0	f	f	none	2026-04-05 14:19:08.970045+00
019d5e03-b39d-7dd7-a2df-0cc6ce3571c4	\N	\N	0	f	f	none	2026-04-05 14:19:53.396121+00
019d5e03-f20a-74ba-b45b-09bdd4d1d796	\N	\N	0	f	f	none	2026-04-05 14:20:09.383145+00
019d5e03-f60c-77ba-98c1-d32619758bee	\N	\N	0	f	f	none	2026-04-05 14:20:10.381816+00
019d5e04-0c81-79e0-a484-189f24cc4107	\N	\N	0	f	f	none	2026-04-05 14:20:16.179901+00
019d5e04-4faf-7432-8ce6-5a7aed5060d9	\N	\N	0	f	f	none	2026-04-05 14:20:33.388002+00
019d5e05-6113-7391-9f42-66368eb705e2	\N	\N	0	f	f	none	2026-04-05 14:21:43.143997+00
019d5e05-65db-78f0-ace6-06af17d1153b	\N	\N	0	f	f	none	2026-04-05 14:21:43.936955+00
019d5e05-95fc-7dc5-9df5-8891f1cc8063	\N	\N	0	f	f	none	2026-04-05 14:21:56.876449+00
019d5e05-a5c9-70c2-a86e-6004e0a9a9e2	\N	\N	0	f	f	none	2026-04-05 14:22:00.856573+00
019d5e05-a6c2-74a8-ab40-6bd0469f966d	\N	\N	0	f	f	none	2026-04-05 14:22:01.16666+00
019d5e05-d301-75b1-82f2-4714844c10c2	\N	\N	0	f	f	none	2026-04-05 14:22:12.52248+00
019d5e15-7ac3-71f0-8db4-f769cb760a29	\N	\N	0	f	f	none	2026-04-05 14:39:18.519301+00
019d5e16-267a-7688-8ae4-79f0ab7727bb	\N	\N	0	f	f	none	2026-04-05 14:40:02.498012+00
019d5e16-3d33-7bfe-8624-34316e61c17c	\N	\N	0	f	f	none	2026-04-05 14:40:08.287535+00
019d5e16-6cdc-7c5f-b823-f1f7c732d775	\N	\N	0	f	f	none	2026-04-05 14:40:20.457751+00
019d5e16-c18a-7a23-b97f-f887c4735f87	\N	\N	0	f	f	none	2026-04-05 14:40:42.186569+00
019d5e16-d713-7508-b6ca-9aca15c1f360	\N	\N	0	f	f	none	2026-04-05 14:40:47.677185+00
019d5e17-0a2c-7e56-a869-ac901120ad5d	\N	\N	0	f	f	none	2026-04-05 14:41:00.780922+00
019d5e19-b890-7223-9f23-5d0df6638310	\N	\N	0	f	f	none	2026-04-05 14:43:56.145865+00
019d5e1d-fae4-7e16-a0cc-3991b47df69c	\N	\N	0	f	f	none	2026-04-05 14:48:35.61292+00
019d5e1d-fbc3-7537-8605-9d6afafb168c	\N	\N	0	f	f	none	2026-04-05 14:48:35.83147+00
019d5e1e-13fd-70ed-b664-a12999e68f91	\N	\N	0	f	f	none	2026-04-05 14:48:42.055092+00
019d5e1e-4b49-7564-adef-7cc84bdc2f9c	\N	\N	0	f	f	none	2026-04-05 14:48:56.110243+00
019d5e1e-a368-7a11-97bd-280393b606ae	\N	\N	0	f	f	none	2026-04-05 14:49:18.572803+00
019d5e1e-bf79-730c-8ee4-ea4d2be9cdf0	\N	\N	0	f	f	none	2026-04-05 14:49:25.779928+00
019d5e1e-e0f3-7038-810c-c46c3c453857	\N	\N	0	f	f	none	2026-04-05 14:49:34.505866+00
019d5e1e-fce7-75a0-92c9-5739e8d785eb	\N	\N	0	f	f	none	2026-04-05 14:49:41.607489+00
019d5e1f-2f87-700f-8b95-222d5591aee2	\N	\N	0	f	f	none	2026-04-05 14:49:54.489368+00
019d5e1f-6f1c-74a4-abcf-a7d837c850d5	\N	\N	0	f	f	none	2026-04-05 14:50:10.751391+00
019d5e69-9c58-7cc0-818b-4263a7eb3304	\N	\N	0	f	f	none	2026-04-05 16:11:12.130642+00
019d5e72-f30e-702d-beab-d4faefa19adf	\N	\N	0	f	f	none	2026-04-05 16:21:24.117759+00
019d5e73-b967-78be-9497-1fbaf694f6f4	\N	\N	0	f	f	none	2026-04-05 16:22:14.937209+00
019d5e73-cbb4-7121-83f0-43d73b076734	\N	\N	0	f	f	none	2026-04-05 16:22:19.635365+00
019d5e74-0093-7850-ad03-8cd5df758e8a	\N	\N	0	f	f	none	2026-04-05 16:22:33.148814+00
019d5e74-0b9d-7e29-9f30-b6a02799f0c0	\N	\N	0	f	f	none	2026-04-05 16:22:35.974939+00
019d5e74-1255-7f9a-8ee2-3325849d8686	\N	\N	0	f	f	none	2026-04-05 16:22:37.701912+00
019d5e74-1932-7c3d-b7e3-5320747bf047	\N	\N	0	f	f	none	2026-04-05 16:22:39.475459+00
019d5e74-22d1-74a6-8435-9b7635f4dd86	\N	\N	0	f	f	none	2026-04-05 16:22:41.940406+00
019d5e74-2e04-7611-a3a4-aec87dda773b	\N	\N	0	f	f	none	2026-04-05 16:22:44.78653+00
019d5e74-34ac-74f7-8790-391fed369935	\N	\N	0	f	f	none	2026-04-05 16:22:46.48935+00
019d5e74-398e-729d-81a3-97d91e7ec60b	\N	\N	0	f	f	none	2026-04-05 16:22:47.746412+00
019d5e74-3e38-7360-b9a9-f34c1a711287	\N	\N	0	f	f	none	2026-04-05 16:22:48.943944+00
019d5e74-485c-7d14-801a-501aa9cd9b67	\N	\N	0	f	f	none	2026-04-05 16:22:51.553065+00
019d5e74-4e17-7516-8575-03ed7dbdb15a	\N	\N	0	f	f	none	2026-04-05 16:22:53.014117+00
019d5e74-52b5-7666-8647-c48fd2e98f07	\N	\N	0	f	f	none	2026-04-05 16:22:54.175406+00
019d5e74-5698-7f9f-a52b-4a0aea487a3d	\N	\N	0	f	f	none	2026-04-05 16:22:55.207911+00
019d5e74-6114-7cd7-b558-3a131cb3efd7	\N	\N	0	f	f	none	2026-04-05 16:22:57.860538+00
019d5e74-6514-7bd7-bd17-a857520a924a	\N	\N	0	f	f	none	2026-04-05 16:22:58.901868+00
019d5e74-ada2-7853-9ce3-4cee9273fc90	\N	\N	0	f	f	none	2026-04-05 16:23:17.397094+00
019d5e75-4598-7b7b-80cd-93320523ffcd	\N	\N	0	f	f	none	2026-04-05 16:23:56.354348+00
019d5e77-2259-7b7b-80e4-9ee5be3c3962	\N	\N	0	f	f	none	2026-04-05 16:25:58.418611+00
019d5e77-24c2-7da6-9c12-10e429a521c1	\N	\N	0	f	f	none	2026-04-05 16:25:59.007815+00
019d5e77-376d-7941-984e-53a6d6472b55	\N	\N	0	f	f	none	2026-04-05 16:26:03.815608+00
019d5e77-58d4-7904-8ec5-7ffca0eee876	\N	\N	0	f	f	none	2026-04-05 16:26:12.355676+00
019d5e77-5b41-7383-a45e-4e6f804308e9	\N	\N	0	f	f	none	2026-04-05 16:26:12.973217+00
019d5e77-6e14-78e2-a585-5fde8a6add04	\N	\N	0	f	f	none	2026-04-05 16:26:17.786185+00
019d5e77-9b64-7628-9175-86b52492974e	\N	\N	0	f	f	none	2026-04-05 16:26:29.409218+00
019d5e78-1b3c-732e-9109-42513f9f8dee	\N	\N	0	f	f	none	2026-04-05 16:27:02.119492+00
019d5e78-f005-7e2a-897e-bfb64cd6fc32	\N	\N	0	f	f	none	2026-04-05 16:27:56.534522+00
019d5e7a-6d97-730b-935a-95096da70c79	\N	\N	0	f	f	none	2026-04-05 16:29:34.304868+00
019d5e7a-820d-7378-a2c9-5364e608cab8	\N	\N	0	f	f	none	2026-04-05 16:29:39.533567+00
019d5e7a-9b90-71ad-b6e4-88262c7fc1f1	\N	\N	0	f	f	none	2026-04-05 16:29:46.064361+00
019d5e7a-af04-7327-97ca-380ef3a35f3a	\N	\N	0	f	f	none	2026-04-05 16:29:51.034402+00
019d5e7a-dd7b-74c3-9763-50451f1a9f9c	\N	\N	0	f	f	none	2026-04-05 16:30:02.93609+00
019d5e7a-e564-75d2-9993-564e04228237	\N	\N	0	f	f	none	2026-04-05 16:30:04.97097+00
019d5e7a-f9a9-7007-a694-a83d9ea916c3	\N	\N	0	f	f	none	2026-04-05 16:30:10.136312+00
019d5e7a-fe42-7450-b451-6e914f39a5e5	\N	\N	0	f	f	none	2026-04-05 16:30:11.312505+00
019d5e7b-35ea-732b-bba5-470b1cb07c3b	\N	\N	0	f	f	none	2026-04-05 16:30:25.566957+00
019d5ec4-48d7-79c2-b6b1-ef217f1e0df6	\N	\N	0	f	f	none	2026-04-05 17:50:14.531493+00
019d5ec4-c306-7d50-ba94-9b1258940161	\N	\N	0	f	f	none	2026-04-05 17:50:45.72684+00
019d5ec5-01c9-79cd-b69d-24bb8d9e9c0c	\N	\N	0	f	f	none	2026-04-05 17:51:01.8746+00
019d5ec5-02ee-7e3c-bd1c-ad7649404ef2	\N	\N	0	f	f	none	2026-04-05 17:51:02.190171+00
019d5ec5-182e-7f1e-95d5-e151a847a297	\N	\N	0	f	f	none	2026-04-05 17:51:07.658364+00
019d5ec5-22cd-76c6-b196-afcd451ac727	\N	\N	0	f	f	none	2026-04-05 17:51:10.361346+00
019d5ec5-4fbc-7d09-952d-127c4b327e4c	\N	\N	0	f	f	none	2026-04-05 17:51:21.862214+00
019d5ec6-1095-7e57-b37c-c85b0ae588ca	\N	\N	0	f	f	none	2026-04-05 17:52:11.121037+00
019d5ec6-4df2-7e22-bb5d-136fb3ccf2d7	\N	\N	0	f	f	none	2026-04-05 17:52:26.939095+00
019d5ec6-90dc-714c-acb0-87d82f4ca7b6	\N	\N	0	f	f	none	2026-04-05 17:52:44.037321+00
019d5ed2-2536-70c2-83e4-5524c3ddf7e5	\N	\N	0	f	f	none	2026-04-05 18:05:22.966071+00
019d5ed2-382a-77c8-9b01-1352d31ea0f6	\N	\N	0	f	f	none	2026-04-05 18:05:27.790976+00
019d5ed2-3df4-7362-a0f5-e2d759f2f111	\N	\N	0	f	f	none	2026-04-05 18:05:29.338125+00
019d5ed2-75d1-7f04-a9d6-dd7a65624e9f	\N	\N	0	f	f	none	2026-04-05 18:05:43.595833+00
019d6136-f9be-7753-a8fa-04b28f724605	\N	\N	0	f	f	none	2026-04-06 05:14:45.383665+00
019d6138-a8c7-7d4b-a107-efc4a50ee186	\N	\N	0	f	f	none	2026-04-06 05:16:35.769551+00
019d6177-0da6-7400-be7a-b5cc1cb73b7e	\N	\N	0	f	f	none	2026-04-06 06:24:44.765162+00
019d6178-ddd1-75a2-ae19-3737bf1883d5	\N	\N	0	f	f	none	2026-04-06 06:26:43.504198+00
019d6179-0d02-7dcc-a5f8-e3180550f2e9	\N	\N	0	f	f	none	2026-04-06 06:26:55.698058+00
019d617a-6aec-7bb5-8b02-940a4cf3ea2b	\N	\N	0	f	f	none	2026-04-06 06:28:25.286359+00
019d617a-8065-77c4-a36c-298d0e4c9ef7	\N	\N	0	f	f	none	2026-04-06 06:28:30.746187+00
\.


--
-- Data for Name: user_preferred_artists; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_preferred_artists (user_id, artist_id, score, updated_at) FROM stdin;
bb659d1e-e400-4fac-9125-b34873a5bd94	4da91679-8a35-479b-a12a-b91031da063a	2	2026-03-31 07:13:45.009427+00
bb659d1e-e400-4fac-9125-b34873a5bd94	83fc2a9a-e886-4ef3-8a85-1d4d1e4af867	5	2026-03-31 08:38:57.47791+00
bb659d1e-e400-4fac-9125-b34873a5bd94	9f07ef2d-ebc4-4aa6-af1d-1aef3c99b23b	10	2026-04-03 07:14:53.038646+00
bb659d1e-e400-4fac-9125-b34873a5bd94	6158d472-3722-46d5-9fe5-1a3101d6e24b	10	2026-04-03 07:15:08.661642+00
bb659d1e-e400-4fac-9125-b34873a5bd94	cf8db550-c1b1-4d1a-9476-72a2e6f07351	10	2026-04-03 07:15:24.807604+00
bb659d1e-e400-4fac-9125-b34873a5bd94	8de0ac59-ebcc-401e-84c0-bfedd47e5ad5	10	2026-04-05 10:34:49.534633+00
bb659d1e-e400-4fac-9125-b34873a5bd94	860f19de-29a2-4a2a-8e28-3a0feb576f07	10	2026-04-05 11:06:33.226375+00
bb659d1e-e400-4fac-9125-b34873a5bd94	58d12164-cf39-4ecb-ae2e-dfa0f76809e4	1	2026-03-23 03:18:05.587109+00
bb659d1e-e400-4fac-9125-b34873a5bd94	2faf0c38-90eb-4e4d-b385-60702b1c1633	1	2026-03-23 03:18:05.587109+00
bb659d1e-e400-4fac-9125-b34873a5bd94	9fb2ae7f-b38f-4e78-ae2f-c6f58d4549fa	1	2026-03-23 03:18:10.396546+00
bb659d1e-e400-4fac-9125-b34873a5bd94	661c1836-ae0a-4ac3-a452-ecdb5bc81e89	1	2026-03-23 03:18:10.396546+00
bb659d1e-e400-4fac-9125-b34873a5bd94	126403af-6197-4acb-9596-14e44bf9480f	1	2026-03-24 14:02:39.550902+00
bb659d1e-e400-4fac-9125-b34873a5bd94	1070aeb4-69a6-4a75-9ec1-28da1b455cdc	1	2026-03-24 14:02:39.550902+00
bb659d1e-e400-4fac-9125-b34873a5bd94	55e33fdc-9249-4eac-8a32-80d8af20aec2	28	2026-03-24 14:02:42.290304+00
bb659d1e-e400-4fac-9125-b34873a5bd94	f678e8c8-57cf-4ced-a787-83b35788b7c8	2	2026-03-24 14:17:09.980007+00
bb659d1e-e400-4fac-9125-b34873a5bd94	da00a97c-9f38-4830-918b-1682133e554a	2	2026-03-24 14:17:09.980007+00
bb659d1e-e400-4fac-9125-b34873a5bd94	770f6054-f072-49cf-a30a-5712175060cf	2	2026-03-24 16:15:49.779727+00
bb659d1e-e400-4fac-9125-b34873a5bd94	1ba78362-f6f5-4070-aa80-ee2dffa0f316	1	2026-03-24 16:16:02.665307+00
bb659d1e-e400-4fac-9125-b34873a5bd94	5eeeea72-b859-445d-80c2-7dd524208cff	1	2026-03-24 16:16:02.665307+00
bb659d1e-e400-4fac-9125-b34873a5bd94	d76686d4-d196-433a-b87b-921e3b7da72f	1	2026-03-24 16:16:02.665307+00
bb659d1e-e400-4fac-9125-b34873a5bd94	cbe6dabd-7354-4086-948a-8dc4e9d35070	4	2026-03-24 23:03:54.034369+00
bb659d1e-e400-4fac-9125-b34873a5bd94	b1bf7bb9-5c3a-4313-a384-b82acbb48283	5	2026-03-24 23:03:54.034369+00
bb659d1e-e400-4fac-9125-b34873a5bd94	941294a4-a8d6-40c6-9d79-d71f96fd3be2	9	2026-03-24 23:03:54.034369+00
bb659d1e-e400-4fac-9125-b34873a5bd94	a0a852dd-1cf9-4c3a-9094-1c485ff3aec7	3	2026-03-24 23:09:11.183052+00
bb659d1e-e400-4fac-9125-b34873a5bd94	2951ece2-3d85-49e5-a605-776ebfe81425	2	2026-03-24 23:09:47.620324+00
bb659d1e-e400-4fac-9125-b34873a5bd94	0b208b81-4be1-42f9-97a7-36d16f72ba49	13	2026-03-27 20:59:48.876434+00
bb659d1e-e400-4fac-9125-b34873a5bd94	438b19f6-e22c-41f0-9ef8-d76fdb281e6e	13	2026-03-27 20:59:48.876434+00
\.


--
-- Data for Name: user_preferred_genres; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_preferred_genres (user_id, genre_id, score, updated_at) FROM stdin;
bb659d1e-e400-4fac-9125-b34873a5bd94	1	24	2026-03-24 14:02:42.290304+00
bb659d1e-e400-4fac-9125-b34873a5bd94	5	2	2026-03-24 14:17:09.980007+00
bb659d1e-e400-4fac-9125-b34873a5bd94	6	9	2026-03-24 23:03:54.034369+00
bb659d1e-e400-4fac-9125-b34873a5bd94	3	13	2026-03-27 20:59:48.876434+00
bb659d1e-e400-4fac-9125-b34873a5bd94	2	5	2026-03-31 08:38:57.47791+00
\.


--
-- Data for Name: user_recent_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_recent_items (id, user_id, item_type, item_key, interaction_type, source_screen, last_interacted_at, metadata) FROM stdin;
82	bb659d1e-e400-4fac-9125-b34873a5bd94	album	1	open	album_detail	2026-03-27 21:23:42.523041+00	{}
75	bb659d1e-e400-4fac-9125-b34873a5bd94	album	8	open	album_detail	2026-03-27 21:29:08.694861+00	{}
76	bb659d1e-e400-4fac-9125-b34873a5bd94	album	3	open	album_detail	2026-03-27 21:29:30.810746+00	{}
87	bb659d1e-e400-4fac-9125-b34873a5bd94	hashtag	2	open	search	2026-03-27 21:37:15.692889+00	{}
84	bb659d1e-e400-4fac-9125-b34873a5bd94	hashtag	1	open	search	2026-03-27 21:37:24.713454+00	{}
60	bb659d1e-e400-4fac-9125-b34873a5bd94	hashtag	3	open	search	2026-03-28 17:40:00.521504+00	{}
48	bb659d1e-e400-4fac-9125-b34873a5bd94	song	19	play	player	2026-03-31 07:13:45.009427+00	{}
37	bb659d1e-e400-4fac-9125-b34873a5bd94	song	60	play	player	2026-03-31 08:38:57.47791+00	{}
58	bb659d1e-e400-4fac-9125-b34873a5bd94	song	1	like	player	2026-03-31 23:31:49.989373+00	{}
54	bb659d1e-e400-4fac-9125-b34873a5bd94	song	31	like	player	2026-04-01 08:32:48.331027+00	{}
93	bb659d1e-e400-4fac-9125-b34873a5bd94	song	25	like	player	2026-04-01 08:39:22.074517+00	{}
94	bb659d1e-e400-4fac-9125-b34873a5bd94	song	16	like	player	2026-04-01 08:40:52.325657+00	{}
42	bb659d1e-e400-4fac-9125-b34873a5bd94	song	5	like	player	2026-04-01 08:40:55.212263+00	{}
3	bb659d1e-e400-4fac-9125-b34873a5bd94	song	8	play	player	2026-03-23 03:11:11.726547+00	{}
2	bb659d1e-e400-4fac-9125-b34873a5bd94	song	38	play	player	2026-03-23 03:11:15.197362+00	{}
1	bb659d1e-e400-4fac-9125-b34873a5bd94	song	7	play	player	2026-03-23 03:11:16.21029+00	{}
25	bb659d1e-e400-4fac-9125-b34873a5bd94	song	21	play	player	2026-03-23 03:18:05.587109+00	{}
26	bb659d1e-e400-4fac-9125-b34873a5bd94	song	33	play	player	2026-03-23 03:18:10.396546+00	{}
27	bb659d1e-e400-4fac-9125-b34873a5bd94	song	49	play	player	2026-03-23 03:31:11.304053+00	{}
28	bb659d1e-e400-4fac-9125-b34873a5bd94	song	53	play	player	2026-03-23 03:34:46.267013+00	{}
30	bb659d1e-e400-4fac-9125-b34873a5bd94	song	58	play	player	2026-03-24 14:00:49.579135+00	{}
34	bb659d1e-e400-4fac-9125-b34873a5bd94	song	37	play	player	2026-03-24 14:02:39.550902+00	{}
5	bb659d1e-e400-4fac-9125-b34873a5bd94	song	6	play	player	2026-03-24 14:02:42.290304+00	{}
39	bb659d1e-e400-4fac-9125-b34873a5bd94	song	41	play	player	2026-03-24 14:17:09.980007+00	{}
36	bb659d1e-e400-4fac-9125-b34873a5bd94	song	14	play	player	2026-03-24 14:22:22.424531+00	{}
45	bb659d1e-e400-4fac-9125-b34873a5bd94	song	51	play	player	2026-03-24 16:15:49.779727+00	{}
47	bb659d1e-e400-4fac-9125-b34873a5bd94	song	40	play	player	2026-03-24 16:16:02.665307+00	{}
51	bb659d1e-e400-4fac-9125-b34873a5bd94	song	54	play	player	2026-03-24 23:09:11.183052+00	{}
59	bb659d1e-e400-4fac-9125-b34873a5bd94	song	56	play	player	2026-03-24 23:09:47.620324+00	{}
80	bb659d1e-e400-4fac-9125-b34873a5bd94	album	5	open	album_detail	2026-03-27 21:23:21.004502+00	{}
\.


--
-- Data for Name: user_recent_searches; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_recent_searches (id, user_id, keyword, searched_at) FROM stdin;
\.


--
-- Data for Name: user_saved_playlists; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_saved_playlists (id, user_id, playlist_id, created_at) FROM stdin;
\.


--
-- Name: albums_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.albums_id_seq', 8, true);


--
-- Name: favorites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.favorites_id_seq', 27, true);


--
-- Name: genres_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.genres_id_seq', 6, true);


--
-- Name: hashtags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.hashtags_id_seq', 5, true);


--
-- Name: home_banners_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.home_banners_id_seq', 3, true);


--
-- Name: home_section_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.home_section_items_id_seq', 19, true);


--
-- Name: home_sections_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.home_sections_id_seq', 6, true);


--
-- Name: listens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.listens_id_seq', 81, true);


--
-- Name: moods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.moods_id_seq', 5, true);


--
-- Name: playlist_songs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.playlist_songs_id_seq', 88, true);


--
-- Name: playlists_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.playlists_id_seq', 57, true);


--
-- Name: podcast_listens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.podcast_listens_id_seq', 20, true);


--
-- Name: song_hashtags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.song_hashtags_id_seq', 25, true);


--
-- Name: song_listens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.song_listens_id_seq', 242, true);


--
-- Name: songs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.songs_id_seq', 71, true);


--
-- Name: trending_search_keywords_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.trending_search_keywords_id_seq', 5, true);


--
-- Name: user_followed_artists_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_followed_artists_id_seq', 5, true);


--
-- Name: user_recent_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_recent_items_id_seq', 116, true);


--
-- Name: user_recent_searches_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_recent_searches_id_seq', 1, false);


--
-- Name: user_saved_playlists_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_saved_playlists_id_seq', 1, false);


--
-- PostgreSQL database dump complete
--

\unrestrict q5UIohGgtZUb9exTGdiDQdWut1MHP8gQKD7s77y1uyp7QaS0QBzMNhoYvNN2T4x

